# -*- coding: UTF-8 -*-
"""
Project: PhD_Paper3
File: tweet.py
Author: 王晨龙 Chenlong Wang
Date & Time of Creation: 2022-04-23 10:12 
"""
import random


class Tweet:
    def __init__(self, tweet_id: str, create_time: int, publisher, opinion: float, content_most_important_aspect: tuple,
                 content_less_important_aspect: tuple, content_least_important_aspect: tuple):
        """
        Constructor of the Tweet.

        :param str tweet_id: The identification ID of the Tweet.
        :param int create_time: The time step in which the Tweet was created.
        :param User publisher: The user who posted this Tweet.
        :param float opinion: The opinion expressed in this Tweet.
        :param tuple content_most_important_aspect: The content of this Tweet about the most important aspect.
        (topic, information about this topic).
        :param tuple content_less_important_aspect: The content of this Tweet about the less important aspect.
        (topic, information about this topic).
        :param tuple content_least_important_aspect: The content of this Tweet about the lease important aspect.
        (topic, information about this topic).
        """
        # =========================================== Basic Configurations =========================================== #
        # Identification ID of this Tweet.
        self.tweetId = tweet_id
        # The time step in which this tweet was published.
        self.create_time = create_time
        # The user who published this tweet.
        self.publisher = publisher
        # The opinion expressed in this Tweet.
        self.opinion = opinion
        # The content of this Tweet about the most important aspect. (aspect, information about this aspect).
        self.content_most_important_aspect = content_most_important_aspect
        # The content of this Tweet about the less important aspect. (aspect, information about this aspect).
        self.content_less_important_aspect = content_less_important_aspect
        # The content of this Tweet about the lease important aspect. (topic, information about this aspect).
        self.content_least_important_aspect = content_least_important_aspect
        # The topics of this Tweet.
        self.topics = set()
        self.topics.add(content_most_important_aspect[0])
        self.topics.add(content_less_important_aspect[0])
        self.topics.add(content_least_important_aspect[0])
        # The weighted error severity of this Tweet.
        self.weighted_severity = 4 * abs(self.content_most_important_aspect[1]) + \
                                 2 * abs(self.content_less_important_aspect[1]) + \
                                 1 * abs(self.content_least_important_aspect[1])

        # The period of time steps that is defined as "recent".
        self.recent_definition = 3
        # ============================================= Behaviour Records ============================================ #
        # The record of times of this Tweet being read. <key, value> = <time_step, int>.
        self.read_record = dict()
        # The record of this Tweet being retweeted. <key, value> = <time_step, Set<User>>.
        self.retweet_record = dict()
        # How many times this Tweet has been retweeted in corresponding time step. <key, value> = <time_step, int>
        self.retweet_times = dict()
        # In total, how many times this Tweet has been retweeted. <key, value> = <time_step, int>
        self.accumulative_retweet_times = dict()

        # The users who up voted this Tweet. <key, value> = <time_step, Set<User>>.
        self.up_vote_record = dict()
        # The users who down voted this Tweet. <key, value> = <time_step, Set<User>>.
        self.down_vote_record = dict()
        # How many up votes this Tweet gets in corresponding time steps. <time_step, int>
        self.up_vote_nums = dict()
        # In total, how many up votes this Tweet gets. <key, value> = <time_step, int>.
        self.accumulative_up_vote_nums = dict()
        # How many down votes this Tweet gets in corresponding time steps. <time_step, int>
        self.down_vote_nums = dict()
        # In total, how many down votes this Tweet gets. <key, value> = <time_step, int>.
        self.accumulative_down_vote_nums = dict()

        # The notes attached to this Tweet. <key, value> = <time_step, Set<Note>>.
        self.notes = dict()
        # How many Notes are posted in corresponding time step. <key, value> = <time_step, int>.
        self.note_num = dict()
        # In total, how many Notes are posted to this Tweet. <key, value> = <time_step, int>.
        self.accumulative_note_num = dict()
        # The note that is rated as helpful and is shown. This will be updated at the beginning of every time step.
        self.shown_note = None

    def __repr__(self):
        return "Tweet %s" % self.tweetId

    def __str__(self):
        return "Tweet %s" % self.tweetId

    def __eq__(self, other):
        if self.tweetId == other.tweetId:
            return True
        return False

    def __hash__(self):
        return hash(self.tweetId)

    def was_recently_posted_by(self, user, current_time_step):
        """
        Whether this Tweet was posted by the given user in the recent 5 time steps.

        :param User user: The given user.
        :param int current_time_step: Current time steps.
        :return: True/False.
        :rtype: bool
        """
        if self.publisher == user and self.create_time > current_time_step-self.recent_definition:
            return True
        return False

    def was_posted_by(self, user):
        """
        Whether this Tweet was posted by the given user.

        :param User user: The given user.
        :return: True/False.
        :rtype: bool
        """
        if self.publisher == user:
            return True
        return False

    def was_retweeted_by(self, user):
        """
        Whether this Tweet was retweeted by the given user.
        :param User user: The given user.
        :return: True/False.
        :rtype: bool
        """
        for time_step in self.retweet_record:
            if user in self.retweet_record[time_step]:
                return True
        return False

    def was_recently_retweeted_by(self, user, current_time_step):
        """
        Whether this Tweet was retweeted by the given user in the recent 5 time steps.

        :param User user: The given user.
        :param int current_time_step: The current time step.
        :return: True/False.
        :rtype: bool
        """
        for time_step in self.retweet_record:
            if time_step > current_time_step-self.recent_definition and user in self.retweet_record[time_step]:
                return True
        return False

    def recent_retweet_users(self, current_time_step):
        """
        Get a set of users who retweeted this tweet in the recent 5 time steps.

        :param int current_time_step: Current time step.
        :return: The set of users.
        :rtype: set[User]
        """
        users_who_retweeted = set()
        for time_step in self.retweet_record:
            if time_step > current_time_step - self.recent_definition:
                users_who_retweeted.update(self.retweet_record[time_step])
        return users_who_retweeted

    def calculate_retweet_time(self, current_time_step):
        """
        Calculate how many times this Tweet has been retweeted in the given time step.

        :param int current_time_step: Current time step.
        """
        count = 0
        accumulative_count = 0
        for time_step in range(1, current_time_step+1):
            if time_step in self.retweet_record.keys():
                accumulative_count += len(self.retweet_record[time_step])
                if time_step == current_time_step:
                    count += len(self.retweet_record[time_step])
        self.retweet_times[current_time_step] = count
        self.accumulative_retweet_times[current_time_step] = accumulative_count

    def get_up_vote_num(self, current_time_step: int):
        """
        Calculate the number of up vote this Tweet has received in the given time step.

        :param int current_time_step: The given time step.
        :return: The up vote number.
        :rtype: int
        """
        up_vote_num = 0
        for time_step in self.up_vote_record.keys():
            up_vote_num += len(self.up_vote_record[time_step])
        self.accumulative_up_vote_nums[current_time_step] = up_vote_num
        return up_vote_num

    def calculate_votes(self, current_time_step):
        """
        Calculate how many up votes and down votes this Tweet has gotten.

        :param int current_time_step: Current time step.
        """
        self.up_vote_nums[current_time_step] = 0
        self.down_vote_nums[current_time_step] = 0
        accumulative_up_vote_count = 0
        accumulative_down_vote_count = 0
        for time_step in range(1, current_time_step+1):
            if time_step in self.up_vote_record.keys():
                accumulative_up_vote_count += len(self.up_vote_record[time_step])
                if time_step == current_time_step:
                    self.up_vote_nums[current_time_step] = len(self.up_vote_record[time_step])
            if time_step in self.down_vote_record.keys():
                accumulative_down_vote_count += len(self.down_vote_record[time_step])
                if time_step == current_time_step:
                    self.down_vote_nums[current_time_step] = len(self.down_vote_record[time_step])
        self.accumulative_up_vote_nums[current_time_step] = accumulative_up_vote_count
        self.accumulative_down_vote_nums[current_time_step] = accumulative_down_vote_count

    def calculate_notes(self, current_time_step):
        """
        Calculate how many Notes this Tweet has gotten.

        :param int current_time_step: Current time step.
        """
        self.note_num[current_time_step] = 0
        accumulative_count = 0
        for time_step in range(1, current_time_step+1):
            if time_step in self.notes.keys():
                accumulative_count += len(self.notes[time_step])
                if time_step == current_time_step:
                    self.note_num[current_time_step] = len(self.notes[time_step])
        self.accumulative_note_num[current_time_step] = accumulative_count

    def calculate_like_num(self):
        """
        Calculate how many likes this Tweet has gotten.

        :return: The number of likes.
        :rtype: int
        """
        count = 0
        for time_step in self.up_vote_record:
            count += len(self.up_vote_record[time_step])
        return count

    def get_random_not_showing_notes(self, topic: int):
        """
        Randomly select at most 3 notes about the given topic, except for the shown one.

        :param int topic: The given topic. -1 if the topic is not specified.
        :return: A list of notes.
        :rtype: list[Note]
        """
        all_notes = []
        for time_step in self.notes:
            for note in self.notes[time_step]:
                if self.shown_note is not None and note == self.shown_note:
                    continue
                if topic == -1 or note.content[0] == topic:
                    all_notes.append(note)
        if len(all_notes) <= 3:
            return all_notes
        else:
            return random.sample(all_notes, 3)

    def randomly_select_an_aspect(self):
        """
        Randomly select an aspect for verification.

        :return: The selected aspect.
        :rtype: int
        """
        aspect_choice = random.choice([1, 2, 3])
        if aspect_choice == 1:
            verification_aspect = self.content_most_important_aspect[0]
        elif aspect_choice == 2:
            verification_aspect = self.content_less_important_aspect[0]
        else:
            verification_aspect = self.content_least_important_aspect[0]
        return verification_aspect

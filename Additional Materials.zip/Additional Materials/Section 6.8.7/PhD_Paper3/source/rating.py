# -*- coding: UTF-8 -*-
"""
Project: PhD_Paper3
File: rating.py
Author: 王晨龙 Chenlong Wang
Date & Time of Creation: 2022-05-12 18:10 
"""


class Rating:
    def __init__(self, rating_id, rater, note, publish_time, helpful):
        """
        The constructor of Rating class.

        :param int rating_id: The identification ID of this rating.
        :param User rater: Who gave this rating.
        :param Note note: The note to which this rating was given.
        :param int publish_time: The time step in which this rating was given.
        :param int helpful: Whether this note is helpful. 0: not helpful; 1: somewhat helpful, 2: helpful
        """
        self.rating_id = rating_id
        self.rater = rater
        self.note = note
        self.publish_time = publish_time
        self.helpful = helpful

    def __str__(self):
        if self.helpful == 0:
            helpful = "Not helpful"
        elif self.helpful == 1:
            helpful = "Somewhat helpful"
        else:
            helpful = "Helpful"
        string = "Rating %d to Note %d: %s."
        return string % (self.rating_id, self.note.note_id, helpful)

    def __repr__(self):
        if self.helpful == 0:
            helpful = "Not helpful"
        elif self.helpful == 1:
            helpful = "Somewhat helpful"
        else:
            helpful = "Helpful"
        string = "Rating %d to Note %d: %s."
        return string % (self.rating_id, self.note.note_id, helpful)

    def __eq__(self, other):
        if self.rating_id == other.rating_id:
            return True
        return False

    def __hash__(self):
        return hash(self.rating_id)

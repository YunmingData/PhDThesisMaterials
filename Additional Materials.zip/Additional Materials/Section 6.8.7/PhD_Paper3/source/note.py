# -*- coding: UTF-8 -*-
"""
Project: PhD_Paper3
File: note.py
Author: 王晨龙 Chenlong Wang
Date & Time of Creation: 2022-04-23 10:16 
"""
from tweet import Tweet


class Note:
    def __init__(self, note_id: str, tweet: Tweet, publisher, create_time: int, opinion: float, content: tuple):
        """
        The constructor of the Note.

        :param str note_id: The identification ID of this Note.
        :param Tweet tweet: The Tweet to which this Note is posted.
        :param User publisher: The user who posted this Note.
        :param int create_time: The time step in which this Note is posted.
        :param float opinion: The opinion expressed in this note.
        :param tuple content: The debunking content of this note. (topic, content).
        """
        # =========================================== Basic Configurations =========================================== #
        # The identification ID of the note.
        self.note_id = note_id
        # The Tweet to which this note was published.
        self.tweet = tweet
        # Which user published this Note.
        self.publisher = publisher
        # The time step in which this note was created.
        self.create_time = create_time
        # The opinion expressed in this note.
        self.opinion = opinion
        # The debunking content of this note. (topic, content).
        self.content = content
        # ============================================= Behaviour Records ============================================ #
        # The users who rated this note. <key, value> = <time_step, set(Rating)>
        self.ratings = dict()
        # The rating status calculated by Birdwatch. 1: helpful; -1: not helpful; 0: need more ratings.
        self.rating_status = 0

    def __str__(self):
        return "Note %s to Tweet %s" % (self.note_id, self.tweet.tweetId)

    def __repr__(self):
        return "Note %s to Tweet %s" % (self.note_id, self.tweet.tweetId)

    def __eq__(self, other):
        if other.note_id == self.note_id:
            return True
        return False

    def __hash__(self):
        return hash(self.note_id)


# -*- coding: UTF-8 -*-
"""
Project: PhD_Paper3
File: run_3.py
Author: 王晨龙 Chenlong Wang
Date & Time of Creation: 2022-07-19 14:47 
"""
from model import SimulationModel

rep_num = 10
rep = 1

for i in range(rep_num):
    # Sub model 2.
    for note_ranking_interval in [1, 2, 3, 4, 5]:
        for discreet_level in [0.1, 0.3, 0.5, 0.7, 0.9]:
            for up_vote_effect in [1, 2, 3]:
                for polarisation_degree in [0.1, 0.3, 0.5, 0.7, 0.9]:
                    abm = SimulationModel(sub_model="Sub Model 3",
                                          repetition=rep,
                                          treatment=2,
                                          discreet_level=discreet_level,
                                          up_vote_effect=up_vote_effect,
                                          echo_chamber_degree=polarisation_degree,

                                          note_ranking_interval=note_ranking_interval,
                                          post_tweet_probability=0.01,
                                          read_length=10,
                                          network_evolution_period=5,
                                          network_evolution_threshold=0.5,
                                          verified_num=10,
                                          unverified_num=10,
                                          opinion_threshold=0.5,
                                          malicious_proportion=0.08)
                    abm.initialise()
                    abm.run()
                    rep += 1

    # Sensitivity Analysis: post_tweet_probability.
    for post_tweet_probability in [0.005, 0.01, 0.015]:
        abm = SimulationModel(sub_model="Sub Model 3: post_tweet_probability",
                              repetition=rep,
                              treatment=2,
                              discreet_level=0.5,
                              up_vote_effect=2,
                              echo_chamber_degree=0.5,

                              note_ranking_interval=3,
                              post_tweet_probability=post_tweet_probability,
                              read_length=10,
                              network_evolution_period=5,
                              network_evolution_threshold=0.5,
                              verified_num=10,
                              unverified_num=10,
                              opinion_threshold=0.5,
                              malicious_proportion=0.08)
        abm.initialise()
        abm.run()
        rep += 1

    # Sensitivity Analysis: read_length.
    for read_length in [5, 10, 15]:
        abm = SimulationModel(sub_model="Sub Model 3: read_length",
                              repetition=rep,
                              treatment=2,
                              discreet_level=0.5,
                              up_vote_effect=2,
                              echo_chamber_degree=0.5,

                              note_ranking_interval=3,
                              post_tweet_probability=0.01,
                              read_length=read_length,
                              network_evolution_period=5,
                              network_evolution_threshold=0.5,
                              verified_num=10,
                              unverified_num=10,
                              opinion_threshold=0.5,
                              malicious_proportion=0.08)
        abm.initialise()
        abm.run()
        rep += 1

    # Sensitivity Analysis: network_evolution_period.
    for network_evolution_period in [3, 5, 7]:
        abm = SimulationModel(sub_model="Sub Model 3: network_evolution_period",
                              repetition=rep,
                              treatment=2,
                              discreet_level=0.5,
                              up_vote_effect=2,
                              echo_chamber_degree=0.5,

                              note_ranking_interval=3,
                              post_tweet_probability=0.01,
                              read_length=10,
                              network_evolution_period=network_evolution_period,
                              network_evolution_threshold=0.5,
                              verified_num=10,
                              unverified_num=10,
                              opinion_threshold=0.5,
                              malicious_proportion=0.08)
        abm.initialise()
        abm.run()
        rep += 1

    # Sensitivity Analysis: opinion_threshold.
    for network_evolution_threshold in [0.3, 0.5, 0.7]:
        abm = SimulationModel(sub_model="Sub Model 3: network_evolution_threshold",
                              repetition=rep,
                              treatment=2,
                              discreet_level=0.5,
                              up_vote_effect=2,
                              echo_chamber_degree=0.5,

                              note_ranking_interval=3,
                              post_tweet_probability=0.01,
                              read_length=10,
                              network_evolution_period=5,
                              network_evolution_threshold=network_evolution_threshold,
                              verified_num=10,
                              unverified_num=10,
                              opinion_threshold=0.5,
                              malicious_proportion=0.08)
        abm.initialise()
        abm.run()
        rep += 1

    # Sensitivity Analysis: opinion_threshold.
    for opinion_threshold in [0.3, 0.5, 0.7]:
        abm = SimulationModel(sub_model="Sub Model 3: opinion_threshold",
                              repetition=rep,
                              treatment=2,
                              discreet_level=0.5,
                              up_vote_effect=2,
                              echo_chamber_degree=0.5,

                              note_ranking_interval=3,
                              post_tweet_probability=0.01,
                              read_length=10,
                              network_evolution_period=5,
                              network_evolution_threshold=0.5,
                              verified_num=10,
                              unverified_num=10,
                              opinion_threshold=opinion_threshold,
                              malicious_proportion=0.08)
        abm.initialise()
        abm.run()
        rep += 1

    # Sensitivity Analysis: malicious_proportion.
    for malicious_proportion in [0.04, 0.08, 0.12]:
        abm = SimulationModel(sub_model="Sub Model 3: malicious_proportion",
                              repetition=rep,
                              treatment=2,
                              discreet_level=0.5,
                              up_vote_effect=2,
                              echo_chamber_degree=0.5,

                              note_ranking_interval=3,
                              post_tweet_probability=0.01,
                              read_length=10,
                              network_evolution_period=5,
                              network_evolution_threshold=0.5,
                              verified_num=10,
                              unverified_num=10,
                              opinion_threshold=0.5,
                              malicious_proportion=malicious_proportion)
        abm.initialise()
        abm.run()
        rep += 1

# -*- coding: UTF-8 -*-
"""
Project: PhD_Paper3
File: utils.py
Author: 王晨龙 Chenlong Wang
Date & Time of Creation: 2022-06-27 18:53 
"""
import random


def merge_sort_users_by_extreme_degrees(user_list):
    """
    Sort the given user list by users' extreme degrees.

    :param list[User] user_list:
    :return: The sorted user list.
    """
    if len(user_list) <= 1:
        return user_list
    mid = len(user_list) // 2
    return merge(merge_sort_users_by_extreme_degrees(user_list[:mid]),
                 merge_sort_users_by_extreme_degrees(user_list[mid:]))


def merge(user_list_1: list, user_list_2: list):
    """
    Merge the two parts of users and make sure the result is sorted.

    :param list[User] user_list_1: The first part of
    :param list[User] user_list_2:
    :return: The merged user list.
    :rtype: list[User]
    """
    result = []
    while user_list_1 and user_list_2:
        if user_list_1[0].neutral_degree < user_list_2[0].neutral_degree:
            result.append(user_list_1.pop(0))
        else:
            result.append(user_list_1.pop(0))
    if user_list_1:
        result += user_list_1
    if user_list_2:
        result += user_list_2
    return result


def scale_free_principle_selection(candidates: dict, num_needed: int):
    """
    From the candidates offered, select several items according to the scale-free principle. The higher the item's
    corresponding attribute is, the more likely it will be chosen.

    :param dict candidates: The candidates and their attributes. <key, value> = <item, item's attribute>.
    :param int num_needed: How many items are needed to be selected.
    :return: A list of items selected from the candidates.
    :rtype: list
    """
    if num_needed >= len(candidates.keys()):
        return list(candidates.keys())

    selected_items = []
    while len(selected_items) < num_needed:
        item_selected = scale_free_principle_select(candidates)
        if item_selected is None:
            continue
        if item_selected in selected_items:
            continue
        selected_items.append(item_selected)
        del candidates[item_selected]
    return selected_items


def scale_free_principle_select(candidates: dict):
    """
    From the candidates offered, select one item according to the scale-free principle. The higher the item's
    corresponding attribute is, the more likely it will be chosen.

    :param dict candidates: The candidates and their attributes. <key, value> = <item, item's attribute>.
    :return: The item selected from the candidates.
    """
    total = 0
    for item in candidates:
        total += candidates[item]

    random_ranges = []
    accumulative_attribute = 0
    for item in candidates:
        upper_bound = candidates[item] / total + accumulative_attribute
        random_ranges.append((item, accumulative_attribute, upper_bound))
        accumulative_attribute += candidates[item] / total

    choice = random.random()
    for item_range in random_ranges:
        if item_range[1] <= choice < item_range[2]:
            return item_range[0]
    return None

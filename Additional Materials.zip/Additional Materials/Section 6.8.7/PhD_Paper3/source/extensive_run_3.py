# -*- coding: UTF-8 -*-
"""
Project: PhD_Paper3
File: extensive_run_3.py
Author: 王晨龙 Chenlong Wang
Date & Time of Creation: 2022-08-10 10:29 
"""
from model import SimulationModel

rep = 1
rep_num = 10

parameter_space = []

for i in range(rep_num):
    # Sub model 2.
    for note_ranking_interval in [1, 2, 3, 4, 5]:
        for discreet_level in [0.1, 0.3, 0.5, 0.7, 0.9]:
            for echo_chamber_degree in [0.1, 0.3, 0.5, 0.7, 0.9]:
                parameter_set = ("Sub Model 3", rep, 2, discreet_level, 2, echo_chamber_degree, note_ranking_interval,
                                 0.01, 10, 5, 0.5, 10, 10, 0.5, 0.08)
                parameter_space.append(parameter_set)
                rep += 1

    # Sensitivity Analysis: up_vote_effect.
    for up_vote_effect in [1, 2, 3]:
        parameter_set = ("Sub Model 3_up_vote_effect", rep, 0, 0.5, up_vote_effect, 0.5, 3, 0.01, 10, 5,
                         0.5, 10, 10, 0.5, 0.08)
        parameter_space.append(parameter_set)
        rep += 1

    # Sensitivity Analysis: post_tweet_probability.
    for post_tweet_probability in [0.005, 0.01, 0.015]:
        parameter_set = ("Sub Model 3_post_tweet_probability", rep, 2, 0.5, 2, 0.5, 3, post_tweet_probability, 10, 5,
                         0.5, 10, 10, 0.5, 0.08)
        parameter_space.append(parameter_set)
        rep += 1

    # Sensitivity Analysis: read_length.
    for read_length in [5, 10, 15]:
        parameter_set = ("Sub Model 3_read_length", rep, 2, 0.5, 2, 0.5, 3, 0.01, read_length, 5, 0.5, 10, 10, 0.5,
                         0.08)
        parameter_space.append(parameter_set)
        rep += 1

    # Sensitivity Analysis: network_evolution_period.
    for network_evolution_period in [3, 5, 7]:
        parameter_set = ("Sub Model 3_network_evolution_period", rep, 2, 0.5, 2, 0.5, 3, 0.01, 10,
                         network_evolution_period, 0.5, 10, 10, 0.5, 0.08)
        parameter_space.append(parameter_set)
        rep += 1

    # Sensitivity Analysis: opinion_threshold.
    for network_evolution_threshold in [0.3, 0.5, 0.7]:
        parameter_set = ("Sub Model 3_network_evolution_threshold", rep, 2, 0.5, 2, 0.5, 3, 0.01, 10, 5,
                         network_evolution_threshold, 10, 10, 0.5, 0.08)
        parameter_space.append(parameter_set)
        rep += 1

    # Sensitivity Analysis: opinion_threshold.
    for opinion_threshold in [0.3, 0.5, 0.7]:
        parameter_set = ("Sub Model 3_opinion_threshold", rep, 2, 0.5, 2, 0.5, 3, 0.01, 10, 5, 0.5, 10, 10,
                         opinion_threshold, 0.08)
        parameter_space.append(parameter_set)
        rep += 1

    # Sensitivity Analysis: malicious_proportion.
    for malicious_proportion in [0.04, 0.08, 0.12]:
        parameter_set = ("Sub Model 3_malicious_proportion", rep, 2, 0.5, 2, 0.5, 3, 0.01, 10, 5, 0.5, 10, 10, 0.5,
                         malicious_proportion)
        parameter_space.append(parameter_set)
        rep += 1

    # Sensitivity Analysis: verified_num
    for verified_num in [5, 10, 15]:
        parameter_set = ("Sub Model 3_verified_num", rep, 0, 0.5, 2, 0.5, 3, 0.01, 10, 5, 0.5, verified_num, 10, 0.5,
                         malicious_proportion)
        parameter_space.append(parameter_set)
        rep += 1

    # Sensitivity Analysis: unverified_num.
    for unverified_num in [5, 10, 15]:
        parameter_set = ("Sub Model 3_unverified_num", rep, 0, 0.5, 2, 0.5, 3, 0.01, 10, 5, 0.5, 10, unverified_num,
                         0.5, malicious_proportion)
        parameter_space.append(parameter_set)
        rep += 1

start_index = 1
for i in range(start_index-1, len(parameter_space)):
    parameter_set = parameter_space[i]
    abm = SimulationModel(sub_model=parameter_set[0],
                          repetition=parameter_set[1],
                          treatment=parameter_set[2],
                          discreet_level=parameter_set[3],
                          up_vote_effect=parameter_set[4],
                          echo_chamber_degree=parameter_set[5],

                          note_ranking_interval=parameter_set[6],
                          post_tweet_probability=parameter_set[7],
                          read_length=parameter_set[8],
                          network_evolution_period=parameter_set[9],
                          network_evolution_threshold=parameter_set[10],
                          verified_num=parameter_set[11],
                          unverified_num=parameter_set[12],
                          opinion_threshold=parameter_set[13],
                          malicious_proportion=parameter_set[14])
    abm.initialise()
    abm.run()

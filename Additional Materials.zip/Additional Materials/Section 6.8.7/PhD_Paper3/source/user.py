# -*- coding: UTF-8 -*-
"""
Project: PhD_Paper3
File: user.py
Author: 王晨龙 Chenlong Wang
Date & Time of Creation: 2022-05-02 09:16 
"""
from tweet import Tweet
from note import Note
from rating import Rating
import random


class User:
    def __init__(self, current_run: str, u_id: str, opinion: float, treatment: int,
                 discreet_level: float, up_vote_effect: int, post_tweet_probability: float,
                 network_evolution_period: int, network_evolution_threshold: float,
                 verified_information: set, unverified_information: dict,
                 opinion_threshold: float, malicious: bool):
        """
        Constructor of the user.

        :param str current_run: The identification of current run.
        :param str u_id: The identification ID of the user.
        :param float opinion: This user's opinion in the corresponding topic.

        :param int treatment: Whether the Birdwatch mechanism (note rating and calculation) is on. If it is on, which
        kind of mechanism is on. 0: no Birdwatch, just normal comments; 1: Birdwatch on; 2: Birdwatch on with reminding
        system.
        :param float discreet_level: The basic probability of verification.
        :param int up_vote_effect: How strong the up-votes' effect is. {1, 2, 3}.

        :param float post_tweet_probability: The probability of posting a Tweet in each time step. (0, 1).

        :param int network_evolution_period: The period of user's network evolution. It means how many time steps'
        interactions will this user take into consideration in following/unfollowing decision. The longer this threshold
        is, the less frequently this user is likely to change her/his social network structure. It is 0 when the user
        will never change her/his social network structure.
        :param float network_evolution_threshold: The threshold of user's network evolution. It means the proportion of
        agree/disagree from specific user in the period of time steps that leads this user to follow/unfollow the user.

        :param set[int] verified_information: The set of information pieces in which this user has verified knowledge.
        :param dict unverified_information: The information pieces in which this user has unverified, biased belief.
        <key, value> = <topic, belief in the topic>.
        :param float opinion_threshold: The threshold of having different interactions towards the opinion this user
        reads.
        :param bool malicious: Whether this user is the malicious user.
        """
        # =========================================== Basic Configurations =========================================== #
        # The ID of current run.
        self.current_run = current_run
        # The identification ID of this user.
        self.u_id = u_id
        # Whether the Birdwatch mechanism (note rating and calculation) is on.
        self.treatment = treatment
        # The period of user's network evolution. It means how many time steps' interactions will this user take into
        # consideration in following/unfollowing decision. The longer this threshold is, the less frequently this user
        # is likely to change her/his social network structure. It is 0 when the user will never change her/his social
        # network structure.
        self.network_evolution_period = network_evolution_period
        # The threshold of user's network evolution. It means the proportion of agree/disagree from specific user in the
        # period of time steps that leads this user to follow/unfollow the user.
        self.network_evolution_threshold = network_evolution_threshold
        # This user's opinion in the corresponding topic.
        self.opinion = opinion
        # The set of topics in which this user has verified knowledge.
        self.verified_information = verified_information
        # The topics in which this user has unverified, could be biased belief. <key, value> =
        # <topic, belief in the topic>.
        self.unverified_information = unverified_information
        # Whether this user is a malicious user.
        self.malicious = malicious
        # ========================================== Behaviour Rule Related ========================================== #
        # How strong the up-votes' effect is. {1, 2, 3}.
        self.up_vote_effect = up_vote_effect
        # The probability of post a Tweet in each time step.
        self.post_tweet_probability = post_tweet_probability
        # The basic probability of verification.
        self.discreet_level = discreet_level
        # The threshold of having different interactions towards the opinion this user reads.
        self.opinion_threshold = opinion_threshold
        # ============================================= Behaviour Records ============================================ #
        # Current time step.
        self.time_step = 1
        # The highest available Tweet ID. Update in each time step from the main thread.
        self.highest_tweet_id = 0
        # The highest available Note ID. Update in each time step from the main thread.
        self.highest_note_id = 0
        # The highest available Rating ID. Update in each time step from the main thread.
        self.highest_rating_id = 0
        # The record of the tweets that have been read by this user. <key, value> = <time_step, Set<Tweet>>.
        self.tweets_read_record = dict()
        # The record of Tweet posted by this user. <key, value> = <time_step, Set<Note>>.
        self.tweets_posted = dict()
        # The record of retweets by this user. <key, value> = <time_step, Set<Tweet>>.
        self.retweet_record = dict()
        # The record of notes posted by this user. <key, value> = <time_step, Set<Note>>.
        self.note_posted = dict()
        # The users this user follows.
        self.users_I_follow = set()
        # The users who are following this user.
        self.users_following_me = set()
        # The tweets liked (opinion difference below a threshold) by this user. <key, value> = <time_step, Set<Tweet>>.
        self.tweets_up_voted = dict()
        # The tweets unliked (opinion difference above a threshold) by this user.
        # <key, value> = <time_step, Set<Tweet>>.
        self.tweets_down_voted = dict()
        # The records about users with whom this user agreed in the past. <key, value> = <time_step, Set<Users>>.
        self.users_agreed_with = dict()
        # The records about users with whom this user disagreed in the past. <key, value> = <time_step, Set<Users>>.
        self.users_disagreed_with = dict()
        # ================================================== Output ================================================== #
        # The record of verified topics in each time step. <key, value> = <time_step, Set<Verified Topics>>.
        self.verified_topic_record = dict()
        # The record of unverified topics in each time step. <key, value> = <time_step, Set<Unverified Topics>>.
        self.unverified_topic_record = dict()

    def __repr__(self):
        return "User %s" % self.u_id

    def __str__(self):
        return "User %s" % self.u_id

    def __eq__(self, other):
        if other.u_id == self.u_id:
            return True
        return False

    def __hash__(self):
        return hash(self.u_id)

    def follow(self, user):
        """
        Follow the given user, add the following relationship in both users.

        :param User user: The user to follow.
        """
        self.users_I_follow.add(user)
        user.users_following_me.add(self)

    def unfollow(self, user):
        """
        Unfollow the given user, remove the following relationship from both users.

        :param User user: the user to unfollow.
        """
        if user in self.users_I_follow:
            self.users_I_follow.remove(user)
        if self in user.users_following_me:
            user.users_following_me.remove(self)

    def preparation(self, time_step, highest_tweet_id, highest_note_id, highest_rating_id):
        """
        Preparation before the time step.

        :param int time_step: The current time step.
        :param int highest_tweet_id: The highest available Tweet ID.
        :param int highest_note_id: The highest available Note ID.
        :param int highest_rating_id: The highest available Rating ID.
        """
        self.time_step = time_step
        self.highest_tweet_id = highest_tweet_id
        self.highest_note_id = highest_note_id
        self.highest_rating_id = highest_rating_id
        self.tweets_read_record[time_step] = set()
        self.tweets_posted[time_step] = set()
        self.retweet_record[time_step] = set()
        self.note_posted[time_step] = set()
        self.tweets_up_voted[time_step] = set()
        self.tweets_down_voted[time_step] = set()
        self.users_agreed_with[time_step] = set()
        self.users_disagreed_with[time_step] = set()

    def post_tweet(self):
        """
        Post a Tweet.
        :return: The newly posted Tweet if posted; None if not.
        :rtype: Tweet.
        """
        if random.uniform(0, 1) >= self.post_tweet_probability:
            return None

        # Each Tweet has 3 aspects.
        aspects = random.sample(range(1, 101), 3)
        random.shuffle(aspects)
        aspect_1 = aspects.pop(0)
        aspect_2 = aspects.pop(0)
        aspect_3 = aspects.pop(0)

        # Content of the Tweet.
        if aspect_1 in self.verified_information:
            content_most_important_aspect = (aspect_1, 0)
        elif aspect_1 in self.unverified_information:
            content_most_important_aspect = (aspect_1, self.unverified_information[aspect_1])
        else:
            content_most_important_aspect = (aspect_1, random.choice([0, 1]))

        if aspect_2 in self.verified_information:
            content_less_important_aspect = (aspect_2, 0)
        elif aspect_2 in self.unverified_information:
            content_less_important_aspect = (aspect_2, self.unverified_information[aspect_2])
        else:
            content_less_important_aspect = (aspect_2, random.choice([0, 1]))

        if aspect_3 in self.verified_information:
            content_least_important_aspect = (aspect_3, 0)
        elif aspect_3 in self.unverified_information:
            content_least_important_aspect = (aspect_3, self.unverified_information[aspect_3])
        else:
            content_least_important_aspect = (aspect_3, random.choice([0, 1]))
        opinion = random.normalvariate(self.opinion, 0.1)
        while opinion < 0 or opinion > 1:
            opinion = random.normalvariate(self.opinion, 0.1)
        new_tweet = Tweet(tweet_id="%s_%d" % (self.current_run, self.highest_tweet_id),
                          create_time=self.time_step,
                          publisher=self,
                          opinion=opinion,
                          content_most_important_aspect=content_most_important_aspect,
                          content_less_important_aspect=content_less_important_aspect,
                          content_least_important_aspect=content_least_important_aspect)
        self.highest_tweet_id += 1
        self.tweets_posted[self.time_step].add(new_tweet)
        print("    [%s Time Step %d] User %s posts Tweet %s" %
              (self.current_run, self.time_step, self.u_id, new_tweet.tweetId))
        return new_tweet

    def read_tweets_and_notes(self, time_line):
        """
        Read the time line, update knowledge, and make decisions about verification, voting, writing notes, and sharing.

        :param list[Tweet] time_line: The list of Tweets to read.
        :return: The list of notes written, highest available note id and the highest available rating id.
        :rtype: list[Note], int, int
        """
        notes = []
        for tweet in time_line:
            # Record this read.
            if self.time_step not in tweet.read_record.keys():
                tweet.read_record[self.time_step] = 0
            tweet.read_record[self.time_step] += 1
            # Every time this user reads a Tweet, she/he will be influenced more or less.
            self.opinion_influenced_by_tweet(tweet)
            if abs(self.opinion - tweet.opinion) < self.opinion_threshold:
                self.users_agreed_with[self.time_step].add(tweet.publisher)
            else:
                self.users_disagreed_with[self.time_step].add(tweet.publisher)

            verification_probability, verification_topic = self.verification_probability(tweet)
            # Verify the content.
            if random.random() < verification_probability:
                misleading = self.verify_content(tweet, verification_topic)
            # Judge the content with own opinion.
            else:
                misleading = self.judge_content(tweet)

            if not misleading:
                self.vote_for_tweet(tweet)
                self.retweet(tweet)
            else:
                if abs(tweet.opinion - self.opinion) <= self.opinion_threshold:
                    if self.malicious or random.choice([True, False]):
                        self.retweet(tweet)
                    else:
                        self.vote_against_tweet(tweet)
                        # The probability of writing a note.
                        if random.choice([True, False]):
                            if verification_topic in self.verified_information:
                                note = self.write_note(tweet, verification_topic, 0)
                                notes.append(note)
                            elif verification_topic in self.unverified_information:
                                note = self.write_note(tweet, verification_topic,
                                                       self.unverified_information[verification_topic])
                                notes.append(note)
                else:
                    self.vote_against_tweet(tweet)
                    # The probability of writing a note.
                    if random.choice([True, False]):
                        if verification_topic in self.verified_information:
                            note = self.write_note(tweet, verification_topic, 0)
                            notes.append(note)
                        elif verification_topic in self.unverified_information:
                            note = self.write_note(tweet, verification_topic,
                                                   self.unverified_information[verification_topic])
                            notes.append(note)

        return notes, self.highest_note_id, self.highest_rating_id

    def verification_probability(self, tweet: Tweet):
        """
        Calculate the probability of verifying the content of the given Tweet. It is determined by this user's discreet
        level, the Tweet's up vote numbers (which influence the perceived source credibility), and the notes. The user's
        opinion is also influenced in this function.

        :param Tweet tweet: The Tweet.
        :return: The probability, and the topic on which this user could verify.
        :rtype: tuple[float, int]
        """
        p_v = self.discreet_level

        # The small opinion difference would decrease the willing of fact-checking.
        if abs(self.opinion - tweet.opinion) <= self.opinion_threshold:
            p_v -= 0.3

        # The up vote number increases the perceived credibility of the information source, thus decreases the
        # probability of verification.
        up_vote_num = tweet.get_up_vote_num(self.time_step)
        if up_vote_num >= 20:
            p_v -= (0.075 + 0.075 * self.up_vote_effect)
        elif up_vote_num >= 10:
            p_v -= (0.05 + 0.05 * self.up_vote_effect)
        elif up_vote_num >= 5:
            p_v -= (0.025 + 0.025 * self.up_vote_effect)

        # The note shown increases the probability of verification because it nudges user to think twice.
        verification_probability_change, verification_topic = self.read_notes(tweet)
        p_v += verification_topic

        p_v = 0 if p_v < 0 else p_v
        p_v = 1 if p_v > 1 else p_v

        # The malicious user will not verification, she/he will only judge based on her/his opinion.
        if self.malicious:
            return 0, verification_topic
        return p_v, verification_topic

    def opinion_influenced_by_tweet(self, tweet: Tweet):
        """
        When reading the Tweet, the user's opinion will be influence by it.

        :param Tweet tweet: The Tweet this user reads.
        """
        # Malicious users will not be influenced.
        if self.malicious:
            return
        weight = 0.05 * (1 - 2 * abs(self.opinion - tweet.opinion))
        change = weight * (tweet.opinion - self.opinion)
        self.opinion += change
        self.opinion = 0 if self.opinion < 0 else self.opinion
        self.opinion = 1 if self.opinion > 1 else self.opinion

        self.tweets_read_record[self.time_step].add(tweet)

    def read_notes(self, tweet: Tweet):
        """
        Read the notes under the given Tweet, update ideas, affect verification probability and topic to check.

        :param Tweet tweet: The given Tweet.
        :return: The change in verification probability, and the topic to check.
        :rtype: tuple[float, int]
        """
        # There is a note saying the tweet is misleading and currently rated as helpful.
        if tweet.shown_note is not None:
            verification_aspect = tweet.shown_note.content[0]
            agree_with_shown_note = self.read_note(tweet.shown_note)
            if agree_with_shown_note < 2:
                # Randomly read at most three other notes.
                for note in tweet.get_random_not_showing_notes(verification_aspect):
                    self.read_note(note)
                probability_change = random.uniform(0.2, 0.4)
            else:
                probability_change = 0
        # There is no helpful note shown.
        else:
            # There are notes that are not marked as helpful.
            if tweet.notes:
                suspicious_aspects = dict()
                for note in tweet.get_random_not_showing_notes(-1):
                    agree_with_note = self.read_note(note)
                    if agree_with_note < 2:
                        if note.content[0] not in suspicious_aspects.keys():
                            suspicious_aspects[note.content[0]] = 1
                        else:
                            suspicious_aspects[note.content[0]] += 1
                if suspicious_aspects:
                    verification_aspect = -1
                    suspicious_degree = 0
                    for topic in suspicious_aspects:
                        if suspicious_aspects[topic] > suspicious_degree:
                            verification_aspect = topic
                            suspicious_degree = suspicious_aspects[topic]
                    if self.treatment != 0:
                        probability_change = random.uniform(0.2, 0.4)
                    else:
                        probability_change = random.uniform(0.1, 0.2)
                else:
                    verification_aspect = tweet.randomly_select_an_aspect()
                    probability_change = 0
            # There is no notes under this Tweet.
            else:
                verification_aspect = tweet.randomly_select_an_aspect()
                probability_change = 0
        return probability_change, verification_aspect

    def read_note(self, note: Note):
        """
        Read the note, opinion being influenced by it, and rate the note.

        :param Note note: The note to read.
        :return: Whether this user agrees with the note. 2: agree; 1: not sure; 0: not agree.
        :rtype: int
        """
        self.opinion_influenced_by_note(note)
        if note.content[0] in self.verified_information:
            if note.content[1] == 0:
                self.rate_note(note, 2)
                return 2
            else:
                self.rate_note(note, 0)
                return 0
        elif note.content[0] in self.unverified_information:
            if self.unverified_information[note.content[0]] == note.content[1]:
                self.rate_note(note, 2)
                return 2
            else:
                # Has been persuaded, change belief.
                if random.choice([True, False]):
                    self.rate_note(note, 1)
                    self.unverified_information[note.content[0]] = note.content[1]
                    return 1
                # Has not been persuaded.
                else:
                    self.rate_note(note, 0)
                    return 0
        else:
            self.rate_note(note, 1)
            self.unverified_information[note.content[0]] = note.content[1]
            return 1

    def opinion_influenced_by_note(self, note: Note):
        """
        When reading the note, the user's opinion will be influence by the note.

        :param Note note: The note this user reads.
        """
        # Malicious users will not be influenced.
        if self.malicious:
            return
        weight = 0.5 * (1 - 2 * abs(self.opinion - note.opinion))
        change = weight * (note.opinion - self.opinion)
        self.opinion += change
        self.opinion = 0 if self.opinion < 0 else self.opinion
        self.opinion = 1 if self.opinion > 1 else self.opinion

    def verify_content(self, tweet: Tweet, information_to_check: int):
        """
        Verify the content of the Tweet, trying to find out if there is factual error. This user will learn the correct
        knowledge about the corresponding topic after verification.

        :param Tweet tweet: The Tweet to check.
        :param int information_to_check: The topic that this user wants to check.
        :return: Whether there is misleading content.
        :rtype: bool
        """
        if information_to_check is None:
            information_to_check = tweet.content_most_important_aspect[0]
            content = tweet.content_most_important_aspect[1]
        else:
            if information_to_check == tweet.content_most_important_aspect[0]:
                content = tweet.content_most_important_aspect[1]
            elif information_to_check == tweet.content_less_important_aspect[0]:
                content = tweet.content_less_important_aspect[1]
            elif information_to_check == tweet.content_least_important_aspect[0]:
                content = tweet.content_least_important_aspect[1]
            # If the topic to check is not relevant to the Tweet, check the Tweet's content about the most important
            # topic.
            else:
                information_to_check = tweet.content_most_important_aspect[0]
                content = tweet.content_most_important_aspect[1]

        # Whether there is misleading content. No matter whether the user knows the knowledge before, as long as she/he
        # verifies, she/he will get the correct information (i.e., knowledge).
        if content != 0:
            content_misleading = True
        else:
            content_misleading = False

        # Update this user's belief on the information piece.
        if information_to_check in self.unverified_information:
            del self.unverified_information[information_to_check]
        self.verified_information.add(information_to_check)

        return content_misleading

    def judge_content(self, tweet: Tweet):
        """
        Judge the content based on this user's intuition. Randomly select a topic to judge. The user will also read
        notes if there are some. The user will have a higher chance to find the misinformation in the Tweets catering
        her/his opinion.

        :param Tweet tweet: The Tweet to check.
        :return: Whether there is misleading content.
        :rtype: bool
        """
        # Judgement from opinion.
        if abs(tweet.opinion - self.opinion) <= self.opinion_threshold:
            j_o = 1
        else:
            j_o = -1

        # Judgement from knowledge.
        choice = random.choice([1, 2, 3])
        if choice == 1:
            information_to_check = tweet.content_most_important_aspect[0]
            content = tweet.content_most_important_aspect[1]
        elif choice == 2:
            information_to_check = tweet.content_less_important_aspect[0]
            content = tweet.content_less_important_aspect[1]
        else:
            information_to_check = tweet.content_least_important_aspect[0]
            content = tweet.content_least_important_aspect[1]
        if information_to_check in self.verified_information:
            j_k = 1 if content == 0 else -1
        elif information_to_check in self.unverified_information:
            j_k = 1 if content == self.unverified_information[information_to_check] else -1
        else:
            j_k = 1 if random.choice([True, False]) else -1

        # Final judgment.
        # The decision proportion captures all the latent features that can influence the position of two kinds of
        # judgements in the  final judgement.
        decision_proportion = random.uniform(0, 1)
        # The malicious user's decision is solely based on the opinion judgement.
        if self.malicious:
            decision_proportion = 1
        final_decision = decision_proportion * j_o + (1 - decision_proportion) * j_k
        if final_decision >= 0:
            content_misleading = False
        else:
            content_misleading = True

        return content_misleading

    def vote_for_tweet(self, tweet):
        """
        Record this user's like to the given Tweet.

        :param Tweet tweet: The Tweet this user reads and likes.
        """
        # Record in this user, won't duplicate.
        recorded = False
        for time_step in self.tweets_up_voted:
            if tweet in self.tweets_up_voted[time_step]:
                recorded = True
                break
        if not recorded:
            self.tweets_up_voted[self.time_step].add(tweet)
        # Cancel this user's previous dislike.
        for time_step in self.tweets_down_voted:
            if tweet in self.tweets_down_voted[time_step]:
                self.tweets_down_voted[time_step].remove(tweet)

        # Record in the Tweet.
        recorded = False
        for time_step in tweet.up_vote_record:
            if self in tweet.up_vote_record[time_step]:
                recorded = True
                break
        if not recorded:
            if self.time_step not in tweet.up_vote_record.keys():
                tweet.up_vote_record[self.time_step] = set()
            tweet.up_vote_record[self.time_step].add(self)
        # Cancel the Tweet's previous dislike record given by this user.
        for time_step in tweet.down_vote_record:
            if self in tweet.down_vote_record[time_step]:
                tweet.down_vote_record[time_step].remove(self)

    def vote_against_tweet(self, tweet):
        """
        Record this user's dislike to the given Tweet.

        :param Tweet tweet: The Tweet this user reads and dislike.
        """
        # Record in this user, won't duplicate.
        recorded = False
        for time_step in self.tweets_down_voted:
            if tweet in self.tweets_down_voted[time_step]:
                recorded = True
                break
        if not recorded:
            self.tweets_down_voted[self.time_step].add(tweet)
        # Cancel this user's previous like.
        for time_step in self.tweets_up_voted:
            if tweet in self.tweets_up_voted[time_step]:
                self.tweets_up_voted[time_step].remove(tweet)

        # Record in the Tweet.
        recorded = False
        for time_step in tweet.down_vote_record:
            if self in tweet.down_vote_record[time_step]:
                recorded = True
                break
        if not recorded:
            if self.time_step not in tweet.down_vote_record.keys():
                tweet.down_vote_record[self.time_step] = set()
            tweet.down_vote_record[self.time_step].add(self)
        # Cancel the Tweet's previous like record given by this user.
        for time_step in tweet.up_vote_record:
            if self in tweet.up_vote_record[time_step]:
                tweet.up_vote_record[time_step].remove(self)

    def has_read_tweet(self, tweet):
        """
        Whether this user has read the given Tweet.

        :param Tweet tweet:
        :return: True/False.
        :rtype: bool
        """
        for time_step in self.tweets_read_record:
            for tweet_read in self.tweets_read_record[time_step]:
                if tweet_read == tweet:
                    return True
        return False

    def has_recently_retweeted_tweet(self, tweet: Tweet):
        """
        Whether this user has retweeted the given Tweet recently.

        :param Tweet tweet: The given Tweet.
        :return: True/False.
        :rtype: bool
        """
        for time_step in self.retweet_record:
            if (self.time_step - time_step) <= 5:
                for retweeted_tweet in self.retweet_record[time_step]:
                    if retweeted_tweet == tweet:
                        return True
        return False

    def has_written_note(self, tweet: Tweet, topic: int):
        """
        Whether this user has written a note on the given Tweet about the given topic.

        :param Tweet tweet: The given Tweet.
        :param int topic: The given topic.
        :return: True/False, the previous written note/None.
        :rtype: bool
        """
        for time_step in self.note_posted:
            for note in self.note_posted[time_step]:
                if note.publisher == self and note.tweet == tweet and note.content[0] == topic:
                    return True, note
        return False, None

    def write_note(self, tweet: Tweet, aspect: int, content: int):
        """
        Write debunking note for the given Tweet. User will delete the previous note on same Tweet, about same topic,
        expressing different content.

        :param Tweet tweet: The given Tweet.
        :param int aspect: The aspect on which the note is written.
        :param int content: The idea about the aspect.
        :return: The newly posted note.
        :rtype: Note
        """
        written, old_note = self.has_written_note(tweet, aspect)
        if not written:
            opinion = random.normalvariate(self.opinion, 0.1)
            while opinion < 0 or opinion > 1:
                opinion = random.normalvariate(self.opinion, 0.1)
            new_note = Note(note_id="%s_%d" % (self.current_run, self.highest_note_id),
                            tweet=tweet,
                            publisher=self,
                            create_time=self.time_step,
                            opinion=opinion,
                            content=(aspect, content))
            if self.time_step not in tweet.notes.keys():
                tweet.notes[self.time_step] = set()
            tweet.notes[self.time_step].add(new_note)
            self.note_posted[self.time_step].add(new_note)
            self.highest_note_id += 1
            print("    [%s Time Step %d] User %s writes Note %s to Tweet %s." %
                  (self.current_run, self.time_step, self.u_id, new_note.note_id, tweet.tweetId))
        else:
            if old_note.content[1] == content:
                return None
            else:
                # Delete the previous written note.
                old_note_deleted = False
                for time_step in self.note_posted:
                    for note in self.note_posted[time_step]:
                        if note.publisher == self and note.tweet == tweet and note.content[0] == aspect:
                            self.note_posted[time_step].remove(note)
                            old_note_deleted = True
                            break
                    if old_note_deleted:
                        break
                old_note_deleted = False
                for time_step in tweet.notes:
                    for note in tweet.notes[time_step]:
                        if note == old_note:
                            tweet.notes[time_step].remove(note)
                            old_note_deleted = True
                            break
                    if old_note_deleted:
                        break

                opinion = random.normalvariate(self.opinion, 0.1)
                while opinion < 0 or opinion > 1:
                    opinion = random.normalvariate(self.opinion, 0.1)
                new_note = Note(note_id="%s_%d" % (self.current_run, self.highest_note_id),
                                tweet=tweet,
                                publisher=self,
                                create_time=self.time_step,
                                opinion=opinion,
                                content=(aspect, content))
                if self.time_step not in tweet.notes.keys():
                    tweet.notes[self.time_step] = set()
                tweet.notes[self.time_step].add(new_note)
                self.note_posted[self.time_step].add(new_note)
                self.highest_note_id += 1
                print("    [%s Time Step %d] User %s writes Note %s to Tweet %s." %
                      (self.current_run, self.time_step, self.u_id, new_note.note_id, tweet.tweetId))
        return new_note

    def retweet(self, tweet):
        """
        The decision of retweeting the Tweet this user has read.

        :param Tweet tweet: The Tweet on which this decision will be made.
        """
        if self.time_step not in tweet.retweet_record.keys():
            tweet.retweet_record[self.time_step] = set()
        self.retweet_record[self.time_step].add(tweet)
        tweet.retweet_record[self.time_step].add(self)
        # print("    [%s Time Step %d] User %s retweets Tweet %s." %
        #       (self.current_run, self.time_step, self.u_id, tweet.tweetId))

    def rate_note(self, note: Note, helpful: int):
        """
        Rate the given note as helpful or not.

        :param Note note: Given note.
        :param int helpful: Whether this note is helpful. 0: not helpful; 1: somewhat helpful, 2: helpful
        """
        if self.treatment == 0:
            return
        if self.time_step not in note.ratings.keys():
            note.ratings[self.time_step] = set()
        new_rating = Rating(self.highest_rating_id, self, note, self.time_step, helpful)
        self.highest_rating_id += 1
        note.ratings[self.time_step].add(new_rating)
        if helpful == 2:
            helpful_str = "Helpful"
        elif helpful == 1:
            helpful_str = "Somewhat helpful"
        else:
            helpful_str = "Not helpful"
        print("    [%s Time Step %d] User %s rates Note %s as %s." %
              (self.current_run, self.time_step, self.u_id, note.note_id, helpful_str))

    def make_decision_in_social_network_relationships(self):
        """
        According to the previous interactions with other users, determine which users will be followed/unfollowed from
        now on.

        :return: The list of users this user will follow, and the list of users this user will unfollow.
        :rtype: tuple[list[User], list[User]]
        """
        # How many times of agreement each user gets from this user.
        # <key, value> = <User, times of agreement by this user>.
        user_agreement = dict()
        for time_step in range(self.time_step, self.time_step - self.network_evolution_period - 1, -1):
            if time_step in self.users_agreed_with:
                for user in self.users_agreed_with[time_step]:
                    if user in user_agreement:
                        user_agreement[user] += 1
                    else:
                        user_agreement[user] = 1

        # How many times of disagreement each user gets from this user.
        # <key, value> = <User, times of disagreement by this user>.
        user_disagreement = dict()
        for time_step in range(self.time_step, self.time_step - self.network_evolution_period - 1, -1):
            if time_step in self.users_disagreed_with:
                for user in self.users_disagreed_with[time_step]:
                    if user in user_disagreement:
                        user_disagreement[user] += 1
                    else:
                        user_disagreement[user] = 1

        # The users who get more times of agreement than the threshold.
        to_follow_unfiltered = []
        for user in user_agreement:
            if user_agreement[user] / self.network_evolution_period > self.network_evolution_threshold:
                to_follow_unfiltered.append(user)

        # The users who get more times of disagreement than the threshold.
        to_unfollow_unfiltered = []
        for user in user_disagreement:
            if user_disagreement[user] / self.network_evolution_period > self.network_evolution_threshold:
                to_unfollow_unfiltered.append(user)

        # Filter the users who exist in both the ones that should be followed and the ones that should be unfollowed.
        to_follow = []
        for user in to_follow_unfiltered:
            if user not in to_unfollow_unfiltered:
                to_follow.append(user)
        to_unfollow = []
        for user in to_unfollow_unfiltered:
            if user not in to_follow_unfiltered:
                to_unfollow.append(user)

        # Follow and unfollow the users in the filtered lists.
        for user in to_follow:
            self.follow(user)
        for user in to_unfollow:
            self.unfollow(user)
        return to_follow, to_unfollow

    def record_knowledge_change(self):
        """
        Record the knowledge change in this time step.
        """
        self.verified_topic_record[self.time_step] = self.verified_information
        self.unverified_topic_record[self.time_step] = self.unverified_information.keys()

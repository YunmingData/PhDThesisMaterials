# -*- coding: UTF-8 -*-
"""
Project: PhD_Paper3
File: model.py
Author: 王晨龙 Chenlong Wang
Date & Time of Creation: 2022-03-10 16:27 
"""
from tweet import Tweet
from user import User
from networkx import DiGraph
import random
import pandas as pd
from score_notes_callable import call_bird_watch_code
import os


class SimulationModel:
    def __init__(self, sub_model: str, repetition: int, treatment: int,
                 discreet_level: float, up_vote_effect: int, echo_chamber_degree: float,
                 note_ranking_interval: int, post_tweet_probability: float, read_length: int,
                 network_evolution_period: int, network_evolution_threshold: float, verified_num: int,
                 unverified_num: int, opinion_threshold: float, malicious_proportion: float):
        """
        Constructor of the ABM.

        :param str sub_model: Name of the sub model
        :param int repetition: Which time of running the sub model.

        :param int treatment: Whether the Birdwatch mechanism (note rating and calculation) is on. If it is on, which
        kind of mechanism is on. 0: no Birdwatch, just normal comments; 1: Birdwatch on; 2: Birdwatch on with reminding
        system.

        :param float discreet_level: The basic probability of verification.
        :param int up_vote_effect: How strong the up-votes' effect is. {1, 2, 3}.
        :param float echo_chamber_degree: The degree of polarisation in terms of user network, which is also the ratio
        of inter cluster density to intra cluster density. (0, 1].

        :param int note_ranking_interval: The interval of time steps between two times to run the Birdwatch note rating
        calculation algorithm.
        :param float post_tweet_probability: The probability for each user to post a Tweet in each time step. (0, 1).
        :param int read_length: At most, how many Tweets a user can read in one time step.

        :param int network_evolution_period: The threshold of user's network evolution. It means how many time steps'
         interactions will this user take into consideration in following/unfollowing decision. The longer this
         threshold is, the less frequently this user is likely to change her/his social network structure. It is 0 when
         the user will never change her/his social network structure.
         :param float network_evolution_threshold: The threshold of user's network evolution. It means the proportion of
        agree/disagree from specific user in the period of time steps that leads this user to follow/unfollow the user.
        :param int verified_num: In how many aspects a user has verified knowledge.
        :param int unverified_num: In how many aspects a user has unverified information. The unverified information
        does not necessary to be wrong.
        :param float opinion_threshold: The threshold of having different interactions towards the opinion each user
        reads. Usually it is set as 0.5.
        :param float malicious_proportion: The proportion of malicious users in the crowd.
        """
        # =========================================== Basic Configurations =========================================== #
        # The name of the sub model.
        self.sub_model = sub_model
        # This is which time of running the sub_model
        self.repetition = repetition
        # Whether the Birdwatch mechanism (note rating and calculation) is on.
        self.treatment = treatment
        # The probability for each user to post a Tweet in each time step. (0, 1).
        self.post_tweet_probability = post_tweet_probability
        # The threshold of user's network evolution. It means how many time steps' interactions will this user take into
        # consideration in following/unfollowing decision. The longer this threshold is, the less frequently this user
        # is likely to change her/his social network structure. It is 0 when the user will never change her/his social
        # network structure.
        self.network_evolution_period = network_evolution_period
        # The threshold of user's network evolution. It means the proportion of agree/disagree from specific user in the
        # period of time steps that leads this user to follow/unfollow the user.
        self.network_evolution_threshold = network_evolution_threshold
        # The identification of this run.
        self.current_run = "%s_%d" % (self.sub_model, self.repetition)
        # All the topics in the world.
        self.topics = range(1, 101)
        # ============================================= User Attributes ============================================== #
        # In total, how many users are there in the model.
        self.user_total_num = 3000
        # The basic probability of verification.
        self.discreet_level = discreet_level
        # How strong the up-votes' effect is. {1, 2, 3}
        self.up_vote_effect = up_vote_effect
        # The degree of echo chamber in terms of user network, which is also the ratio of inter-cluster edge number to
        # the whole edge number . (0, 1].
        self.echo_chamber_degree = echo_chamber_degree
        # The user network, which is a directed graph. If A is following B, then there will be an edge: A -> B.
        self.user_network = DiGraph()
        # The density of network for the users as whole.
        self.network_density = 0.01
        # On average, in how many aspects a user have verified knowledge.
        self.verified_num = verified_num
        # In how many aspects a user has unverified information. The unverified information does not necessary to be
        # wrong.
        self.unverified_num = unverified_num
        # The threshold of having different interactions towards the opinion each user reads. Usually it is set as 0.5.
        self.opinion_threshold = opinion_threshold
        # The proportion of malicious users in the crowd.
        self.malicious_proportion = malicious_proportion
        # ================================================= Model Run ================================================ #
        # The interval of time steps between two times to run the Birdwatch note rating calculation algorithm.
        self.note_ranking_interval = note_ranking_interval
        # How many time-steps are needed for the model to run.
        self.run_time = 10
        # At most, how many Tweets a user can read in one time step.
        self.read_length = read_length
        # The Tweets in a list.
        self.tweets = []
        # The Notes in a list.
        self.notes = []
        # Highest available Tweet ID.
        self.highest_tweet_id = 0
        # Highest available Note ID.
        self.highest_note_id = 0
        # Highest available Rating ID.
        self.highest_rating_id = 0
        # ================================================== Output ================================================== #
        # The directory of the output folder.
        if not os.path.exists(os.path.abspath(os.path.dirname(os.getcwd())) + os.sep + "output" + os.sep):
            os.mkdir(os.path.abspath(os.path.dirname(os.getcwd())) + os.sep + "output" + os.sep)
        self.output_dir = os.path.abspath(os.path.dirname(os.getcwd())) + os.sep + "output" + os.sep + self.sub_model \
                          + os.sep
        if not os.path.exists(self.output_dir):
            os.mkdir(self.output_dir)

    def initialise(self):
        """
        The initialisation of the ABM.
        """
        print("""
        # ==================== #
        | Initialising         |
        |    Model: %s         |
        |    Repetition: %d    |
        # ==================== #
                """ % (self.sub_model, self.repetition))
        # Clean intermediary files.
        if os.path.exists(os.getcwd() + os.sep + "notes-00000.tsv"):
            os.remove(os.getcwd() + os.sep + "notes-00000.tsv")
        if os.path.exists(os.getcwd() + os.sep + "ratings-00000.tsv"):
            os.remove(os.getcwd() + os.sep + "ratings-00000.tsv")
        if os.path.exists(os.getcwd() + os.sep + "scoredNotes.tsv"):
            os.remove(os.getcwd() + os.sep + "scoredNotes.tsv")

        # Create user network.
        positive_users, negative_users = self.generate_users()
        self.generate_user_network_with_echo_chambers(positive_users, negative_users)

    def generate_users(self):
        """
        Generate users, assigning attributes.

        :return: The users who have positive biases and the ones who have negative biases.
        :rtype: tuple[list[User], list[User]]
        """
        print("Generate users.")
        positive_users = []
        negative_users = []
        # Create the malicious users, who cannot be influenced, and will never change their minds.
        malicious_user_num = round(self.user_total_num * self.malicious_proportion / 2)
        for i in range(malicious_user_num):
            verified_information = []
            unverified_information_list = random.sample(self.topics, self.unverified_num + self.verified_num)
            unverified_information = dict()
            for information in unverified_information_list:
                unverified_information[information] = 1
            opinion = random.normalvariate(0.3, 0.2)
            while opinion > 1 or opinion < 0:
                opinion = random.normalvariate(0.3, 0.2)
            user = User(current_run=self.current_run,
                        u_id="%d_%s" % (i, self.current_run),
                        opinion=opinion,
                        treatment=self.treatment,
                        discreet_level=self.discreet_level,
                        up_vote_effect=self.up_vote_effect,
                        post_tweet_probability=self.post_tweet_probability,
                        network_evolution_period=self.network_evolution_period,
                        network_evolution_threshold=self.network_evolution_threshold,
                        verified_information=set(verified_information),
                        unverified_information=unverified_information,
                        opinion_threshold=self.opinion_threshold,
                        malicious=True)
            self.user_network.add_node(user)
            negative_users.append(user)
        for i in range(malicious_user_num, malicious_user_num+malicious_user_num):
            verified_information = []
            unverified_information_list = random.sample(self.topics, self.unverified_num + self.verified_num)
            unverified_information = dict()
            for information in unverified_information_list:
                unverified_information[information] = 1
            opinion = random.normalvariate(0.8, 0.2)
            while opinion > 1 or opinion < 0:
                opinion = random.normalvariate(0.8, 0.2)
            user = User(current_run=self.current_run,
                        u_id="%d_%s" % (i, self.current_run),
                        opinion=opinion,
                        treatment=self.treatment,
                        discreet_level=self.discreet_level,
                        up_vote_effect=self.up_vote_effect,
                        post_tweet_probability=self.post_tweet_probability,
                        network_evolution_period=self.network_evolution_period,
                        network_evolution_threshold=self.network_evolution_threshold,
                        verified_information=set(verified_information),
                        unverified_information=unverified_information,
                        opinion_threshold=self.opinion_threshold,
                        malicious=True)
            self.user_network.add_node(user)
            positive_users.append(user)

        # Then create the
        mid_index = (self.user_total_num - malicious_user_num*2) // 2 + malicious_user_num*2
        for i in range(malicious_user_num*2, self.user_total_num):
            verified_information = random.sample(self.topics, self.verified_num)
            unverified_information_list = []
            while len(unverified_information_list) < self.unverified_num:
                candidate = random.choice(self.topics)
                if candidate in verified_information:
                    continue
                if candidate in unverified_information_list:
                    continue
                unverified_information_list.append(candidate)
            unverified_information = dict()
            for biased_topic in unverified_information_list:
                if random.choice([True, False]):
                    unverified_information[biased_topic] = 1
                else:
                    unverified_information[biased_topic] = 0
            if 1 <= mid_index:
                opinion = random.normalvariate(0.3, 0.2)
                while opinion > 1 or opinion < 0:
                    opinion = random.normalvariate(0.3, 0.2)
            else:
                opinion = random.normalvariate(0.8, 0.2)
                while opinion > 1 or opinion < 0:
                    opinion = random.normalvariate(0.8, 0.2)
            user = User(current_run=self.current_run,
                        u_id="%d_%s" % (i, self.current_run),
                        opinion=opinion,
                        treatment=self.treatment,
                        discreet_level=self.discreet_level,
                        up_vote_effect=self.up_vote_effect,
                        post_tweet_probability=self.post_tweet_probability,
                        network_evolution_period=self.network_evolution_period,
                        network_evolution_threshold=self.network_evolution_threshold,
                        verified_information=set(verified_information),
                        unverified_information=unverified_information,
                        opinion_threshold=self.opinion_threshold,
                        malicious=False)
            self.user_network.add_node(user)
            if i <= mid_index:
                negative_users.append(user)
            else:
                positive_users.append(user)
        print("Users Created.")
        return positive_users, negative_users

    def generate_user_network_with_echo_chambers(self, positive_users: list, negative_users: list):
        """
        Generate the user network. There will be two clusters with different opinion preferences, simulating the echo
        chamber phenomenon in reality.

        :param list[User] positive_users: The users holding the opinions with higher values.
        :param list[User] negative_users: The users holding the opinions with lower values.
        """
        print("Generating user network.")
        total_user_num = len(list(self.user_network.nodes))
        max_edge_number = total_user_num * (total_user_num - 1) / 2
        total_edge_number = round(max_edge_number * self.network_density)
        inter_cluster_edge_num = round(total_edge_number * self.echo_chamber_degree)
        intra_cluster_edge_num = total_edge_number - inter_cluster_edge_num
        positive_cluster_edge_num = round(intra_cluster_edge_num / 2)
        negative_cluster_edge_num = intra_cluster_edge_num - positive_cluster_edge_num

        # In each group, users are densely connected.
        print("    Generating random network in the first cluster.")
        self.generate_random_network(positive_users, positive_cluster_edge_num)
        print("    Generating random network in the second cluster.")
        self.generate_random_network(negative_users, negative_cluster_edge_num)

        # Between each group, users are sparsely connected.
        print("    Generating inter-cluster edges.")
        inter_edge_count = 0
        while inter_edge_count < inter_cluster_edge_num:
            user_a: User
            user_b: User
            if random.choice([True, False]):
                user_a = random.choice(positive_users)
                user_b = random.choice(negative_users)
            else:
                user_a = random.choice(negative_users)
                user_b = random.choice(positive_users)
            if self.user_network.has_edge(user_a, user_b):
                continue
            self.user_network.add_edge(user_a, user_b)
            user_a.follow(user_b)
            inter_edge_count += 1
            print("    %d/%d inter cluster edges established." % (inter_edge_count, inter_cluster_edge_num))

    def generate_random_network(self, user_list: list[User], edge_number: int):
        """
        Generate a random network among the given users with a given edge number.

        :param list[User] user_list: The list of users among whom the network is established.
        :param int edge_number: The number of edges needed.
        """
        edge_established = 0
        while edge_established < edge_number:
            user_a: User
            user_b: User
            (user_a, user_b) = random.sample(user_list, 2)
            if self.user_network.has_edge(user_a, user_b):
                continue
            self.user_network.add_edge(user_a, user_b)
            user_a.follow(user_b)
            edge_established += 1
            print("        %d/%d intra-cluster edges established." % (edge_established, edge_number))

    def run(self):
        """
        Run the model.
        """
        print("""
# ==================== #
| Start Running        |
|    Model: %s         |
|    Repetition: %d    |
# ==================== #
        """ % (self.sub_model, self.repetition))
        for time_step in range(1, self.run_time+1):
            print("# ============================== Time Step %d in %s ============================== #"
                  % (time_step, self.current_run))
            user_list = list(self.user_network.nodes)
            random.shuffle(user_list)
            for user in user_list:
                user.preparation(time_step, self.highest_tweet_id, self.highest_note_id, self.highest_rating_id)

                new_tweet = user.post_tweet()
                if new_tweet is not None:
                    self.tweets.append(new_tweet)
                    self.highest_tweet_id += 1

                time_line = self.forming_timeline(user, time_step)

                notes, self.highest_note_id, self.highest_rating_id = user.read_tweets_and_notes(time_line)
                for new_note in notes:
                    if new_note is not None:
                        self.notes.append(new_note)

                if self.treatment == 2:
                    tweets_to_reread = self.reminder_system(user)
                    notes, self.highest_note_id, self.highest_rating_id = user.read_tweets_and_notes(tweets_to_reread)
                    for new_note in notes:
                        if new_note is not None:
                            self.notes.append(new_note)

                # If the it is a dynamic social network, the user make the decisions of following and unfollowing.
                if self.network_evolution_period > 0:
                    to_follow, to_unfollow = user.make_decision_in_social_network_relationships()
                    for user_a in to_follow:
                        if not self.user_network.has_edge(user, user_a):
                            self.user_network.add_edge(user, user_a)
                    for user_b in to_unfollow:
                        if self.user_network.has_edge(user, user_b):
                            self.user_network.remove_edge(user, user_b)
                user.record_knowledge_change()

            # There is a periodic intervals between each two calculations.
            if time_step % self.note_ranking_interval == 0:
                if self.treatment != 0:
                    self.utilise_birdwatch_code()
                    print("[%s Time Step %d] Birdwatch code finished." % (self.current_run, time_step))
            self.output_dependent_variables(time_step)
            print("[%s Time Step %d] Dependent variables written." % (self.current_run, time_step))

    def forming_timeline(self, user, time_step):
        """
        Form a timeline for the given user in the given time step with Tweets posted or retweeted in the recent 5 time
        steps. At most 10 Tweets.

        :param User user: The given user.
        :param int time_step: The time step.
        :return: A list of Tweets.
        :rtype: list[Tweet]
        """
        users_being_followed = self.following_users(user)

        # First consider the Tweets recently posted by friends.
        tweets_recently_posted_by_friends = set()
        for tweet in self.tweets:
            if tweet.was_posted_by(user):
                continue
            for user_A in users_being_followed:
                if tweet.was_recently_posted_by(user_A, time_step):
                    tweets_recently_posted_by_friends.add(tweet)
                    break
        if len(tweets_recently_posted_by_friends) >= self.read_length:
            return random.sample(list(tweets_recently_posted_by_friends), self.read_length)

        # If not enough, consider the Tweets recently shared by friends.
        needed = self.read_length - len(tweets_recently_posted_by_friends)
        tweets_recently_shared_by_friends = set()
        for tweet in self.tweets:
            if tweet.was_posted_by(user):
                continue
            if tweet in tweets_recently_posted_by_friends:
                continue
            for user_A in users_being_followed:
                if tweet.was_recently_retweeted_by(user_A, time_step):
                    tweets_recently_shared_by_friends.add(tweet)
                    break
        if len(tweets_recently_shared_by_friends) >= needed:
            return list(tweets_recently_posted_by_friends) + \
                   random.sample(list(tweets_recently_shared_by_friends), needed)

        # If not enough, consider the Tweets posted by friends long ago.
        needed = self.read_length - \
                 len(tweets_recently_posted_by_friends) - \
                 len(tweets_recently_shared_by_friends)
        tweets_posted_by_friends_long_ago = set()
        for tweet in self.tweets:
            if tweet.was_posted_by(user):
                continue
            if tweet in tweets_recently_posted_by_friends:
                continue
            if tweet in tweets_recently_shared_by_friends:
                continue
            for user_A in users_being_followed:
                if tweet.was_posted_by(user_A):
                    tweets_posted_by_friends_long_ago.add(tweet)
                    break
        if len(tweets_posted_by_friends_long_ago) >= needed:
            return list(tweets_recently_posted_by_friends) + \
                   list(tweets_recently_shared_by_friends) + \
                   random.sample(list(tweets_posted_by_friends_long_ago), needed)

        # If not enough, consider the Tweets shared by friends long ago.
        needed = self.read_length - \
                 len(tweets_recently_posted_by_friends) - \
                 len(tweets_recently_shared_by_friends) - \
                 len(tweets_posted_by_friends_long_ago)
        tweets_shared_by_friends_long_ago = set()
        for tweet in self.tweets:
            if tweet.was_posted_by(user):
                continue
            if tweet in tweets_recently_posted_by_friends:
                continue
            if tweet in tweets_recently_shared_by_friends:
                continue
            if tweet in tweets_posted_by_friends_long_ago:
                continue
            for user_A in users_being_followed:
                if tweet.was_retweeted_by(user_A):
                    tweets_shared_by_friends_long_ago.add(tweet)
                    break
        if len(tweets_shared_by_friends_long_ago) >= needed:
            return list(tweets_recently_posted_by_friends) + \
                   list(tweets_recently_shared_by_friends) + \
                   list(tweets_posted_by_friends_long_ago) + \
                   random.sample(list(tweets_shared_by_friends_long_ago), needed)
        else:
            return list(tweets_recently_posted_by_friends) + \
                   list(tweets_recently_shared_by_friends) + \
                   list(tweets_posted_by_friends_long_ago) + \
                   list(tweets_shared_by_friends_long_ago)

    def reminder_system(self, user: User):
        """
        Remind the user about the misleading information she/he voted for. Randomly chose one Tweet each time.

        :param User user: The given user.
        :return: The Tweet that needs to read again, in a list.
        :rtype: list
        """
        # Get the Tweets that have been read and retweeted by the given user in the recent 5 time steps.
        retweeted_tweets = set()
        for tweet in self.tweets:
            if user.has_recently_retweeted_tweet(tweet):
                retweeted_tweets.add(tweet)

        # Get the ones that have shown note.
        candidate = []
        for tweet in retweeted_tweets:
            if tweet.shown_note is not None:
                candidate.append(tweet)
        if len(candidate) > 0:
            chosen_tweet = random.choice(candidate)
            return [chosen_tweet]
        else:
            return []

    def following_users(self, user: User):
        """
        Get the users given user is following.

        :param User user: The given user.
        :return: A list of users followed by this given user.
        :rtype: list[User]
        """
        users_being_followed = []
        for user_A in self.user_network.nodes:
            if self.user_network.has_edge(user, user_A):
                users_being_followed.append(user_A)
        return users_being_followed

    def utilise_birdwatch_code(self):
        """
        Utilise Birdwatch code to calculate the helpfulness of each Note.
        """
        need_calculation = self.write_notes_ratings_to_files()
        if need_calculation:
            call_bird_watch_code()
            self.select_shown_notes()

    def write_notes_ratings_to_files(self):
        """
        Write the notes and ratings into files for Birdwatch code to calculate scoredNotes.

        :return: If there is no notes or no ratings, return False; otherwise, True.
        :rtype: bool
        """
        rating_set = set()
        for note in self.notes:
            for time_step in note.ratings:
                for rating in note.ratings[time_step]:
                    rating_set.add(rating)
        if len(self.notes) == 0 or len(rating_set) == 0:
            return False
        # Fill Note Dataframe.
        note_column_titles = ["noteId", "participantId", "createdAtMillis", "tweetId", "classification", "believable",
                              "harmful", "validationDifficulty", "misleadingOther", "misleadingFactualError",
                              "misleadingManipulatedMedia", "misleadingOutdatedInformation",
                              "misleadingMissingImportantContext", "misleadingUnverifiedClaimAsFact",
                              "misleadingSatire", "notMisleadingOther", "notMisleadingFactuallyCorrect",
                              "notMisleadingOutdatedButNotWhenWritten", "notMisleadingClearlySatire",
                              "notMisleadingPersonalOpinion", "trustworthySources", "summary"]
        note_df = pd.DataFrame(columns=note_column_titles)

        note_ids = []
        participant_ids = []
        created_times = []
        tweet_ids = []
        misleading_others = []
        misleading_factual = []
        not_misleading_others = []
        not_misleading_factual = []
        for note in self.notes:
            note_ids.append(note.note_id)
            participant_ids.append(note.publisher.u_id)
            created_times.append(note.create_time)
            tweet_ids.append(note.tweet.tweetId)
            # If there are not two different tags that are each used by two different raters, then the note’s status
            # label is reverted back to “Needs More Ratings” (this is very rare). -- Birdwatch Note Ranking.
            if random.choice([1, 0]) == 1:
                misleading_others.append(1)
                misleading_factual.append(0)
            else:
                misleading_factual.append(1)
                misleading_others.append(0)
            not_misleading_others.append(0)
            not_misleading_factual.append(0)
        note_df["noteId"] = note_ids
        note_df["participantId"] = participant_ids
        note_df["createdAtMillis"] = created_times
        note_df["tweetId"] = tweet_ids
        note_df["misleadingOther"] = misleading_others
        note_df["misleadingFactualError"] = misleading_factual
        note_df["notMisleadingOther"] = not_misleading_others
        note_df["notMisleadingFactuallyCorrect"] = not_misleading_factual
        note_df["believable"].fillna("BELIEVABLE_BY_MANY", inplace=True)
        note_df["harmful"].fillna("CONSIDERABLE_HARM", inplace=True)
        note_df["validationDifficulty"].fillna("CHALLENGING", inplace=True)
        note_df["summary"].fillna("Summary: %f" % random.random(), inplace=True)
        note_df["classification"].fillna("MISINFORMED_OR_POTENTIALLY_MISLEADING", inplace=True)
        note_df.fillna(0, inplace=True)

        # Fill Rating Dataframe.
        rating_column_titles = ["noteId", "participantId", "createdAtMillis", "version", "agree", "disagree", "helpful",
                                "notHelpful", "helpfulnessLevel", "helpfulOther", "helpfulInformative", "helpfulClear",
                                "helpfulEmpathetic", "helpfulGoodSources", "helpfulUniqueContext",
                                "helpfulAddressesClaim", "helpfulImportantContext", "helpfulUnbiasedLanguage",
                                "notHelpfulOther", "notHelpfulIncorrect", "notHelpfulSourcesMissingOrUnreliable",
                                "notHelpfulOpinionSpeculationOrBias", "notHelpfulMissingKeyPoints",
                                "notHelpfulOutdated", "notHelpfulHardToUnderstand", "notHelpfulArgumentativeOrBiased",
                                "notHelpfulOffTopic", "notHelpfulSpamHarassmentOrAbuse", "notHelpfulIrrelevantSources",
                                "notHelpfulOpinionSpeculation", "notHelpfulNoteNotNeeded"]
        rating_df = pd.DataFrame(columns=rating_column_titles)

        rating_note_ids = []
        rating_participants = []
        rating_times = []
        helpfulness = []
        helpful_others = []
        helpful_informative = []
        not_helpful_others = []
        not_helpful_incorrect = []
        for rating in rating_set:
            rating_note_ids.append(rating.note.note_id)
            rating_participants.append(rating.rater.u_id)
            rating_times.append(rating.publish_time)
            if rating.helpful == 2:
                helpfulness.append("HELPFUL")
                # If there aren’t two different tags that are each used by two different raters, then the note’s status
                # label is reverted back to “Needs More Ratings” (this is very rare). -- Birdwatch Note Ranking.
                if random.choice([0, 1]) == 1:
                    helpful_others.append(1)
                    helpful_informative.append(0)
                else:
                    helpful_others.append(0)
                    helpful_informative.append(1)
                not_helpful_others.append(0)
                not_helpful_incorrect.append(0)
            elif rating.helpful == 1:
                helpfulness.append("SOMEWHAT_HELPFUL")
                if random.choice([0, 1]) == 1:
                    helpful_others.append(1)
                    helpful_informative.append(0)
                else:
                    helpful_others.append(0)
                    helpful_informative.append(1)
                not_helpful_others.append(0)
                not_helpful_incorrect.append(0)
            else:
                helpfulness.append("NOT_HELPFUL")
                helpful_others.append(0)
                helpful_informative.append(0)
                if random.choice([0, 1]) == 1:
                    not_helpful_others.append(1)
                    not_helpful_incorrect.append(0)
                else:
                    not_helpful_others.append(0)
                    not_helpful_incorrect.append(1)
        rating_df["noteId"] = rating_note_ids
        rating_df["participantId"] = rating_participants
        rating_df["createdAtMillis"] = rating_times
        rating_df["helpfulnessLevel"] = helpfulness
        rating_df["helpfulOther"] = helpful_others
        rating_df["helpfulInformative"] = helpful_informative
        rating_df["notHelpfulOther"] = not_helpful_others
        rating_df["notHelpfulIncorrect"] = not_helpful_incorrect
        rating_df["version"].fillna(2, inplace=True)
        rating_df.fillna(0, inplace=True)

        # Output as tsv files.
        note_df.to_csv("notes-00000.tsv", sep="\t", index=False)
        rating_df.to_csv("ratings-00000.tsv", sep="\t", index=False)
        return True

    def select_shown_notes(self):
        """
        Select notes to show under each Tweet.
        """
        # Read the scoredNotes.tsv.
        scored_notes_df = pd.read_csv("scoredNotes.tsv", sep="\t", header=0)
        interested_df = scored_notes_df[scored_notes_df["ratingStatus"] == "Currently Rated Helpful"]
        note_ids = interested_df.drop_duplicates(subset=["noteId"])["noteId"].tolist()
        for note_id in note_ids:
            for note in self.notes:
                if note.note_id == note_id:
                    note.rating_status = 1

        # for index, row in scored_notes_df.iterrows():
        #     for note in self.notes:
        #         if note.note_id == row["noteId"]:
        #             if row["ratingStatus"] == "Currently Rated Helpful":
        #                 note.rating_status = 1
        #             elif row["ratingStatus"] == "Currently Rated Not Helpful":
        #                 note.rating_status = -1
        #             else:
        #                 note.rating_status = 0
        #             break

        # Assign shown note for each Tweet.
        for tweet in self.tweets:
            notes = set()
            for time_step in tweet.notes:
                for note in tweet.notes[time_step]:
                    if note.rating_status == 1:
                        notes.add(note)
            if len(notes) > 0:
                shown_note = random.choice(list(notes))
                tweet.shown_note = shown_note
            else:
                tweet.shown_note = None

    def output_dependent_variables(self, current_time_step):
        """
        Prepare and write the dependent variables into files.

        :param int current_time_step: Current time step.
        """
        self.write_content_moderation_output(current_time_step)
        self.write_user_output(current_time_step)

    def write_content_moderation_output(self, current_time_step: int):
        """
        Summarise the content moderation effect, and write it into the output file.

        :param int current_time_step: Current time step.
        """
        for tweet in self.tweets:
            tweet.calculate_retweet_time(current_time_step)
            tweet.calculate_notes(current_time_step)
            tweet.calculate_votes(current_time_step)
        moderation_df = pd.DataFrame(columns=["current_run", "sub_model", "repetition", "treatment",
                                              "note_ranking_interval", "discreet_level", "echo_chamber_degree",
                                              "up_vote_effect", "post_tweet_probability", "read_length",
                                              "network_evolution_period", "network_evolution_threshold",
                                              "opinion_threshold", "malicious_proportion", "verified_num",
                                              "unverified_num", "tweetId", "time", "time_since_published",
                                              "weighted_severity", "reads", "retweets", "total_retweets", "up_votes",
                                              "total_up_votes", "down_votes", "total_down_votes", "notes",
                                              "total_notes"])
        tweet_ids = []
        times = []
        time_since_published = []
        weighted_severities = []
        reads = []
        retweets = []
        total_retweets = []
        up_votes = []
        total_up_votes = []
        down_votes = []
        total_down_votes = []
        notes = []
        total_notes = []
        for tweet in self.tweets:
            for time_step in range(1, current_time_step+1):
                if time_step >= tweet.create_time:
                    t_p = time_step - tweet.create_time
                else:
                    t_p = -1
                time_since_published.append(t_p)
                tweet_ids.append(tweet.tweetId)
                times.append(time_step)
                weighted_severities.append(tweet.weighted_severity)

                if time_step in tweet.read_record.keys():
                    reads.append(tweet.read_record[time_step])
                else:
                    reads.append(0)

                if time_step in tweet.retweet_times.keys():
                    retweets.append(tweet.retweet_times[time_step])
                    total_retweets.append(tweet.accumulative_retweet_times[time_step])
                else:
                    retweets.append(0)
                    pre_time_step = time_step - 1
                    filled = False
                    while pre_time_step > 1:
                        if pre_time_step in tweet.accumulative_retweet_times.keys():
                            total_retweets.append(tweet.accumulative_retweet_times[pre_time_step])
                            filled = True
                            break
                        pre_time_step -= 1
                    if not filled:
                        total_retweets.append(0)

                if time_step in tweet.up_vote_nums.keys():
                    up_votes.append(tweet.up_vote_nums[time_step])
                    total_up_votes.append(tweet.accumulative_up_vote_nums[time_step])
                    down_votes.append(tweet.down_vote_nums[time_step])
                    total_down_votes.append(tweet.accumulative_down_vote_nums[time_step])
                else:
                    up_votes.append(0)
                    down_votes.append(0)
                    pre_time_step = time_step - 1
                    filled = False
                    while pre_time_step > 1:
                        if pre_time_step in tweet.accumulative_up_vote_nums.keys():
                            total_up_votes.append(tweet.accumulative_up_vote_nums[pre_time_step])
                            filled = True
                            break
                        pre_time_step -= 1
                    if not filled:
                        total_up_votes.append(0)
                    pre_time_step = time_step - 1
                    filled = False
                    while pre_time_step > 1:
                        if pre_time_step in tweet.accumulative_down_vote_nums.keys():
                            total_down_votes.append(tweet.accumulative_down_vote_nums[pre_time_step])
                            filled = True
                            break
                        pre_time_step -= 1
                    if not filled:
                        total_down_votes.append(0)

                if time_step in tweet.note_num.keys():
                    notes.append(tweet.note_num[time_step])
                    total_notes.append(tweet.accumulative_note_num[time_step])
                else:
                    notes.append(0)
                    pre_time_step = time_step - 1
                    filled = False
                    while pre_time_step > 1:
                        if pre_time_step in tweet.accumulative_note_num.keys():
                            total_notes.append(tweet.accumulative_note_num[pre_time_step])
                            filled = True
                            break
                        pre_time_step -= 1
                    if not filled:
                        total_notes.append(0)
        moderation_df["tweetId"] = tweet_ids
        moderation_df["time"] = times
        moderation_df["time_since_published"] = time_since_published
        moderation_df["weighted_severity"] = weighted_severities
        moderation_df["reads"] = reads
        moderation_df["retweets"] = retweets
        moderation_df["total_retweets"] = total_retweets
        moderation_df["up_votes"] = up_votes
        moderation_df["total_up_votes"] = total_up_votes
        moderation_df["down_votes"] = down_votes
        moderation_df["total_down_votes"] = total_down_votes
        moderation_df["notes"] = notes
        moderation_df["total_notes"] = total_notes

        moderation_df["current_run"].fillna(self.current_run, inplace=True)
        moderation_df["sub_model"].fillna(self.sub_model, inplace=True)
        moderation_df["repetition"].fillna(self.repetition, inplace=True)
        moderation_df["treatment"].fillna(self.treatment, inplace=True)
        moderation_df["note_ranking_interval"].fillna(self.note_ranking_interval, inplace=True)
        moderation_df["discreet_level"].fillna(self.discreet_level, inplace=True)
        moderation_df["echo_chamber_degree"].fillna(self.echo_chamber_degree, inplace=True)
        moderation_df["up_vote_effect"].fillna(self.up_vote_effect, inplace=True)
        moderation_df["post_tweet_probability"].fillna(self.post_tweet_probability, inplace=True)
        moderation_df["read_length"].fillna(self.read_length, inplace=True)
        moderation_df["network_evolution_period"].fillna(self.network_evolution_period, inplace=True)
        moderation_df["network_evolution_threshold"].fillna(self.network_evolution_threshold, inplace=True)
        moderation_df["opinion_threshold"].fillna(self.opinion_threshold, inplace=True)
        moderation_df["malicious_proportion"].fillna(self.malicious_proportion, inplace=True)
        moderation_df["verified_num"].fillna(self.verified_num, inplace=True)
        moderation_df["unverified_num"].fillna(self.unverified_num, inplace=True)

        moderation_df.to_csv(self.output_dir + "moderation_%s.csv" % self.current_run)

    def write_user_output(self, current_time_step: int):
        """
        Summarise the user's data and write it into output file.

        :param int current_time_step: Current time step.
        """
        user_df = pd.DataFrame(columns=["current_run", "user_id", "malicious", "time", "opinion", "verified_num",
                                        "unverified_num"])
        u_ids = []
        times = []
        v_t_n = []
        u_t_n = []
        m = []
        o = []
        self.current_run
        user: User
        for user in self.user_network.nodes:
            for time_step in range(1, current_time_step + 1):
                u_ids.append(user.u_id)
                times.append(time_step)
                m.append(user.malicious)
                v_t_n.append(len(user.verified_topic_record[time_step]))
                u_t_n.append(len(user.unverified_topic_record[time_step]))
                o.append(user.opinion)
        user_df["user_id"] = u_ids
        user_df["malicious"] = m
        user_df["time"] = times
        user_df["opinion"] = o
        user_df["verified_num"] = v_t_n
        user_df["unverified_num"] = u_t_n


        user_df["current_run"].fillna(self.current_run, inplace=True)
        user_df.to_csv(self.output_dir + "user_%s.csv" % self.current_run)

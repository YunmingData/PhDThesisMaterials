#!/bin/bash

for i in {1..100..1}
do
	python3 main.py "selection" $i
done

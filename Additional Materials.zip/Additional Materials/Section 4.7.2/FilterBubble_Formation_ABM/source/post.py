# -*- coding: UTF-8 -*-

###
# Class Description
#     Post is the basic class of all the information users publish.
#     It has four children classes: Question, Answer, Article and Comment.
###
class Post():
    ###
    # Task:
    #     Construction function of Post class.
    # Parameters:
    #     id
    #         Type: String
    #         Meaning: The id of this post.
    #     publisher
    #         Type: User
    #         Meaning: The user who published this content.
    #     publish_time
    #         Type: String
    #         Meaning: The time step when this content is firstly published.
    ###
    def __init__(self, id, publisher, publish_time):
        self.id = id
        self.publisher = publisher
        self.publish_time = publish_time
        # <key, value>: <time_step, Set<User>>.
        self.up_votes = dict()

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        return self.id == other.id

    def __hash__(self):
        return hash(str(self.id))

    def __repr__(self):
        return "Post %d, Posted Time Step: %d" % (self.id, self.publish_time)

    def __str__(self):
        return "Post %d, Posted Time Step: %d" % (self.id, self.publish_time)

    def get_publisher(self):
        return self.publisher

    def get_publish_time(self):
        return self.publish_time

    def get_up_votes(self):
        return self.up_votes

    def get_up_voted_users(self):
        result = set()
        for time_step in self.up_votes.keys():
            result.update(self.up_votes[time_step])
        return result

    def is_voted_by(self, user):
        for time_step in self.up_votes:
            if user in self.up_votes[time_step]:
                return True
        return False

    def get_up_vote_number(self):
        voters = set()
        for time_step in self.up_votes:
            for voter in self.up_votes[time_step]:
                voters.add(voter)
        return len(voters)

    ###
    # Task:
    #     Record the users who voted for it.
    # Parameters:
    #     time_step:
    #         Type: int
    #         Meaning: current time step.
    #     users:
    #         Type: List<User>
    #         Meaning: Users who voted for it.
    ###
    def users_vote_for(self, time_step, users):
        if time_step not in self.up_votes.keys():
            self.up_votes[time_step] = set()
            for user in users:
                self.up_votes[time_step].add(user)
        else:
            for user in users:
                self.up_votes[time_step].add(user)

    ###
    # Task:
    #     Record the user who voted for it.
    # Parameters:
    #     time_step:
    #         Type: int
    #         Meaning: current time step.
    #     users:
    #         Type: User
    #         Meaning: The user who voted for it.
    ###
    def vote_for(self, time_step, user):
        if time_step not in self.up_votes.keys():
            self.up_votes[time_step] = set()
        self.up_votes[time_step].add(user)

###
# Class Description
#     Question is the questions put forward by users. It involves several topics. It could be followed.
###
class Question(Post):
    def __init__(self, id, publisher, publish_time, related_topics):
        super().__init__(id, publisher, publish_time)
        # The related topics. As each topic is a unique object of Class Topic,
        self.topics = set()
        for topic in related_topics:
            self.topics.add(topic)
        # The users who follows this question. They will get update when new answers are posted.
        # <key, value>: <time_step, Set<User>>.
        self.followers = dict()
        # <key, value>: <time_step, Set<User>>.
        self.read_user = dict()
        # The answers to this question.
        self.answers = set()
        # The answerers who provided answers to this question.
        self.answerers = set()

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        return self.id == other.id

    def __hash__(self):
        return hash(str(self.id))

    def __repr__(self):
        topic_ids = []
        for topic in self.topics:
            topic_ids.append(topic.get_id())
        return "Question %d, Posted Time Step: %d,  Topic:%d-%d-%d" % \
               (self.id, self.publish_time, topic_ids[0], topic_ids[1], topic_ids[2])

    def __str__(self):
        topic_ids = []
        for topic in self.topics:
            topic_ids.append(topic.get_id())
        return "Question %d, Posted Time Step: %d,  Topic:%d-%d-%d" % \
               (self.id, self.publish_time, topic_ids[0], topic_ids[1], topic_ids[2])

    def get_related_topics(self):
        return self.topics

    def read_by(self, time_step, user):
        if time_step not in self.read_user.keys():
            self.read_user[time_step] = set()
        self.read_user[time_step].add(user)

    def followed_by(self, time_step, user):
        if time_step not in self.read_user.keys():
            self.followers[time_step] = set()
        self.followers[time_step].add(user)

    def get_following_users(self):
        return self.followers

    def get_answers(self):
        return self.answers

    def add_answer(self, answer):
        self.answers.add(answer)

    def answered_by(self, user):
        self.answerers.add(user)

    def is_answered_by(self, user):
        return user in self.answerers

###
# Class Description
#     Answer is placed under a question. It does not involve topic. It could be saved.
###
class Answer(Post):
    def __init__(self, id, publisher, publish_time, question, topic_opinions, quality):
        super().__init__(id, publisher, publish_time)
        # The users who saved this answer. <key, value>: <time_step, Set<User>>.
        self.saving_users = dict()
        # <key, value>: <time_step, Set<User>>.
        self.read_users = dict()
        # The question of this answer.
        self.question = question
        # <key, value> = <Topic, opinion in this topic>.
        self.topic_opinions = topic_opinions
        # <key, value> = <Topic, quality in this topic>.
        self.quality = quality

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        return self.id == other.id

    def __hash__(self):
        return hash(str(self.id))

    def __repr__(self):
        topics = []
        for topic in self.topic_opinions:
            topics.append(topic)
        qualities = []
        for topic in topics:
            qualities.append(self.topic_opinions[topic])
        return "Answer %d, Posted by User %d in Time Step %d, To Question %d. Topic opinions:%d[%f]-%d[%f]-%d[%f], Quality: %d[%f]-%d[%f]-%d[%f]" \
               % (self.id, self.publisher.id, self.publish_time, self.question.id,
                  topics[0].id, self.topic_opinions[topics[0]],
                  topics[1].id, self.topic_opinions[topics[1]],
                  topics[2].id, self.topic_opinions[topics[2]],
                  topics[0].id, qualities[0],
                  topics[1].id, qualities[1],
                  topics[2].id, qualities[2])

    def __str__(self):
        topics = []
        for topic in self.topic_opinions:
            topics.append(topic)
        qualities = []
        for topic in topics:
            qualities.append(self.topic_opinions[topic])
        return "Answer %d, Posted by User %d in Time Step %d, To Question %d. Topic opinions:%d[%f]-%d[%f]-%d[%f], Quality: %d[%f]-%d[%f]-%d[%f]" \
               % (self.id, self.publisher.id, self.publish_time, self.question.id,
                  topics[0].id, self.topic_opinions[topics[0]],
                  topics[1].id, self.topic_opinions[topics[1]],
                  topics[2].id, self.topic_opinions[topics[2]],
                  topics[0].id, qualities[0],
                  topics[1].id, qualities[1],
                  topics[2].id, qualities[2])

    def get_question(self):
        return self.question

    def is_read_by(self, user):
        for time_step in self.read_users:
            if user in self.read_users[time_step]:
                return True
        return False

    def get_read_users_in_set(self):
        result = set()
        for time_step in self.read_users:
            result.update(self.read_users[time_step])
        return result

    def read_by(self, time_step, user):
        if time_step not in self.read_users.keys():
            self.read_users[time_step] = set()
        self.read_users[time_step].add(user)

    def saved_by(self, time_step, user):
        if time_step not in self.read_users.keys():
            self.saving_users[time_step] = set()
        self.saving_users[time_step].add(user)

    def get_saving_user(self):
        return self.saving_users

    def get_topic_opinion(self):
        return self.topic_opinions

    def get_quality(self):
        return self.quality

###
# Class Description
#     Article is placed alone, involving some topics. It could be saved.
###
class Aritcle(Post):
    def __init__(self, id, publisher, publish_time, topic_opinions, quality):
        super().__init__(id, publisher, publish_time)
        # The users who saved this answer. <key, value>: <time_step, Set<User>>.
        self.saving_users = dict()
        # <key, value>: <time_step, Set<User>>.
        self.read_users = dict()
        # <key, value>: <Topic, opinion in this topic>/.
        self.topic_opinions = topic_opinions
        # <key, value> = <Topic, quality in this topic>.
        self.quality = quality

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        return self.id == other.id

    def __hash__(self):
        return hash(str(self.id))

    def read_by(self, time_step, user):
        if time_step not in self.read_users.keys():
            self.read_users[time_step] = set()
        self.read_users[time_step].add(user)

    def saved_by(self, time_step, user):
        if time_step not in self.read_users.keys():
            self.saving_users[time_step] = set()
        self.saving_users[time_step].add(user)

    def get_saving_user(self):
        return self.saving_users

    def get_topic_opinion(self):
        return self.topic_opinions

    def get_quality(self):
        return self.quality

###
# Class Description
#     Comments is placed under other three kinds of posts. It does not involve any topics.
###
class Comment(Post):
    def __init__(self, id, publisher, publish_time, belonging_post, topic_opinions, quality):
        super().__init__(id, publisher, publish_time)
        # The post under which this comments is placed.
        self.belonging_post = belonging_post
        # <key, value>: <Topic, opinion in this topic>/.
        self.topic_opinions = topic_opinions
        # <key, value> = <Topic, quality in this topic>.
        self.quality = quality

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        return self.id == other.id

    def __hash__(self):
        return hash(str(self.id))

    def get_belonging_post(self):
        return self.belonging_post

    def get_topic_opinion(self):
        return self.topic_opinions

    def get_quality(self):
        return self.quality
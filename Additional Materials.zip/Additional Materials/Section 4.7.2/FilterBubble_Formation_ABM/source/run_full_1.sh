#!/bin/bash

for i in {1..30..1}
do
	python3 main.py "influence_selection_algorithm" $i
done

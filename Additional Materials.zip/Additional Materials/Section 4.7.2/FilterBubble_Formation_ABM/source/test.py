import sys

if __name__ == "__main__":
    sub_model = sys.argv[1]
    repetition = sys.argv[2]

    print("Running: sub model %s, repetition %s" % (sub_model, repetition))

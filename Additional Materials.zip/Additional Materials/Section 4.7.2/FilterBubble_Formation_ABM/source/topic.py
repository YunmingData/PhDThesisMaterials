# -*- coding: UTF-8 -*-
import logging, logging.handlers
import os

class Topic():
    ###
    # Task:
    #     Construction function of Topic object.
    # Level: Public
    # Parameters:
    #     id
    #         Type: int
    #         Meaning: ID of current user.
    #     log_dir_path
    #         Type: String
    #         Meaning: The path to put the log files.
    ###
    def __init__(self, id, log_dir_path):
        # ========================================= Log Configurations =============================================== #
        self.log_dir_path = log_dir_path + os.sep
        # logging.basicConfig(level=logging.DEBUG,
        #                     format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
        #                     datefmt='%a, %d %b %Y %H:%M:%S')
        # self.formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        # self.log_handler_debug = logging.FileHandler(filename = self.log_dir_path + "topic_debug.log")
        # self.log_handler_debug.setLevel(logging.DEBUG)
        # self.log_handler_debug.setFormatter(self.formatter)
        # self.log_handler_info = logging.FileHandler(filename = self.log_dir_path + "topic_info.log")
        # self.log_handler_info.setLevel(logging.INFO)
        # self.log_handler_info.setFormatter(self.formatter)
        # self.log_handler_warning = logging.FileHandler(filename = self.log_dir_path + "topic_warning.log")
        # self.log_handler_warning.setLevel(logging.WARNING)
        # self.log_handler_warning.setFormatter(self.formatter)
        # self.log_handler_error = logging.FileHandler(filename = self.log_dir_path + "topic_error.log")
        # self.log_handler_error.setLevel(logging.ERROR)
        # self.log_handler_error.setFormatter(self.formatter)
        # self.logger = logging.getLogger(__name__)
        # self.logger.addHandler(self.log_handler_debug)
        # self.logger.addHandler(self.log_handler_info)
        # self.logger.addHandler(self.log_handler_warning)
        # self.logger.addHandler(self.log_handler_error)
        # ======================================== Basic Configurations ============================================== #
        self.id = id
        # The parent topics of this topic. If it's empty, then this topic is the root topic.
        self.parent_topics = set()
        # The children topics of this topic. If it's empty, then this topic is a le
        self.children_topics = set()
        # The users who follows this topic.
        self.followers = set()
        # The questions belong to this topic.
        self.questions = set()
        # The articles belong to this topic.
        self.articles = set()

    ###
    # Task:
    #     Re-implement __eq__ function, so that Topic could be deduplicated by set().
    # Parameters:
    #     other
    #         Type: object
    #         Meaning: The other object compared.
    # Return:
    #     Boolean. Only when the Class type and id are the same, return True.
    ###
    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        # Here I only compare the ids of two topics, rather than taking parent topics and children topics into
        # consideration, because the relationship among topics won't be changed after they're created.
        return self.id == other.id

    def __hash__(self):
        return hash(str(self.id))

    def __repr__(self):
        return "Topic %d" % self.id

    def __str__(self):
        return "Topic %d" % self.id

    ###
    # Task:
    #     Get this topic's ID
    # Level: Public
    # Return:
    #     self.id: int
    ###
    def get_id(self):
        return self.id

    ###
    # Task:
    #     Get all the parent topics for this topic.
    # Level: Public
    # Return:
    #     self.parent_topics: set(Topic)
    ###
    def get_parent_topics(self):
        return self.parent_topics

    ###
    # Task:
    #     Get all the children topics for this topic.
    # Level: Public
    # Return:
    #     self.children_topics: set(Topic)
    ###
    def get_children_topics(self):
        return self.children_topics

    ###
    # Task:
    #     Get one the child topic for this topic by its ID.
    # Level: Public
    # Parameters:
    #     id
    #         Type: int
    #         Meaning: the ID of the child topic.
    # Return:
    #     Normal: the Topic
    #     The topic doesn't exist: None
    ###
    def get_child_topic_by_id(self, id):
        for topic in self.children_topics:
            if topic.get_id() == id:
                return topic
        # logging.error("[Get Child Topic by ID] Not found (Topic id: %d)" % id)
        return None

    ###
    # Task:
    #     Set parent topics as a whole.
    # Level: Public
    # Parameters:
    #     parent_topics
    #         Type: set(Topic)
    #         Meaning: All parent topics for this topic.
    ###
    def set_parent_topics(self, parent_topics):
        self.parent_topics.clear()
        for topic in parent_topics:
            self.parent_topics.add(topic)

    ###
    # Task:
    #     Add a set of parent topics.
    # Level: Public
    # Parameters:
    #     parent_topics
    #         Type: set(Topic)
    #         Meaning: New parent topics for this topic.
    ###
    def add_parent_topics(self, parent_topics):
        for topic in parent_topics:
            self.parent_topics.add(topic)

    ###
    # Task:
    #     Add a parent topic.
    # Level: Public
    # Parameters:
    #     topic
    #         Type: Topic
    #         Meaning: The new parent topic
    ###
    def add_parent_topic(self, topic):
        self.parent_topics.add(topic)

    ###
    # Task:
    #     Set children topics as a whole.
    # Level: Public
    # Parameters:
    #     children_topics
    #         Type: set(Topic)
    #         Meaning: All children topics for this topic.
    ###
    def set_children_topics(self, children_topics):
        self.children_topics.clear()
        for topic in children_topics:
            self.children_topics.add(topic)

    ###
    # Task:
    #     Add a set of children topics.
    # Level: Public
    # Parameters:
    #     children_topics
    #         Type: set(Topic)
    #         Meaning: New children topics for this topic.
    ###
    def add_children_topics(self, children_topics):
        for topic in children_topics:
            self.children_topics.add(topic)

    ###
    # Task:
    #     Add a child topic.
    # Level: Public
    # Parameters:
    #     topic
    #         Type: Topic
    #         Meaning: The new child topic
    ###
    def add_child_topic(self, topic):
        self.children_topics.add(topic)

    def add_question(self, question):
        self.questions.add(question)

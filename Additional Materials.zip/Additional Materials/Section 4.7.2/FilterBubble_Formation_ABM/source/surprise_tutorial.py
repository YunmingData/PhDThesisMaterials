import random
from surprise import KNNWithZScore
from surprise.prediction_algorithms.matrix_factorization import SVD
from surprise import Dataset
from surprise import Reader
import pandas as pd
class User():
    def __init__(self, id):
        self.id = id
        self.voted_answer = []

    def vote_for_answer(self, answer):
        self.voted_answer.append(answer)

class Answer():
    def __init__(self, id):
        self.id = id

user_list = []
for i in range(5):
    user_list.append(User(i))

answer_list = []
for i in range(20):
    answer_list.append(Answer(i))

for user in user_list:
    answer_sample = random.sample(answer_list, random.randint(4, 9))
    for answer in answer_sample:
        user.vote_for_answer(answer)

user_id_list = []
answer_id_list = []
voting_list = []
for i in range(5):
    user = user_list[i]
    for j in range(20):
        answer = answer_list[j]
        user_id_list.append(str(user.id))
        answer_id_list.append(str(answer.id))
        voting_list.append(1 if answer in user.voted_answer else 0)

data = {
    "user_id":user_id_list,
    "answer_id":answer_id_list,
    "voting":voting_list
}
dataframe = pd.DataFrame(data)

reader = Reader(rating_scale=(0, 1))
data = Dataset.load_from_df(dataframe[["user_id", "answer_id", "voting"]], reader)

# Retrieve the train_set.
train_set = data.build_full_trainset()

# Build an algorithm, and train it.
# nmf_algo = NMF()
svd_algo = SVD()
svd_algo.fit(train_set)
uid = str(2)  # raw user id (as in the ratings file). They are **strings**!
iid = str(1001)  # raw item id (as in the ratings file). They are **strings**!

# get a prediction for specific users and items.
print("Prediction of User ID = %s, Item ID = %s by SVD is:" % (uid, iid))
pred_svd = svd_algo.predict(uid = uid, iid = iid, verbose=True)
print("\n")

print("Prediction of User ID = %s, Item ID = %s by KNN with Z-score is:" % (uid, iid))
algo = KNNWithZScore()

algo.fit(train_set)
neighbours = algo.get_neighbors(iid=train_set.to_inner_uid(uid), k=1)
print(neighbours)
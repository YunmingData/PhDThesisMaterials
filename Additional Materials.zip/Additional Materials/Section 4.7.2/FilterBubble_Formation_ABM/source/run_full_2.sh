#!/bin/bash

for i in {31..60..1}
do
	python3 main.py "influence_selection_algorithm" $i
done

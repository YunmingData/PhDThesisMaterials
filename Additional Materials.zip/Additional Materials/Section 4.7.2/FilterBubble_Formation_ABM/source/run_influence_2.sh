#!/bin/bash

for i in {31..60..1}
do
	python3 main.py "influence" $i
done

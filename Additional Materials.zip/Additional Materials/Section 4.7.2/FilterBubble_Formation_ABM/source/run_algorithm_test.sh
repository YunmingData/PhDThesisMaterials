#!/bin/bash

for i in {1..5..1}
do
	python3.8 main.py "algorithm" $i
done

#!/bin/bash

for i in {1..30..1}
do
	python3 main.py "influence" $i
done

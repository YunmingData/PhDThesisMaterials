# -*- coding: UTF-8 -*-
import logging, logging.handlers
import os
import time
import sys
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import random
import json
from topic import Topic
from user import User
from efficient_apriori import apriori
import pandas as pd
from surprise.prediction_algorithms.matrix_factorization import SVD
from surprise import KNNWithZScore
from surprise import Dataset
from surprise import Reader

class Simulator():
    ###
    # Task:
    #     The constructor of the agent-based model class.
    # Parameters:
    #     sub_model
    #         Type: String
    #         Meaning: The name of the sub model.
    #     repetition
    #         Type: String
    #         Meaning: The time of repetition of this run with current repetition.
    ###
    def __init__(self, sub_model, repetition):
        # ========================================= Log Configurations =============================================== #
        self.log_dir_path = os.path.abspath(os.path.dirname(os.getcwd())) + os.sep + "log" + os.sep + \
                       sub_model
        self.repetition = repetition
        if not os.path.exists(self.log_dir_path):
            os.mkdir(self.log_dir_path)
        self.log_dir_path = self.log_dir_path + os.sep + repetition
        if not os.path.exists(self.log_dir_path):
            os.mkdir(self.log_dir_path)
        logging.basicConfig(level=logging.DEBUG,
                            format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                            datefmt='%a, %d %b %Y %H:%M:%S')
        self.formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        # self.log_handler_debug = logging.FileHandler(filename = self.log_dir_path + os.sep + "main_debug.log")
        # self.log_handler_debug.setLevel(logging.DEBUG)
        # self.log_handler_debug.setFormatter(self.formatter)
        self.log_handler_info = logging.FileHandler(filename = self.log_dir_path + os.sep + "main_info.log")
        self.log_handler_info.setLevel(logging.INFO)
        self.log_handler_info.setFormatter(self.formatter)
        self.log_handler_warning = logging.FileHandler(filename = self.log_dir_path + os.sep + "main_warning.log")
        self.log_handler_warning.setLevel(logging.WARNING)
        self.log_handler_warning.setFormatter(self.formatter)
        self.log_handler_error = logging.FileHandler(filename = self.log_dir_path + os.sep + "main_error.log")
        self.log_handler_error.setLevel(logging.ERROR)
        self.log_handler_error.setFormatter(self.formatter)
        self.logger = logging.getLogger(__name__)
        # self.logger.addHandler(self.log_handler_debug)
        self.logger.addHandler(self.log_handler_info)
        self.logger.addHandler(self.log_handler_warning)
        self.logger.addHandler(self.log_handler_error)
        # ======================================== Basic Configurations ============================================== #
        self.sub_model = sub_model
        self.social_influence_switch = False
        self.social_selection_switch = False
        self.recommender_algorithm_switch = False
        self.topic_space = nx.DiGraph()
        self.user_network = nx.DiGraph()

        # ========================================== User Generation ================================================= #
        # The biggest available user ID.
        self.user_id = 0
        # The mean of users' interested topic numbers.
        mu_interested_topic_number = 10
        # The standard deviation of users' interested topic numbers.
        sigma_interested_topic_number = 3
        self.sample_interested_topic_number = np.random.normal(mu_interested_topic_number,
                                                               sigma_interested_topic_number,
                                                               100)
        # The mean of users' opinions towards a topic.
        mu_opinion = 0
        # The standard deviation of users' opinions towards a topic.
        sigma_opinion = 0.3
        self.sample_opinion = np.random.normal(mu_opinion, sigma_opinion, 10000)

        # The mean of users' expertise in a topic.
        mu_expertise = 50
        # The standard deviation of users' expertise in a topic.
        sigma_expertise = 20
        self.sample_expertise = np.random.normal(mu_expertise, sigma_expertise, 10000)
        # The output path.
        self.result_dir_path = os.path.abspath(os.path.dirname(os.getcwd())) + os.sep + "result" + os.sep + \
                            sub_model
        if not os.path.exists(self.result_dir_path):
            os.mkdir(self.result_dir_path)
        self.result_dir_path = self.result_dir_path + os.sep + repetition
        if not os.path.exists(self.result_dir_path):
            os.mkdir(self.result_dir_path)

        # ============================================ Interaction Record ============================================ #
        # Current time step.
        self.time_step = 1
        # The biggest available post ID.
        self.post_id = 0
        # The questions asked.
        self.questions = []
        # The answers posted.
        self.answers = []

        # ============================================== Recommendations ============================================= #
        # The user-item matrix, pandas DataFrame.
        self.user_item_matrix = None
        # The training set generated from the user-item matrix.
        self.training_set = None
        # The SVD algorithm.
        self.recommending_algorithm_svd = SVD()
        # The K-Nearest neighbours Algorithm
        self.recommending_algorithm_KNN = KNNWithZScore()

    ###
    # Task:
    #     Read the sub model configurations from the configuration files.
    # Return:
    #     (return_code, setting_dict): (int, dict) return_code is below 0 if there is an error.
    ###
    def reading_sub_model_config(self):
        sub_model_config_path = os.path.abspath(os.path.dirname(os.getcwd())) + os.sep + "config" + \
                                os.sep + "sub_model_config.json"
        config_json = json.load(open(sub_model_config_path, "r"))
        if self.sub_model not in config_json.keys():
            logging.error("[Reading Sub Model Config] Sub-model %s does not exist in config json." % self.sub_model)
            return -1

        self.settings = config_json[self.sub_model]
        element_list = ["topic_number",
                        "original_user_number",
                        "max_user_following",
                        "acceptable_up_vote_number",
                        "friend_up_vote_read_threshold",
                        "acceptable_quality_threshold",
                        "acceptable_opinion_threshold",
                        "social_influence",
                        "social_selection",
                        "recommender_system"]
        for element in element_list:
            if element not in self.settings:
                # logging.error("[Reading Sub Model Config] Element <%s> does not exist in config json for sub-model %s."
                #               % (self.sub_model, element))
                return -2

        self.social_influence_switch = self.settings["social_influence"]
        self.social_selection_switch = self.settings["social_selection"]
        self.recommender_algorithm_switch = self.settings["recommender_system"]
        # self.logger.info("[Reading Sub Model Config] Succeed for sum-model %s." % self.sub_model)
        return 0

    ###
    # Task:
    #     The entrance of the whole agent-based model. This function controls the whole process.
    ###
    def run(self):
        time_used_dict = dict()
        pre_time = time.time()
        user_ids = []
        changing_focusing_topic_time = []
        asking_time = []
        answering_time = []
        data_source_time = []
        recommender_system_update_time = []
        df_times = []
        trainset_build_times = []
        svd_times = []
        knn_times = []
        data_presentation_time = []
        user_recommendation_time = []
        read_time = []

        self.create_topic_space()
        while self.time_step < 31:
            print("\n* ========================= Sub Model %s Repetition %s Time Step %d ========================= *" %
                  (self.sub_model, self.repetition, self.time_step))
            self.create_new_user()
            self.check_user_following_status()
            shuffled_users = self.shuffle_existing_user_order()

            pre_time = time.time()
            self.recommender_system_update()
            updating_time = time.time() - pre_time
            pre_time = time.time()

            for user in shuffled_users:
                user_ids.append(user.id)
                # print("    User: %d in time step %d" % (user.id, self.time_step))
                # print("        Following:")
                # for userA in user.get_user_I_am_following():
                #     print("            User %d" % userA.id)
                #
                # print("        Have read:")
                # for answer in user.get_answers_read_in_a_list():
                #     print("            %s" % answer)
                #
                # print("        Have asked:")
                # for question in user.get_question_published_in_set():
                #     print("            %s" % question)
                #
                # print("        Have posted answers:")
                # answer_posted = user.get_answers_posted_in_a_set()
                # for answer in answer_posted:
                #     print("            %s" % answer)

                user.changing_focusing_topic(self.time_step)
                changing_focusing_topic_time.append(time.time() - pre_time)
                pre_time = time.time()

                new_question = user.asking(self.post_id)
                if new_question != None:
                    self.questions.append(new_question)
                asking_time.append(time.time() - pre_time)
                pre_time = time.time()

                new_answers = user.answering(self.questions)
                if len(new_answers) > 0:
                    self.answers.extend(new_answers)
                answering_time.append(time.time() - pre_time)
                pre_time = time.time()

                recommender_system_update_time.append(updating_time)

                timeline = self.data_source(user)
                data_source_time.append(time.time()-pre_time)
                pre_time = time.time()

                self.data_presentation(user, timeline)
                data_presentation_time.append(time.time() - pre_time)
                pre_time = time.time()

                self.user_recommendation(user)
                user_recommendation_time.append(time.time()-pre_time)
                pre_time = time.time()

                self.post_id = user.read()
                read_time.append(time.time()-pre_time)
                pre_time = time.time()
            self.time_step += 1
        time_used_dict = {
            "user":user_ids,
            "changing_focusing_topic": changing_focusing_topic_time,
            "asking":asking_time,
            "answering":answering_time,
            "data_source":data_source_time,
            "updating":recommender_system_update_time,
            "data_presentation":data_presentation_time,
            "user_recommendation":user_recommendation_time,
            "read":read_time
        }
        time_df = pd.DataFrame(time_used_dict)
        time_df.to_csv("time_used.csv")
        self.gather_user_outputs()
        # self.logger.info("[%s] Model Ends." % sys._getframe().f_code.co_name)

    ###
    # Task:
    #     Create all the topics which form a DAG (Directed Acyclic Graph).
    ###
    def create_topic_space(self):
        self.create_topics()
        self.establish_topic_network()
        # self.draw_topic_space()
        self.calculate_topic_distance_matrix()

    ###
    # Task:
    #     Create the Topics according to the "topic number" attribute in the settings.
    ###
    def create_topics(self):
        # self.logger.info("[%s] Starts." % sys._getframe().f_code.co_name)
        topic_number = self.settings["topic_number"]
        self.topic_distance_matrix = np.zeros([topic_number + 1, topic_number + 1])

        # Create Topics in the graph.
        topic_space = set()
        # Topic 0 is the root topic, so the normal topics start from Topic 1.
        for i in range(1, topic_number + 1):
            topic_space.add(Topic(i, self.log_dir_path))
        self.topic_space.add_nodes_from(topic_space)

    ###
    # Task
    #     Establish the network among Topics.
    ###
    def establish_topic_network(self):
        # self.logger.info("[%s] Starts." % sys._getframe().f_code.co_name)
        topic_number = self.settings["topic_number"]
        # Create the edges in the graph.
        max_edge_number = topic_number * (topic_number - 1) / 2
        # The density of topic network is set to be 50%.
        topic_network_density = 0.5
        real_edge_number = round(max_edge_number * topic_network_density)

        node_list = list(self.topic_space.nodes)
        while not nx.algorithms.components.is_weakly_connected(self.topic_space):
            self.topic_space.clear()
            self.topic_space.add_nodes_from(node_list)
            while self.topic_space.size() < real_edge_number:
                (topic_a, topic_b) = random.sample(self.topic_space.nodes, 2)

                # The comparision between two ids is making sure there is no circles in this graph.
                if topic_a.id > topic_b.id:
                    if self.topic_space.has_edge(topic_b, topic_a):
                        continue
                    else:
                        self.topic_space.add_edge(topic_b, topic_a)
                        # logging.info("[Create Topic Space] Create edge <%d, %d>, now the size of the graph is %d." %
                        #              (topic_b.id, topic_a.id, self.topic_space.size()))
                else:
                    if self.topic_space.has_edge(topic_a, topic_b):
                        continue
                    else:
                        self.topic_space.add_edge(topic_a, topic_b)
                        # logging.info("[Create Topic Space] Create edge <%d, %d>, now the size of the graph is %d." %
                        #              (topic_a.id, topic_b.id, self.topic_space.size()))

        root_node = Topic(0, self.log_dir_path)
        top_nodes = []
        for topic in self.topic_space.nodes:
            if self.topic_space.in_degree(topic) == 0:
                top_nodes.append(topic)
        for topic in top_nodes:
            self.topic_space.add_edge(root_node, topic)

    ###
    # Task:
    # Draw the topic space.
    ###
    # def draw_topic_space(self):
    #     pos = nx.circular_layout(self.topic_space)
    #     drawn_nodes = []
    #     drawn_labels = dict()
    #     for i in range(6):
    #         for topic in self.topic_space.nodes:
    #             if topic.id == i:
    #                 drawn_nodes.append(topic)
    #                 drawn_labels[topic] = i
    #                 break
    #     nx.draw_networkx_nodes(self.topic_space, pos, nodelist=drawn_nodes)
    #     nx.draw_networkx_labels(self.topic_space, pos, drawn_labels, font_size=16)
    #     nx.draw_networkx_edges(self.topic_space, pos, arrowstyle='->')
    #
    #     plt.savefig('topic_network.png')

    ###
    # Task:
    #     Calculate the distance matrix. As in our definition the directed links represent the parent-child relation
    #     among the topics, the matrix is calculated as an undirected graph.
    ###
    def calculate_topic_distance_matrix(self):
        # self.logger.info("[%s] Starts." % sys._getframe().f_code.co_name)
        for i in range(self.topic_space.number_of_nodes()):
            for topic_1 in self.topic_space.nodes:
                if topic_1.id == i:
                    for j in range(self.topic_space.number_of_nodes()):
                        for topic_2 in self.topic_space.nodes:
                            if topic_2.id == j:
                                try:
                                    shortest_path = nx.algorithms.shortest_paths.dijkstra_path(self.topic_space,
                                                                                               topic_1, topic_2)
                                    self.topic_distance_matrix[i][j] = len(shortest_path) - 1
                                    self.topic_distance_matrix[j][i] = len(shortest_path) - 1
                                except nx.exception.NetworkXNoPath:
                                    break
                                break
                    break

    ###
    # Task:
    #     Create a new user, set the attributes.
    ###
    def create_new_user(self):
        # self.logger.info("[%s] Starts." % sys._getframe().f_code.co_name)
        # New user's interested topics. The user will originally only follow 5 interested topics.
        interested_topic_number = 10
        # while interested_topic_number <= 0:
        #     interested_topic_number = round(random.choice(self.sample_interested_topic_number))
        interested_topics = set(random.sample(list(self.topic_space), interested_topic_number))
        following_topics = set(random.sample(interested_topics, 5))

        # New user's opinion and expertise in each topic.
        topic_opinions = dict()
        topic_expertise = dict()
        index = 0
        for topic in self.topic_space.nodes:
            opinion = random.choice(self.sample_opinion)
            while opinion < -1 or opinion > 1:
                opinion = random.choice(self.sample_opinion)
            topic_opinions[topic] = opinion

            expertise = random.choice(self.sample_expertise)
            while expertise < 0 or expertise > 100:
                expertise = random.choice(self.sample_expertise)
            topic_expertise[topic] = expertise
            index += 1

        user = User(id=self.user_id,
                    log_dir_path = self.log_dir_path,
                    result_dir_path = self.result_dir_path,
                    creation_time_step = self.time_step,
                    interested_topics = interested_topics,
                    following_topics = following_topics,
                    topic_opinions = topic_opinions,
                    topic_expertise = topic_expertise,
                    topic_space = self.topic_space,
                    social_influence_switch = self.social_influence_switch,
                    social_selection_switch = self.social_selection_switch,
                    max_user_following = self.settings["max_user_following"],
                    acceptable_up_vote_number = self.settings["acceptable_up_vote_number"],
                    friend_up_vote_read_threshold = self.settings["friend_up_vote_read_threshold"],
                    acceptable_quality_threshold = self.settings["acceptable_quality_threshold"],
                    acceptable_opinion_threshold = self.settings["acceptable_opinion_threshold"],
                    stubbornness = random.random())
        self.user_id += 1
        self.user_network.add_node(user)

    ###
    # Task:
    #     Introduce the user into the user network. Gradually each user will follow 10 users at most.
    #     Each user follows one more user in each time step.
    #     If social-selection is switched off, this is the only opportunity for the users to follow users.
    ###
    def check_user_following_status(self):
        # self.logger.info("[%s] Starts." % sys._getframe().f_code.co_name)
        existing_users = list(self.user_network.nodes)
        self.rank_users_quick_sort(existing_users, 0, len(existing_users)-1)

        # The total degree of all the existing users.
        total_degree = 0
        for user in existing_users:
            total_degree += self.user_network.in_degree(user)

        for user in existing_users:
            # For users who hasn't followed enough
            if len(user.get_user_I_am_following()) < 10:
                existing_users_sharing_topic = self.users_who_share_topic_interest(user)
                if len(existing_users_sharing_topic) > 0:
                    self.preferential_attachment(user, existing_users_sharing_topic, total_degree, True)
                else:
                    self.preferential_attachment(user, existing_users, total_degree, False)

    def rank_users_quick_sort(self, users, low_index, high_index):
        if low_index < high_index:
            pi = self.user_partition_quick_sort(users, low_index, high_index)

            self.rank_users_quick_sort(users, low_index, pi - 1)
            self.rank_users_quick_sort(users, pi + 1, high_index)

    def user_partition_quick_sort(self, users, low_index, high_index):
        i = (low_index - 1)
        pivot = self.user_network.in_degree(users[high_index])

        for j in range(low_index, high_index):
            if self.user_network.in_degree(users[j]) >= pivot:
                i += 1
                users[j], users[i] = users[i], users[j]

        users[i + 1], users[high_index] = users[high_index], users[i + 1]
        return (i+1)

    ###
    # Task:
    #     Get the user list who share interested topic(s) with the given user.
    # Parameters:
    #     user
    #         Type: User
    #         Meaning: The given user.
    # Return:
    #     Type: List<User>
    #     Meaning: The users who share at least one interested topic with the given one.
    ###
    def users_who_share_topic_interest(self, user):
        sharing_topic_users = []
        for userA in self.user_network.nodes:
            if userA != user and \
                    not userA.get_interested_topics().isdisjoint(user.get_interested_topics()):
                sharing_topic_users.append(userA)
        return sharing_topic_users

    ###
    # Task:
    #     The given user will follow another user using preferential attachment.
    #     If there are users who share at least one interested topic, he follows one of them;
    #         if not, he chooses from the whole user network.
    #     The more popular (having more followers) a user is, the higher probability the given user will follow him.
    # Parameters:
    #     user
    #         Type: User
    #         Meaning: The given user.
    #     following_candidates
    #         Type: List<User>
    #         Meaning: From which list the given user choose a user to follow.
    #     network_total_degree
    #         Type: Integer
    #         Meaning: The total degree of the whole user network.
    #     small_world_feature
    #         Type: Boolean
    #         Meaning: If True, the user choose from the following_candidates,
    #             if not, the user choose from the whole_user_list.
    ###
    def preferential_attachment(self, user, following_candidates, network_total_degree, small_world_feature):
        if len(following_candidates) == 1 and following_candidates[0].__eq__(user):
            return
        total_degree = 0
        if small_world_feature:
            for userA in following_candidates:
                total_degree += self.user_network.in_degree(userA)
        else:
            total_degree = (network_total_degree - self.user_network.in_degree(user))
        # No link has been established.
        if total_degree == 0:
            for userA in following_candidates:
                if userA.__eq__(user):
                    following_candidates.remove(userA)
                    break
            if len(following_candidates) > 0:
                userA = random.choice(following_candidates)
                self.user_network.add_edge(user, userA)
                user.follow_user(userA)
        else:
            choice = random.random()
            score = 0
            for userA in following_candidates:
                if user.__eq__(userA):
                    continue
                score += (self.user_network.in_degree(userA) / total_degree)
                if choice < score:
                    user.follow_user(userA)
                    self.user_network.add_edge(user, userA)
                    return

    ###
    # Task:
    #     At the beginning of each round, making a random order among the users.
    # Return:
    #     Type: List<User>
    #     Meaning: A list of all existing users with shuffled order.
    ###
    def shuffle_existing_user_order(self):
        # self.logger.info("[%s] Starts." % sys._getframe().f_code.co_name)
        shuffled_users = list(self.user_network.nodes)
        random.shuffle(shuffled_users)
        return shuffled_users

    ###
    # Task:
    #     Prepare the timeline of current user. Pre-selection + self-selection.
    #     There are no duplicated answers in the timeline.
    # Parameters:
    #     user
    #         Type: User
    #         Meaning: Current user.
    # Return:
    #     Type: List<Answer>
    #     Meaning: The original timeline.
    ###
    def data_source(self, user):
        # self.logger.info("[%s] Starts." % sys._getframe().f_code.co_name)
        time_line = set()
        if self.recommender_algorithm_switch:
            content_recommendation = self.content_recommendation(user)
            if len(content_recommendation) > 0:
                time_line.update(content_recommendation)

        # Updates from users this user is following.
        answer_from_followed_users = set()
        for userA in user.get_user_I_am_following():
            for answer in self.answers:
                # New answers posted by the followed users in 5 time steps.
                if answer.get_publisher() == userA and (answer.get_publish_time() > (self.time_step-5)):
                    answer_from_followed_users.add(answer)

                # Answers up-voted by the followed users in 5 time steps.
                upvotes = answer.get_up_votes()
                for time_step in range(self.time_step-5, self.time_step+1):
                    if time_step not in upvotes.keys():
                        continue
                    if userA in upvotes[time_step]:
                        answer_from_followed_users.add(answer)
                        break

        # New answers under the followed topics posted in the last 5 time steps.
        answer_from_followed_topics = set()
        for answer in self.answers:
            question = answer.get_question()
            if not question.get_related_topics().isdisjoint(user.get_following_topics())\
                    and (answer.get_publish_time() > self.time_step-5):
                answer_from_followed_topics.add(answer)

        time_line.update(answer_from_followed_users | answer_from_followed_topics)
        time_line = list(time_line)

        # The search result stays at the top of the time line.
        search_result = self.searching(user)
        if search_result != None:
            if search_result in time_line:
                time_line.remove(search_result)
            time_line.insert(0, search_result)

        user.get_original_data_source(time_line)
        # print("For user %d, there are %d answers in the data source" % (user.id, len(time_line)))
        return time_line

    ###
    # Task:
    #     Recommend an answer to the given user.
    #     The recommendation is done with Apriori algorithm. One half from the reading records, the others from the
    #     voting records.
    #         Minimum support: 50%
    #         Minimum confidence: 50%
    # Parameters:
    #     user
    #         Type: User
    #         Meaning: The given user.
    # Return:
    #     Type: Set<Answer>
    #     Meaning: The recommended answers.
    ###
    def content_recommendation(self, user):
        # self.logger.info("[%s] Starts." % sys._getframe().f_code.co_name)
        recommendations = set()

        # Organise all reading records as transactions.
        reading_transactions = []
        for userA in self.user_network.nodes:
            reading_transaction = []
            answers_read = userA.get_answers_read_in_a_list()
            for answer in answers_read:
                reading_transaction.append(answer.id)
            reading_transaction = tuple(reading_transaction)
            if len(reading_transaction) > 0:
                reading_transactions.append(reading_transaction)

        # Construct the Apriori model for reading transactions and get the association rules.
        itemsets_reading, rules_reading = apriori(reading_transactions, min_support=0.5, min_confidence=0.5)

        # Get the recommendations based on reading transactions.
        answer_id_from_reading_recommendation = set()
        ## Get the related rules for this user.
        user_read_answers = user.get_answers_read_in_a_set()
        useful_rules_reading = []
        for rule in rules_reading:
            if len(set(rule.lhs).intersection(user_read_answers)) > 0:
                useful_rules_reading.append(rule)
        ## Get recommendations from the useful rules.
        for rule in useful_rules_reading:
            recommendation_set = set(rule.rhs)
            finished = False
            for recommendation in recommendation_set:
                if recommendation not in answer_id_from_reading_recommendation:
                    answer_id_from_reading_recommendation.add(recommendation)
                if len(answer_id_from_reading_recommendation) == 5:
                    finished = True
                    break
            if finished:
                break

        # Organise all voting records as transactions.
        voting_transactions = []
        for userA in self.user_network.nodes:
            voting_transaction = []
            answers_voted_for = userA.get_answers_voted_for_in_a_list()
            for answer in answers_voted_for:
                voting_transaction.append(answer.id)
            voting_transaction = tuple(voting_transaction)
            voting_transactions.append(voting_transaction)

        # Construct the Apriori model for voting transactions.
        itemsets_voting, rules_voting = apriori(voting_transactions, min_support=0.5, min_confidence=0.5)

        # Get the recommendations based on voting transactions and get the association rules.
        answer_id_from_voting_recommendation = set()
        ## Get the related rules for this user.
        user_voted_answers = user.get_answers_read_in_a_set()
        useful_rules_voting = []
        for rule in rules_voting:
            if len(set(rule.lhs).intersection(user_voted_answers)) > 0:
                useful_rules_voting.append(rule)
        ## Get recommendations from the useful rules.
        for rule in useful_rules_voting:
            recommendation_set = set(rule.rhs)
            finished = False
            for recommendation in recommendation_set:
                if recommendation not in answer_id_from_voting_recommendation:
                    answer_id_from_voting_recommendation.add(recommendation)
                if len(answer_id_from_voting_recommendation) == 5:
                    finished = True
                    break
            if finished:
                break

        recommendations.update(answer_id_from_reading_recommendation)
        recommendations.update(answer_id_from_voting_recommendation)
        return recommendations

    ###
    # Task:
    #     User searching. Pick a random question with focusing topic firstly. Pick the highest voted answer.
    # Parameters:
    #     user
    #         Type: User
    #         Meaning: The acting user.
    # Return:
    #     Type: Answer
    #     Meaning: The highest voted answer
    ###
    def searching(self, user):
        focusing_topic = user.get_focusing_topic()

        # Randomly pick a question with focusing topic.
        related_questions = set()
        for question in self.questions:
            if focusing_topic in question.get_related_topics():
                related_questions.add(question)
        if len(related_questions) == 0:
            return None
        question_chosen = random.choice(list(related_questions))

        # Pick the highest voted answer under that question.
        answer_candidate = question_chosen.get_answers()
        if len(answer_candidate) == 1:
            return answer_candidate.pop()
        elif len(answer_candidate) >= 2:
            highest_voted_answer_index = 0
            highest_vote = 0
            answer_candidate = list(answer_candidate)
            for index in range(len(answer_candidate)):
                answer = answer_candidate[index]
                current_votes = answer.get_up_vote_number()
                if current_votes > highest_vote:
                    highest_vote = current_votes
                    highest_voted_answer_index = index
            return answer_candidate[highest_voted_answer_index]
        return None


    ###
    # Task:
    #     Sort the timeline for current user. Pre-selection.
    # Parameters:
    #     user
    #         Type: User
    #         Meaning: Current user.
    #     timeline
    #         Type: List<Answer>
    #         Meaning: The timeline of current user without sorting.
    ###
    def data_presentation(self, user, timeline):
        # self.logger.info("[%s] Starts." % sys._getframe().f_code.co_name)
        if not self.recommender_algorithm_switch:
            user.get_sorted_time_line(timeline)
            # self.logger.warning("[%s] No recommender system." % sys._getframe().f_code.co_name)
            return timeline

        if len(timeline) <= 1:
            user.get_sorted_time_line(timeline)
            # self.logger.warning("[%s] Time line shorter than 1." % sys._getframe().f_code.co_name)
            return timeline

        # Searching result does not join in the ranking, it always stays at the top of the timeline.
        searching_result = timeline[0]
        new_timeline = timeline[1:]

        # Predictions given by the recommender system.
        predictions = dict()
        user_id = user.id
        for answer in new_timeline:
            answer_id = answer.id
            estimated_rating = self.recommending_algorithm_svd.predict(user_id, answer_id).est
            if user_id in self.user_item_matrix.df.user_id and answer_id in self.user_item_matrix.df.item_id:
                predictions[answer] = estimated_rating
            else:
                predictions[answer] = 0

        # Rank the timeline according to the predictions given by the recommender system.
        self.rank_answers_quick_sort(new_timeline, 0, len(new_timeline) - 1, predictions)

        new_timeline.insert(0, searching_result)
        user.get_sorted_time_line(new_timeline)

    def rank_answers_quick_sort(self, timeline, low_index, high_index, predictions):
        if low_index < high_index:
            pi = self.answer_partition_quick_sort(timeline, low_index, high_index, predictions)

            self.rank_answers_quick_sort(timeline, low_index, pi - 1, predictions)
            self.rank_answers_quick_sort(timeline, pi + 1, high_index, predictions)

    def answer_partition_quick_sort(self, timeline, low_index, high_index, predictions):
        i = (low_index - 1)
        pivot = predictions[timeline[high_index]]

        for j in range(low_index, high_index):
            if predictions[timeline[j]] >= pivot:
                i += 1
                timeline[j], timeline[i] = timeline[i], timeline[j]

        timeline[i + 1], timeline[high_index] = timeline[high_index], timeline[i + 1]

        return (i + 1)

    ###
    # Task:
    #     Current user receives a user recommendation. She/he has a probability to check this recommendation.
    # Parameters:
    #     user
    #         Type: User
    #         Meaning: Current user.
    ###
    def user_recommendation(self, user):
        # self.logger.info("[%s] Starts." % sys._getframe().f_code.co_name)
        if not self.recommender_algorithm_switch:
            # self.logger.warning("[%s] No recommender systems." % sys._getframe().f_code.co_name)
            return

        if self.training_set == None:
            # self.logger.warning("[%s] Empty training set." % sys._getframe().f_code.co_name)
            return
        inner_uid = self.training_set.to_inner_uid(user.id)
        recommendations = self.recommending_algorithm_KNN.get_neighbors(inner_uid, 1)
        if len(recommendations) == 1:
            recommended_user_id = self.training_set.to_raw_uid(recommendations[0])
            for userA in self.user_network.nodes:
                # The recommended user.
                if user != userA and userA.id == recommended_user_id:
                    user.get_recommended_user(userA)
                    return


    ###
    # Task:
    #     Update the recommender system at the end of each time step, to include the new user, answers and votes.
    ###
    def recommender_system_update(self):
        user_id_list = []
        answer_id_list = []
        voting_list = []
        users = list(self.user_network.nodes)
        for user_index in range(len(users)):
            user = users[user_index]
            for answer_index in range(len(self.answers)):
                answer = self.answers[answer_index]
                user_id_list.append(user.id)
                rating = 0
                answer_id_list.append(self.answers[answer_index].id)
                if answer.id in user.get_answers_read_in_a_set():
                    rating += 1
                if answer.id in user.get_answers_voted_for_in_a_set():
                    rating += 2
                voting_list.append(rating)
        data = {
            "user_id": user_id_list,
            "item_id": answer_id_list,
            "rating": voting_list
        }
        dataframe = pd.DataFrame(data)
        reader = Reader(rating_scale=(0, 3))
        self.user_item_matrix = Dataset.load_from_df(dataframe[["user_id", "item_id", "rating"]], reader)
        if len(user_id_list) == 0:
            self.training_set = None
            return
        self.training_set = self.user_item_matrix.build_full_trainset()
        self.recommending_algorithm_svd.fit(self.training_set)
        self.recommending_algorithm_KNN.fit(self.training_set)

    ###
    # Task:
    #     Gather users' outputs and form the result file.
    ###
    def gather_user_outputs(self):
        # self.logger.info("[%s] Starts." % sys._getframe().f_code.co_name)
        time_step_all_interested_topics_discovered_dict = {
            "user_id":[],
            "time_step":[]
        }
        user_interested_topic_dict = {
            "user_id": [],
            "topic1":[],
            "topic2":[],
            "topic3":[],
            "topic4":[],
            "topic5":[],
            "topic6":[],
            "topic7":[],
            "topic8":[],
            "topic9":[],
            "topic10":[]
        }
        user_interested_topics = dict()
        proportion_answer_by_topic_data_source_dict = {
            "time_step":[],
            "user_id":[],
            "topic_interested":[],
            "proportion":[]
        }
        proportion_answer_by_opinion_data_source_dict = {
            "time_step": [],
            "user_id": [],
            "opinion_difference": [],
            "proportion": []
        }
        proportion_user_by_topic_data_source_dict = {
            "time_step": [],
            "user_id": [],
            "topic_interested": [],
            "proportion": []
        }
        proportion_user_by_opinion_data_source_dict = {
            "time_step": [],
            "user_id": [],
            "opinion_difference": [],
            "proportion": []
        }
        average_ranking_position_answer_by_topic_dict = {
            "time_step": [],
            "user_id": [],
            "topic_interested": [],
            "ranking": []
        }
        average_ranking_position_answer_by_opinion_dict = {
            "time_step": [],
            "user_id": [],
            "opinion_difference": [],
            "ranking": []
        }
        average_ranking_position_user_by_topic_dict = {
            "time_step": [],
            "user_id": [],
            "topic_interested": [],
            "ranking": []
        }
        average_ranking_position_user_by_opinion_dict = {
            "time_step": [],
            "user_id": [],
            "opinion_difference": [],
            "ranking": []
        }
        proportion_answer_by_topic_read_dict = {
            "time_step": [],
            "user_id": [],
            "topic_interested": [],
            "proportion": []
        }
        proportion_answer_by_opinion_read_dict = {
            "time_step": [],
            "user_id": [],
            "opinion_difference": [],
            "proportion": []
        }
        proportion_user_by_topic_read_dict = {
            "time_step": [],
            "user_id": [],
            "topic_interested": [],
            "proportion": []
        }
        proportion_user_by_opinion_read_dict = {
            "time_step": [],
            "user_id": [],
            "opinion_difference": [],
            "proportion": []
        }
        for user in self.user_network.nodes:
            (interested_topics,
             time_step_all_interested_topics_discovered,
             proportion_answer_by_topic_data_source,
             proportion_answer_by_opinion_data_source,
             proportion_user_by_topic_data_source,
             proportion_user_by_opinion_data_source,
             average_ranking_position_answer_by_topic,
             average_ranking_position_answer_by_opinion,
             average_ranking_position_user_by_topic,
             average_ranking_position_user_by_opinion,
             proportion_answer_by_topic_read,
             proportion_answer_by_opinion_read,
             proportion_user_by_topic_read,
             proportion_user_by_opinion_read) = user.report_dependent_variables()

            # The time of all interested topics are discovered by the user.
            time_step_all_interested_topics_discovered_dict["user_id"].append(user.id)
            time_step_all_interested_topics_discovered_dict["time_step"].append(time_step_all_interested_topics_discovered)

            user_interested_topic_dict["user_id"].append(user.id)
            user_interested_topics[user.id] = set()
            topic_index = 1
            for topic in interested_topics:
                user_interested_topic_dict["topic%d" % topic_index].append(topic.id)
                user_interested_topics[user.id].add(topic.id)
                topic_index += 1

            # Data Source: Answer-Topic
            for time_step in proportion_answer_by_topic_data_source:
                interested_topic_proportions = []
                not_interested_topic_proportions = []
                for topic in proportion_answer_by_topic_data_source[time_step]:
                    proportion = proportion_answer_by_topic_data_source[time_step][topic]
                    if topic.id in user_interested_topics[user.id]:
                        interested_topic_proportions.append(proportion)
                    else:
                        not_interested_topic_proportions.append(proportion)
                if len(interested_topic_proportions) > 0:
                    proportion_answer_by_topic_data_source_dict["user_id"].append(user.id)
                    proportion_answer_by_topic_data_source_dict["time_step"].append(time_step)
                    proportion_answer_by_topic_data_source_dict["topic_interested"].append(True)
                    proportion_answer_by_topic_data_source_dict["proportion"].append(
                        np.mean(interested_topic_proportions))
                if len(not_interested_topic_proportions) > 0:
                    proportion_answer_by_topic_data_source_dict["user_id"].append(user.id)
                    proportion_answer_by_topic_data_source_dict["time_step"].append(time_step)
                    proportion_answer_by_topic_data_source_dict["topic_interested"].append(False)
                    proportion_answer_by_topic_data_source_dict["proportion"].append(
                        np.mean(not_interested_topic_proportions))

            # Data Source: Answer-Opinion
            for time_step in proportion_answer_by_opinion_data_source:
                for opinion_difference in proportion_answer_by_opinion_data_source[time_step]:
                    proportion_answer_by_opinion_data_source_dict["user_id"].append(user.id)
                    proportion_answer_by_opinion_data_source_dict["time_step"].append(time_step)
                    proportion_answer_by_opinion_data_source_dict["opinion_difference"].append(opinion_difference)
                    proportion = proportion_answer_by_opinion_data_source[time_step][opinion_difference]
                    proportion_answer_by_opinion_data_source_dict["proportion"].append(proportion)

            # Data Source: User-Topic
            for time_step in proportion_user_by_topic_data_source:
                interested_topic_proportions = []
                not_interested_topic_proportions = []
                for topic in proportion_user_by_topic_data_source[time_step]:
                    proportion = proportion_user_by_topic_data_source[time_step][topic]
                    if topic.id in user_interested_topics[user.id]:
                        interested_topic_proportions.append(proportion)
                    else:
                        not_interested_topic_proportions.append(proportion)
                if len(interested_topic_proportions) > 0:
                    proportion_user_by_topic_data_source_dict["user_id"].append(user.id)
                    proportion_user_by_topic_data_source_dict["time_step"].append(time_step)
                    proportion_user_by_topic_data_source_dict["topic_interested"].append(True)
                    proportion_user_by_topic_data_source_dict["proportion"].append(
                        np.mean(interested_topic_proportions))
                if len(not_interested_topic_proportions) > 0:
                    proportion_user_by_topic_data_source_dict["user_id"].append(user.id)
                    proportion_user_by_topic_data_source_dict["time_step"].append(time_step)
                    proportion_user_by_topic_data_source_dict["topic_interested"].append(False)
                    proportion_user_by_topic_data_source_dict["proportion"].append(
                        np.mean(not_interested_topic_proportions))

            # Data Source: User-Opinion
            for time_step in proportion_user_by_opinion_data_source:
                for opinion_difference in proportion_user_by_opinion_data_source[time_step]:
                    proportion_user_by_opinion_data_source_dict["user_id"].append(user.id)
                    proportion_user_by_opinion_data_source_dict["time_step"].append(time_step)
                    proportion_user_by_opinion_data_source_dict["opinion_difference"].append(opinion_difference)
                    proportion = proportion_user_by_opinion_data_source[time_step][opinion_difference]
                    proportion_user_by_opinion_data_source_dict["proportion"].append(proportion)

            # Data Presentation: Answer-Topic
            for time_step in average_ranking_position_answer_by_topic:
                interested_topic_rankings = []
                not_interested_topic_rankings = []
                for topic in average_ranking_position_answer_by_topic[time_step]:
                    ranking = average_ranking_position_answer_by_topic[time_step][topic]
                    if topic.id in user_interested_topics[user.id]:
                        interested_topic_rankings.append(ranking)
                    else:
                        not_interested_topic_rankings.append(ranking)
                if len(interested_topic_rankings) > 0:
                    average_ranking_position_answer_by_topic_dict["user_id"].append(user.id)
                    average_ranking_position_answer_by_topic_dict["time_step"].append(time_step)
                    average_ranking_position_answer_by_topic_dict["topic_interested"].append(True)
                    average_ranking_position_answer_by_topic_dict["ranking"].append(
                        np.mean(interested_topic_rankings))
                if len(not_interested_topic_rankings) > 0:
                    average_ranking_position_answer_by_topic_dict["user_id"].append(user.id)
                    average_ranking_position_answer_by_topic_dict["time_step"].append(time_step)
                    average_ranking_position_answer_by_topic_dict["topic_interested"].append(False)
                    average_ranking_position_answer_by_topic_dict["ranking"].append(
                        np.mean(not_interested_topic_rankings))

            # Data Presentation: Answer-Opinion
            for time_step in average_ranking_position_answer_by_opinion:
                for opinion_difference in average_ranking_position_answer_by_opinion[time_step]:
                    average_ranking_position_answer_by_opinion_dict["user_id"].append(user.id)
                    average_ranking_position_answer_by_opinion_dict["time_step"].append(time_step)
                    average_ranking_position_answer_by_opinion_dict["opinion_difference"].append(opinion_difference)
                    ranking = average_ranking_position_answer_by_opinion[time_step][opinion_difference]
                    average_ranking_position_answer_by_opinion_dict["ranking"].append(ranking)

            # Data Presentation: User-Topic
            for time_step in average_ranking_position_user_by_topic:
                interested_topic_rankings = []
                not_interested_topic_rankings = []
                for topic in average_ranking_position_user_by_topic[time_step]:
                    ranking = average_ranking_position_user_by_topic[time_step][topic]
                    if topic.id in user_interested_topics[user.id]:
                        interested_topic_rankings.append(ranking)
                    else:
                        not_interested_topic_rankings.append(ranking)
                if len(interested_topic_rankings) > 0:
                    average_ranking_position_user_by_topic_dict["user_id"].append(user.id)
                    average_ranking_position_user_by_topic_dict["time_step"].append(time_step)
                    average_ranking_position_user_by_topic_dict["topic_interested"].append(True)
                    average_ranking_position_user_by_topic_dict["ranking"].append(
                        np.mean(interested_topic_rankings))
                if len(not_interested_topic_rankings) > 0:
                    average_ranking_position_user_by_topic_dict["user_id"].append(user.id)
                    average_ranking_position_user_by_topic_dict["time_step"].append(time_step)
                    average_ranking_position_user_by_topic_dict["topic_interested"].append(False)
                    average_ranking_position_user_by_topic_dict["ranking"].append(
                        np.mean(not_interested_topic_rankings))

            # Data Presentation: User-Opinion
            for time_step in average_ranking_position_user_by_opinion:
                for opinion_difference in average_ranking_position_user_by_opinion[time_step]:
                    average_ranking_position_user_by_opinion_dict["user_id"].append(user.id)
                    average_ranking_position_user_by_opinion_dict["time_step"].append(time_step)
                    average_ranking_position_user_by_opinion_dict["opinion_difference"].append(opinion_difference)
                    ranking = average_ranking_position_user_by_opinion[time_step][opinion_difference]
                    average_ranking_position_user_by_opinion_dict["ranking"].append(ranking)

            # Reading Decision: Answer-Topic
            for time_step in proportion_answer_by_topic_read:
                interested_topic_proportions = []
                not_interested_topic_proportions = []
                for topic in proportion_answer_by_topic_read[time_step]:
                    proportion = proportion_answer_by_topic_read[time_step][topic]
                    if topic.id in user_interested_topics[user.id]:
                        interested_topic_proportions.append(proportion)
                    else:
                        not_interested_topic_proportions.append(proportion)
                if len(interested_topic_proportions) > 0:
                    proportion_answer_by_topic_read_dict["user_id"].append(user.id)
                    proportion_answer_by_topic_read_dict["time_step"].append(time_step)
                    proportion_answer_by_topic_read_dict["topic_interested"].append(True)
                    proportion_answer_by_topic_read_dict["proportion"].append(
                        np.mean(interested_topic_proportions))
                if len(not_interested_topic_proportions) > 0:
                    proportion_answer_by_topic_read_dict["user_id"].append(user.id)
                    proportion_answer_by_topic_read_dict["time_step"].append(time_step)
                    proportion_answer_by_topic_read_dict["topic_interested"].append(False)
                    proportion_answer_by_topic_read_dict["proportion"].append(
                        np.mean(not_interested_topic_proportions))

            # Reading Decision: Answer-Opinion
            for time_step in proportion_answer_by_opinion_read:
                for opinion_difference in proportion_answer_by_opinion_read[time_step]:
                    proportion_answer_by_opinion_read_dict["user_id"].append(user.id)
                    proportion_answer_by_opinion_read_dict["time_step"].append(time_step)
                    proportion_answer_by_opinion_read_dict["opinion_difference"].append(opinion_difference)
                    proportion = proportion_answer_by_opinion_read[time_step][opinion_difference]
                    proportion_answer_by_opinion_read_dict["proportion"].append(proportion)

            # Reading Decision: User-Topic
            for time_step in proportion_user_by_topic_read:
                interested_topic_proportions = []
                not_interested_topic_proportions = []
                for topic in proportion_user_by_topic_read[time_step]:
                    proportion = proportion_user_by_topic_read[time_step][topic]
                    if topic.id in user_interested_topics[user.id]:
                        interested_topic_proportions.append(proportion)
                    else:
                        not_interested_topic_proportions.append(proportion)
                if len(interested_topic_proportions) > 0:
                    proportion_user_by_topic_read_dict["user_id"].append(user.id)
                    proportion_user_by_topic_read_dict["time_step"].append(time_step)
                    proportion_user_by_topic_read_dict["topic_interested"].append(True)
                    proportion_user_by_topic_read_dict["proportion"].append(
                        np.mean(interested_topic_proportions))
                if len(not_interested_topic_proportions) > 0:
                    proportion_user_by_topic_read_dict["user_id"].append(user.id)
                    proportion_user_by_topic_read_dict["time_step"].append(time_step)
                    proportion_user_by_topic_read_dict["topic_interested"].append(False)
                    proportion_user_by_topic_read_dict["proportion"].append(
                        np.mean(not_interested_topic_proportions))

            # Reading Decision: User-Opinion
            for time_step in proportion_user_by_opinion_read:
                for opinion_difference in proportion_user_by_opinion_read[time_step]:
                    proportion_user_by_opinion_read_dict["user_id"].append(user.id)
                    proportion_user_by_opinion_read_dict["time_step"].append(time_step)
                    proportion_user_by_opinion_read_dict["opinion_difference"].append(opinion_difference)
                    proportion = proportion_user_by_opinion_read[time_step][opinion_difference]
                    proportion_user_by_opinion_read_dict["proportion"].append(proportion)

        df_discover_time = pd.DataFrame(time_step_all_interested_topics_discovered_dict)
        df_discover_time.to_csv(self.result_dir_path + os.sep + "topic_discover_time.csv")

        df_interested_topics = pd.DataFrame(user_interested_topic_dict)
        df_interested_topics.to_csv(self.result_dir_path + os.sep + "user_interested_topics.csv")

        df_data_source_answer_topic = pd.DataFrame(proportion_answer_by_topic_data_source_dict)
        df_data_source_answer_topic.to_csv(self.result_dir_path + os.sep + "data_source_answer_topic.csv")
        df_data_source_answer_opinion = pd.DataFrame(proportion_answer_by_opinion_data_source_dict)
        df_data_source_answer_opinion.to_csv(self.result_dir_path + os.sep + "data_source_answer_opinion.csv")
        df_data_source_user_topic = pd.DataFrame(proportion_user_by_topic_data_source_dict)
        df_data_source_user_topic.to_csv(self.result_dir_path + os.sep + "data_source_user_topic.csv")
        df_data_source_user_opinion = pd.DataFrame(proportion_user_by_opinion_data_source_dict)
        df_data_source_user_opinion.to_csv(self.result_dir_path + os.sep + "data_source_user_opinion.csv")

        df_data_presentation_answer_topic = pd.DataFrame(average_ranking_position_answer_by_topic_dict)
        df_data_presentation_answer_topic.to_csv(self.result_dir_path + os.sep + "data_presentation_answer_topic.csv")
        df_data_presentation_answer_opinion = pd.DataFrame(average_ranking_position_answer_by_opinion_dict)
        df_data_presentation_answer_opinion.to_csv(self.result_dir_path + os.sep + "data_presentation_answer_opinion.csv")
        df_data_presentation_user_topic = pd.DataFrame(average_ranking_position_user_by_topic_dict)
        df_data_presentation_user_topic.to_csv(self.result_dir_path + os.sep + "data_presentation_user_topic.csv")
        df_data_presentation_user_opinion = pd.DataFrame(average_ranking_position_user_by_opinion_dict)
        df_data_presentation_user_opinion.to_csv(self.result_dir_path + os.sep + "data_presentation_user_opinion.csv")

        df_reading_decision_answer_topic = pd.DataFrame(proportion_answer_by_topic_read_dict)
        df_reading_decision_answer_topic.to_csv(self.result_dir_path + os.sep + "reading_decision_answer_topic.csv")
        df_reading_decision_answer_opinion = pd.DataFrame(proportion_answer_by_opinion_read_dict)
        df_reading_decision_answer_opinion.to_csv(self.result_dir_path + os.sep + "reading_decision_answer_opinion.csv")
        df_reading_decision_user_topic = pd.DataFrame(proportion_user_by_topic_read_dict)
        df_reading_decision_user_topic.to_csv(self.result_dir_path + os.sep + "reading_decision_user_topic.csv")
        df_reading_decision_user_opinion = pd.DataFrame(proportion_user_by_opinion_read_dict)
        df_reading_decision_user_opinion.to_csv(self.result_dir_path + os.sep + "reading_decision_user_opinion.csv")

###
# Task:
#     The entrance of the whole model.
# Parameters:
#     sub_model
#         Position: 1
#         Meaning: Name of the sub-model
###
if __name__ == "__main__":
    # Config log file.
    # sub_model = sys.argv[1]
    # repetition = sys.argv[2]
    sub_model = "selection"
    repetition = "2"

    simulator = Simulator(sub_model, repetition)

    # Read sub model config
    return_code = simulator.reading_sub_model_config()
    if return_code < 0:
        exit(return_code)

    simulator.run()
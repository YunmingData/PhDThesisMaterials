#!/bin/bash

for i in {49..50..1}
do
	python3 main.py "algorithm" $i
done

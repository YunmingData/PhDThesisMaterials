#!/bin/bash

for i in {61..100..1}
do
	python3 main.py "influence" $i
done

# -*- coding: UTF-8 -*-
import sys
import time
import logging, logging.handlers
import random
from post import Question, Answer
from math import fabs
from numpy import mean

class User():
    ###
    # Task:
    #     The constructor of the User class.
    # Parameters:
    #     id
    #         Type: String
    #         Meaning: ID of this user.
    #     log_dir_path
    #         Type: String
    #         Meaning: The path to put the log files.
    #     result_dir_path
    #         Type: String
    #         Meaning: The path to put the result files.
    #     creation_time_step
    #         Type: Integer
    #         Meaning: The time step of this user's creation.
    #     interested_topics
    #         Type: Set<Topic>
    #         Meaning: A set of interested topics.
    #     interested_topics
    #         Type: Set<Topic>
    #         Meaning: A set of topics followed by the user.
    #     topic_opinions
    #         Type: <key, value>: <Topic, opinion in this topic>
    #         Meaning: User's default opinions in each topic.
    #     topic_expertise
    #         Type: <key, value>: <Topic, expertise in this topic>
    #         Meaning: User's default expertise in each topic.
    #     topic_space
    #         Type: networkx.DiGraph()
    #         Meaning: The topic network generated.
    #     social_influence_switch
    #         Type: Boolean
    #         Meaning: Whether the social selection is switched on.
    #     social_selection_switch
    #         Type: Boolean
    #         Meaning: Whether the social selection is switched on.
    #     ask_probability
    #         Type: Float
    #         Meaning: The probability of this user to ask a question in his time step.
    #     check_user_recommendation_probability
    #         Type: Float
    #         Meaning: The probability of this user to check the recommended user.
    #     max_user_following
    #         Type: Integer
    #         Meaning: If the social selection is switched off, this is the maximum number of user whom followed by
    #         the current user.
    #     acceptable_up_vote_number
    #         Type: Integer
    #         Meaning: The threshold of up vote number for an answer above which this user will pay attention to it.
    #     friend_up_vote_read_threshold
    #         Type: Integer
    #         Meaning: The threshold of the proportion of users followed by this user who have up voted to the answer.
    #             Above this threshold, this user will pay attention to the answer.
    #     acceptable_quality_threshold
    #         Type: Float
    #         Meaning: The threshold of answer quality above which this user will be more likely to vote for the answer.
    #     acceptable_opinion_threshold
    #         Type: Float
    #         Meaning: The threshold of opinion difference between this user and another user above which this user
    #             tends to be influenced by the other user.
    #     stubbornness
    #         Type: Float
    #         Meaning: The stubbornness of this user, representing how hard his opinions are influenced by others.
    #             Max: 1: Will never be influenced by others.
    #             Min: 0: Not assertive at all.
    ###
    def __init__(self, id, log_dir_path, result_dir_path, creation_time_step, interested_topics, following_topics,
                 topic_opinions, topic_expertise, topic_space, social_influence_switch = False,
                 social_selection_switch = False, ask_probability = 0.5, check_user_recommendation_probability = 0.5,
                 max_user_following = 10, acceptable_up_vote_number = 100, friend_up_vote_read_threshold = 0.5,
                 acceptable_quality_threshold = 0.5, acceptable_opinion_threshold = 0.33, stubbornness=0.5):
        # ========================================= Log Configurations =============================================== #
        self.log_dir_path = log_dir_path
        # logging.basicConfig(level = logging.DEBUG,
        #                     format = '%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
        #                     datefmt = '%a, %d %b %Y %H:%M:%S')
        # self.formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        # self.log_handler_debug = logging.FileHandler(filename = self.log_dir_path + "user_debug.log")
        # self.log_handler_debug.setLevel(logging.DEBUG)
        # self.log_handler_debug.setFormatter(self.formatter)
        # self.log_handler_info = logging.FileHandler(filename = self.log_dir_path + "user_info.log")
        # self.log_handler_info.setLevel(logging.INFO)
        # self.log_handler_info.setFormatter(self.formatter)
        # self.log_handler_warning = logging.FileHandler(filename = self.log_dir_path + "user_warning.log")
        # self.log_handler_warning.setLevel(logging.WARNING)
        # self.log_handler_warning.setFormatter(self.formatter)
        # self.log_handler_error = logging.FileHandler(filename = self.log_dir_path + "user_error.log")
        # self.log_handler_error.setLevel(logging.ERROR)
        # self.log_handler_error.setFormatter(self.formatter)
        # self.logger = logging.getLogger(__name__)
        # self.logger.addHandler(self.log_handler_debug)
        # self.logger.addHandler(self.log_handler_info)
        # self.logger.addHandler(self.log_handler_warning)
        # self.logger.addHandler(self.log_handler_error)

        # ======================================== Basic Configurations ============================================== #
        self.id = id
        self.interested_topics = set(interested_topics)
        self.following_topics = set(following_topics)
        self.topic_opinions = topic_opinions
        self.topic_expertise = topic_expertise
        self.topic_space = topic_space
        self.social_influence_switch = social_influence_switch
        self.social_selection_switch = social_selection_switch
        self.max_user_following = max_user_following

        # ======================================= Behaviour Rule Related ============================================= #
        self.time_step = creation_time_step
        # Used in the beginning of each time step.
        self.max_read_energy = 10
        # The energy spent in getting input from the platform. How many questions and answers the user will read.
        self.read_energy = self.max_read_energy
        # The energy spent in outputting through the platform. How many questions and answers the user will publish.
        self.post_energy = 3
        # The probability of asking a question.
        self.ask_probability = ask_probability
        # The probability to check the recommended user.
        self.check_user_recommendation_probability = check_user_recommendation_probability
        # The highest available post id.
        self.post_id = 0
        # The threshold of up vote number for an answer above which this user will pay attention to it.
        self.acceptable_up_vote_number = acceptable_up_vote_number
        # The threshold of the proportion of users followed by this user who have up voted to the answer.
        #     Above this threshold, this user will pay attention to the answer.
        self.friend_up_vote_read_threshold = friend_up_vote_read_threshold
        # The threshold of answer quality above which this user will be more likely to vote for the answer.
        self.acceptable_quality_threshold = acceptable_quality_threshold
        # The threshold of opinion difference between this user and another user above which this user tends to be
        #     influenced by the other user.
        self.acceptable_opinion_threshold = acceptable_opinion_threshold
        # The stubbornness of this user, representing how hard his opinions are influenced by others.
        self.stubbornness = stubbornness

        # =========================================== Behaviour Record =============================================== #
        # The set of users followed by this user.
        self.user_following_me = set()
        # The set of users following this user.
        self.users_I_follow = set()
        # The unsorted timeline get from the system in each time step. <key, value> = <time_step, List<Answer>>.
        self.original_data_source = dict()
        # The sorted timeline get from the system in each time step. <key, value> = <time_step, List<Answer>>.
        self.sorted_time_line = dict()
        # The questions this user asked. <key, value> = <time_step, Question>.
        self.question_asked = dict()
        # The answers read by this user. <key, value> = <time_step, Set<Answer>>.
        self.answers_read = dict()
        # The answers posted by this user. <key, value> = <time_step, Set<Answer>>.
        self.answers_posted = dict()
        # The answers this user voted for. <key, value> = <time_step, Set<Answer>>
        self.answers_voted_for = dict()

        # ======================================= Dependent Variables Related ======================================== #
        # Opinion ranges. <key, value> = <index, Tuple: [min, max)>
        self.opinion_difference_range = {0: (0, 0.4),
                                         1: (0.4, 0.8),
                                         2: (0.8, 1.2),
                                         3: (1.2, 1.6),
                                         4: (1.6, 2)}
        # The User-Topic Opinion Matrix. <key, value> = <User, <Topic, opinion_difference>>.
        self.user_topic_opinion_matrix = dict()
        # The User-Topic Quality Matrix. <key, value> = <User, <Topic, expertise_in_topic>>>.
        self.user_topic_quality_matrix = dict()

        # =========================================== Dependent Variables ============================================ #
        # The time step in which this user has discovered all the topics he is interested in.
        self.time_step_all_interested_topics_discovered = -1
        # Dependent variables for data source phase.
        #     The proportion of answers for each topic in each time step.
        #     <key, value> = <time_step, <Topic, Proportion>>
        self.proportion_answer_by_topic_data_source = dict()
        #     The proportion of answers expressing each opinion range in each time step.
        #     <key, value> = <time_step, <Integer(opinion_difference_index), Proportion>>
        self.proportion_answer_by_opinion_data_source = dict()
        #     The proportion of users for each topic in each time step.
        #     <key, value> = <time_step, <Topic, Proportion>>
        self.proportion_user_by_topic_data_source = dict()
        #     The proportion of users holding each opinion range in each time step.
        #     <key, value> = <time_step, <Integer(opinion_difference_index), Proportion>>
        self.proportion_user_by_opinion_data_source = dict()

        # Dependent variables for data presentation phase.
        #     The average ranking position of the answers related to each topic.
        #     <key, value> = <time_step, <Topic, average_ranking>>
        self.average_ranking_position_answer_by_topic = dict()
        #     The average ranking position of the answers expressing specific opinion.
        #     <key, value> = <time_step, <Integer(opinion_difference_index), average_ranking>>
        self.average_ranking_position_answer_by_opinion = dict()
        #     The average ranking position of the answer providers related to each topic.
        #     <key, value> = <time_step, <Topic, average_ranking>>
        self.average_ranking_position_user_by_topic = dict()
        #     The average ranking position of the answer providers expressing specific opinion.
        #     <key, value> = <time_step, <Integer(opinion_difference_index), average_ranking>>
        self.average_ranking_position_user_by_opinion = dict()

        # Dependent variables for what the user has read.
        #     The proportion of answers related to specific topic in all the answers read by this user.
        #     <key, value> = <time_step, <Topic, proportion>>
        self.proportion_answer_by_topic_read = dict()
        #     The proportion of answers expressing specific opinion in all the answers read by this user.
        #     <key, value> = <time_step, <Integer(opinion_difference_index), proportion>>
        self.proportion_answer_by_opinion_read = dict()
        #     The proportion of answer providers related to specific topic in all the answer providers whose answers
        #         are read by this user.
        #     <key, value> = <time_step, <Topic, proportion>>
        self.proportion_user_by_topic_read = dict()
        #     The proportion of answer providers holing specific opinion in all the answer providers whose answers
        #         are read by this user.
        #     <key, value> = <time_step, <Integer(opinion_difference_index), proportion>>
        self.proportion_user_by_opinion_read = dict()
        # The output path.
        self.result_dir_path = result_dir_path

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        return self.id == other.id

    def __hash__(self):
        return hash(str(self.id))

    def __repr__(self):
        return "User %d" % self.id

    def __str__(self):
        return "User %d" % self.id

    def get_interested_topics(self):
        return self.interested_topics

    def get_topic_opinion(self, topic):
        return self.topic_opinions[topic]

    def get_max_user_following(self):
        return self.max_user_following

    def get_user_following_me(self):
        return self.user_following_me

    def follow_user(self, user):
        self.user_following_me.add(user)
        user.add_user_I_am_following(self)
        # self.logger.info("[%s] User %d follows user %d." % (sys._getframe().f_code.co_name, self.id, user.id))

    def unfollow_user(self, user):
        if user in self.user_following_me:
            self.user_following_me.remove(user)
            user.remove_user_I_am_following(self)
            # self.logger.info("[%s] User %d unfollows user %d." % (sys._getframe().f_code.co_name, self.id, user.id))

    def get_user_I_am_following(self):
        return self.users_I_follow

    def add_user_I_am_following(self, user):
        self.users_I_follow.add(user)

    def remove_user_I_am_following(self, user):
        if user in self.users_I_follow:
            self.users_I_follow.remove(user)

    def get_following_topics(self):
        return self.following_topics

    def follow_topic(self, topic):
        if topic in self.interested_topics:
            self.following_topics.add(topic)

    ###
    # Task:
    #     At the beginning of current time step, focus on another topic.
    #     It simulates current user's attention change in the real world.
    # Return:
    #     Type: Topic
    #     Meaning: Newly focusing topic in this time step.
    ###
    def changing_focusing_topic(self, time_step):
        # self.logger.info("[%s] Starts." % sys._getframe().f_code.co_name)
        self.time_step = time_step
        self.focusing_topic = random.choice(list(self.topic_space.nodes))
        # self.logger.info("[%s] User %d is now following Topic %d" %
        #                  (sys._getframe().f_code.co_name, self.id, self.focusing_topic.id))
        self.read_energy = self.max_read_energy
        return self.focusing_topic

    def get_focusing_topic(self):
        return self.focusing_topic

    def get_question_published(self):
        return self.question_asked

    def get_question_published_in_set(self):
        result = set()
        for time_step in self.question_asked:
            result.add(self.question_asked[time_step])
        return result

    def get_answers_read(self):
        return self.answers_read

    def get_answers_read_in_a_list(self):
        # As this is a list, there could be duplicated answers read by current user.
        result = []
        for time_step in self.answers_read:
            for answer in self.answers_read[time_step]:
                result.append(answer)
        return result

    def get_answers_read_in_a_set(self):
        result = set()
        for time_step in self.answers_read:
            result.update(self.answers_read[time_step])
        return result

    def get_answers_posted(self):
        return self.answers_posted

    def get_answers_posted_in_a_set(self):
        result = set()
        for time_step in self.answers_posted:
            result.update(self.answers_posted[time_step])
        return result

    def get_answers_voted_for(self):
        return self.answers_voted_for

    def get_answers_voted_for_in_a_set(self):
        result = set()
        for time_step in self.answers_voted_for:
            result.update(self.answers_voted_for[time_step])
        return result

    def get_answers_voted_for_in_a_list(self):
        result = []
        for time_step in self.answers_voted_for:
            for answer in self.answers_voted_for[time_step]:
                result.append(answer)
        return result

    def vote_for_answer(self, answer):
        if self.time_step not in self.answers_voted_for.keys():
            self.answers_voted_for[self.time_step] = set()
        self.answers_voted_for[self.time_step].add(answer)
        answer.vote_for(self.time_step, self)

    ###
    # Task:
    #     Publish a question.
    # Parameters:
    #     post_id
    #         Type: Integer
    #         Meaning: The available post ID.
    # Return:
    #     Type: Question
    #     Meaning: The question newly published.
    ###
    def asking(self, post_id):
        self.post_id = post_id
        choice = random.random()
        if choice < self.ask_probability:
            topics = [self.focusing_topic]
            # Add two random related topics.
            candidate_topics = set()
            for topic in self.topic_space.predecessors(self.focusing_topic):
                candidate_topics.add(topic)
            for topic in self.topic_space.successors(self.focusing_topic):
                candidate_topics.add(topic)
            while len(candidate_topics) < 2:
                candidate = random.choice(list(self.topic_space.nodes))
                while candidate in candidate_topics:
                    candidate = random.choice(list(self.topic_space.nodes))
                candidate_topics.add(candidate)
            topics.extend(random.sample(candidate_topics, 2))
            question = Question(id = self.post_id,
                                publisher = self,
                                publish_time = self.time_step,
                                related_topics = topics)
            self.question_asked[self.time_step] = question
            self.post_id += 1
            return question


    ###
    # Task:
    #     Publish an answer for a question.
    # Parameters:
    #     questions
    #         Type: List<Question>
    #         Meaning: The list of question published.
    # Return:
    #     List<Answer>: The answer newly published.
    ###
    def answering(self, questions):
        if len(questions) == 0:
            return []
        # Each user will post only one answer to each question.
        candidates = set()
        for question in questions:
            if not question.is_answered_by(self):
                candidates.add(question)

        # Determine how many answers to post.
        number = random.randint(1, self.post_energy)
        answers = []
        self.answers_posted[self.time_step] = set()

        # All questions will be answered.
        if len(candidates) < number:
            for question in candidates:
                answers.append(self.answer_question(question))
        # Choose some questions to answer.
        else:
            for question in random.sample(candidates, number):
                answers.append(self.answer_question(question))
        return answers

    ###
    # Task:
    #     Answer the given question.
    # Parameters:
    #     question
    #         Type:Question
    #         Meaning: The given question.
    # Returns:
    #     Type: Answer
    #     Meaning: The answer to this question.
    ###
    def answer_question(self, question):
        topics = question.get_related_topics()
        topic_opinions = dict()
        topic_qualities = dict()
        for topic in topics:
            opinion = self.topic_opinions[topic] + random.uniform(-0.2, 0.2)
            topic_opinions[topic] = opinion
            quality = self.topic_expertise[topic] + random.uniform(-0.1, 0.1)
            quality = quality if quality < 1 else 1
            quality = quality if quality > 0 else 0
            topic_qualities[topic] = quality
        answer = Answer(id=self.post_id,
                        publisher=self,
                        publish_time=self.time_step,
                        question=question,
                        topic_opinions=topic_opinions,
                        quality=topic_qualities)
        self.post_id += 1
        question.add_answer(answer)
        question.answered_by(self)
        self.answers_posted[self.time_step].add(answer)
        return answer

    ###
    # Task:
    #     Get the unsorted timeline from the system. This is only for the dependent variable calculation.
    # Parameters:
    #     timeline
    #         Type: List<Answer>
    #         Meaning: The unsorted timeline.
    ###
    def get_original_data_source(self, timeline):
        self.original_data_source[self.time_step] = timeline

    ###
    # Task:
    #     Get sorted timeline from the system, and form the current timeline with the old content.
    # Parameters:
    #     timeline
    #         Type: List<Answer>
    #         Meaning: The sorted timeline.
    ###
    def get_sorted_time_line(self, timeline):
        self.sorted_time_line[self.time_step] = timeline

    ###
    # Task:
    #     Get the system recommended user. This user has a probability to check it.
    # Parameters:
    #     user
    #         Type: User
    #         Meaning: The recommended user.
    ###
    def get_recommended_user(self, user):
        choice = random.random()
        if choice >= self.check_user_recommendation_probability:
            return
        answers = user.get_answers_posted_in_a_set()
        if len(answers) <= 3:
            answers_chosen = list(answers)
        else:
            answers_chosen = random.sample(answers, 3)
        for answer in answers_chosen:
            self.read_answer(answer)

    ###
    # Task:
    #     Reading decision, and the following behaviours.
    #     Update time step.
    ###
    def read(self):
        timeline = self.sorted_time_line[self.time_step]
        # Choose which answers to read.
        answers_chosen = self.choose_answers_to_read(timeline)

        # Read the answers and decide whether to vote for them.
        for answer in answers_chosen:
            friends_up_voted = self.get_friends_up_voted(answer)
            self.read_answer(answer)
            self.voting_decision(answer, friends_up_voted)

        # After reading and voting.
        self.update_perceived_user_profile()
        self.update_following_status()
        self.calculate_dependent_variables()
        return self.post_id

    ###
    # Task:
    #     Choose some answer to read.
    # Parameters:
    #     timeline:
    #         Type: List<Answer>
    #         Meaning: The candidate answers from which to choose.
    # Returns:
    #     Type: Set<Answer>
    #     Meaning: The set of answers chosen to read.
    ###
    def choose_answers_to_read(self, timeline):
        # All remaining answers will be read.
        if len(timeline) == 0:
            return set()
        if self.read_energy >= len(timeline):
            return set(timeline)
        # <key, value> = <Answer, decision_index>
        decision_indices = dict()
        ## The answers will never be read according to the calculation.
        answers_not_interested = []
        ## The answers to be read.
        answers_to_read = []
        for answer in timeline:
            friends_up_voted = self.get_friends_up_voted(answer)
            decision_index = self.reading_decision(answer, friends_up_voted)
            if decision_index > 0:
                answers_to_read.append(answer)
                decision_indices[answer] = decision_index
            else:
                answers_not_interested.append(answer)
        result = set()
        if len(decision_indices) <= self.read_energy:
            result.update(decision_indices.keys())
            result.update(set(random.sample(answers_not_interested, (self.read_energy - len(decision_indices)))))
            return result
        else:
            self.rank_answers_for_reading_decision_quick_sort(answers_to_read, 0, len(answers_to_read)-1,
                                                              decision_indices)
            for i in range(self.read_energy):
                result.add(answers_to_read[i])
            return result

    def rank_answers_for_reading_decision_quick_sort(self, answers, low_index, high_index, decision_indices):
        if low_index < high_index:
            pi = self.answer_partition_quick_sort_for_reading_decision(answers, low_index, high_index, decision_indices)

            self.rank_answers_for_reading_decision_quick_sort(answers, low_index, pi - 1, decision_indices)
            self.rank_answers_for_reading_decision_quick_sort(answers, pi + 1, high_index, decision_indices)

    def answer_partition_quick_sort_for_reading_decision(self, answers, low_index, high_index, decision_indices):
        i = (low_index - 1)
        pivot = decision_indices[answers[high_index]]

        for j in range(low_index, high_index):
            if decision_indices[answers[j]] >= pivot:
                i += 1
                answers[j], answers[i] = answers[i], answers[j]

        answers[i + 1], answers[high_index] = answers[high_index], answers[i + 1]
        return (i+1)

    ###
    # Task:
    #     Get the users followed by this user and up-voted for the given answer.
    # Parameters:
    #     answer
    #         Type: Answer.
    #         Meaning: The given answer.
    # Return:
    #     Type: Set<User>
    #     Meaning: The users followed by this user and up-voted for the given answer.
    ###
    def get_friends_up_voted(self, answer):
        friends_up_voted = set()
        up_votes = answer.get_up_votes()
        for time_step in up_votes:
            up_voters_at_that_time = up_votes[time_step]
            friends_up_voted_at_that_time = self.users_I_follow.intersection(up_voters_at_that_time)
            friends_up_voted.update(friends_up_voted_at_that_time)
        return friends_up_voted

    ###
    # Task:
    #     Decide whether to read this answer.
    # Parameters:
    #     answer
    #         Type: Answer
    #         Meaning: The answer being judged.
    #     friends_up_voted
    #         Type: Set<User>
    #         Meaning: The users followed by this user and have up-voted for the given answer.
    # Return:
    #     Return 1:
    #         Type: Float
    #         Meaning: The decision index.
    ###
    def reading_decision(self, answer, friends_up_voted):
        # Number of topics interested by this user.
        number_topic_interested = 0
        question = answer.get_question()
        topics = question.get_related_topics()
        for topic in topics:
            if topic in self.interested_topics:
                number_topic_interested += 1
        decision_topic = number_topic_interested / 3

        if self.social_influence_switch:
            # Contextual social influence.
            up_vote_number = answer.get_up_vote_number()
            if up_vote_number > self.acceptable_up_vote_number:
                contextual_social_influence = (up_vote_number - self.acceptable_up_vote_number) / \
                                              self.acceptable_up_vote_number
            else:
                contextual_social_influence = 0


            # Specific social influence from the users followed by this user.
            if len(self.users_I_follow) == 0:
                specific_social_influence = 0
            else:
                proportion_friend_up_voted = len(friends_up_voted) / len(self.users_I_follow)
                if proportion_friend_up_voted > self.friend_up_vote_read_threshold:
                    specific_social_influence = (proportion_friend_up_voted - self.friend_up_vote_read_threshold) / \
                                                self.friend_up_vote_read_threshold
                else:
                    specific_social_influence = 0
        else:
            contextual_social_influence = 0
            specific_social_influence = 0

        decision_index = decision_topic * 0.5 + contextual_social_influence * 0.25 + specific_social_influence * 0.25
        return decision_index

    ###
    # Task:
    #     Read the answer. This movement will be called if the user is checking the recommended user.
    #     It costs read_energy.
    # Parameters:
    #     answer
    #         Type: Answer
    #         Meaning: The answer being judged.
    ###
    def read_answer(self, answer):
        self.read_energy -= 1

        question = answer.get_question()
        topics = question.get_related_topics()
        for topic in topics:
            ## Found a new unfollowed interesting topic, follow it.
            if topic in self.interested_topics and topic not in self.following_topics:
                self.follow_topic(topic)
        ## Have found all the interested topics.
        if len(self.interested_topics) == self.following_topics:
            self.time_step_all_interested_topics_discovered = self.time_step

        if self.time_step not in self.answers_read.keys():
            self.answers_read[self.time_step] = set()
        self.answers_read[self.time_step].add(answer)

    ###
    # Task:
    #     Decide whether to vote for the answer.
    # Parameters:
    #     answer
    #         Type: Answer
    #         Meaning: The answer being judged.
    #     friends_up_voted
    #         Type: Set<User>
    #         Meaning: The users followed by this user and have up-voted for the given answer.
    ###
    def voting_decision(self, answer, friends_up_voted):
        question = answer.get_question()
        related_topics = question.get_related_topics()
        # Judgement of quality.
        quality = answer.get_quality()
        quality_judgements = []
        for topic in related_topics:
            quality_answer = quality[topic]
            quality_judgements.append((quality_answer - self.acceptable_quality_threshold)
                                     / self.acceptable_quality_threshold)
        judgement_of_quality = mean(quality_judgements)

        # Judgement of opinion.
        if self.social_influence_switch:
            ## Calculate the specific social influence from users this user follows.
            SI_s = []
            for user in friends_up_voted:
                social_influence_from_this_user = 0
                if user in self.user_topic_opinion_matrix.keys():
                    user_opinions = self.user_topic_opinion_matrix[user]
                    for topic in related_topics:
                        self_opinion = self.topic_opinions[topic]
                        if topic in user_opinions.keys():
                            user_opinion = user_opinions[topic]
                            opinion_difference = fabs(self_opinion - user_opinion)
                        else:
                            opinion_difference = 0
                        social_influence_from_this_user += \
                            (opinion_difference - self.acceptable_opinion_threshold) / self.acceptable_opinion_threshold
                    social_influence_from_this_user = social_influence_from_this_user / 3
                    social_influence_from_this_user = 0 if social_influence_from_this_user < 0 \
                        else social_influence_from_this_user
                else:
                    social_influence_from_this_user = 1
                SI_s.append(social_influence_from_this_user)
            if len(SI_s) == 0:
                specific_social_influence = 0
            else:
                specific_social_influence = mean(SI_s)
            ## This user's opinions are influenced by the answer he reads.
            opinion_change_coefficient = (1-self.stubbornness) * specific_social_influence
            for topic in related_topics:
                answer_opinion = answer.get_topic_opinion()[topic]
                self.topic_opinions[topic] += opinion_change_coefficient * (answer_opinion - self.topic_opinions[topic])
        ## Judgement of opinion.
        judgements = []
        for topic in related_topics:
            answer_opinion = answer.get_topic_opinion()[topic]
            judgement = fabs(self.topic_opinions[topic] - answer_opinion) - self.acceptable_opinion_threshold
            judgements.append(judgement)
        judgement_of_opinion = mean(judgements)

        # Decide whether to vote for the answer.
        decision_index = judgement_of_quality * 0.5 + judgement_of_opinion * 0.5
        if decision_index > 0:
            decision = random.random()
            if decision < decision_index:
                self.vote_for_answer(answer)

    ###
    # Task:
    #     Update perceived user profiles, including the User-Topic Opinion Matrix and the User-Topic Quality Matrix.
    ###
    def update_perceived_user_profile(self):
        if self.time_step not in self.answers_read.keys():
            return

        answers_read = self.answers_read[self.time_step]

        # Update the User-Topic Opinion Matrix.
        for answer in answers_read:
            answer_opinions = answer.get_topic_opinion()
            ## Update perceived opinions of the answer provider.
            answer_provider = answer.get_publisher()
            for topic in answer_opinions:
                answer_opinion = answer_opinions[topic]
                if answer_provider not in self.user_topic_opinion_matrix.keys():
                    self.user_topic_opinion_matrix[answer_provider] = dict()
                    self.user_topic_opinion_matrix[answer_provider][topic] = answer_opinion
                else:
                    if topic in self.user_topic_opinion_matrix[answer_provider].keys():
                        self.user_topic_opinion_matrix[answer_provider][topic] = \
                            (self.user_topic_opinion_matrix[answer_provider][topic] + answer_opinion) / 2
                    else:
                        self.user_topic_opinion_matrix[answer_provider][topic] = answer_opinion

            ## Update the peceived opinions of users who voted for the answers.
            friends_up_voted = self.get_friends_up_voted(answer)
            for user in friends_up_voted:
                if user not in self.user_topic_opinion_matrix.keys():
                    self.user_topic_opinion_matrix[user] = dict()
                for topic in answer_opinions:
                    answer_opinion = answer_opinions[topic]
                    if topic in self.user_topic_opinion_matrix[user].keys():
                        change = (answer_opinion - self.user_topic_opinion_matrix[user][topic]) * 0.1
                        self.user_topic_opinion_matrix[user][topic] += change
                    else:
                        self.user_topic_opinion_matrix[user][topic] = answer_opinion

        # Update the User-Topic Quality Matrix.
        for answer in answers_read:
            answer_provider = answer.get_publisher()
            topic_qualities = answer.get_quality()
            if answer_provider in self.user_topic_quality_matrix.keys():
                for topic in topic_qualities:
                    if topic in self.user_topic_quality_matrix[answer_provider].keys():
                        self.user_topic_quality_matrix[answer_provider][topic] = \
                            (self.user_topic_quality_matrix[answer_provider][topic] + topic_qualities[topic]) / 2
                    else:
                        self.user_topic_quality_matrix[answer_provider][topic] = topic_qualities[topic]
            else:
                self.user_topic_quality_matrix[answer_provider] = dict()
                for topic in topic_qualities:
                    self.user_topic_quality_matrix[answer_provider][topic] = topic_qualities[topic]

    ###
    # Task:
    #     If social selection is switched on, follow and unfollow users according to the User-Topic Opinion Matrix and
    #     the User-Quality Matrix.
    ###
    def update_following_status(self):
        # Only works if the social selection is switched on.
        if not self.social_selection_switch:
            return

        if self.time_step not in self.answers_read.keys():
            return
        answers_read = self.answers_read[self.time_step]
        # Get all the answer providers and the up-voters for the answers read by this user in this time step.
        candidates = set()
        for answer in answers_read:
            candidates.add(answer.get_publisher())
            candidates.update(self.get_friends_up_voted(answer))

        # Update the following statuses.
        for user in candidates:
            ## Calculate the average quality.
            qualities = []
            if user not in self.user_topic_quality_matrix.keys():
                average_quality = 0.5
            else:
                for topic in self.user_topic_quality_matrix[user]:
                    qualities.append(self.user_topic_quality_matrix[user][topic])
                average_quality = mean(qualities)

            ## Calculate the average opinion difference.
            if user not in self.user_topic_opinion_matrix.keys():
                average_difference = 0
            else:
                opinion_differences = []
                for topic in self.user_topic_opinion_matrix[user]:
                    difference = fabs(self.user_topic_opinion_matrix[user][topic] - self.topic_opinions[topic])
                    opinion_differences.append(difference)
                if len(opinion_differences) == 0:
                    average_difference = 0
                else:
                    average_difference = mean(opinion_differences)

            ## Unfollow the user who fails to meet the following requirements.
            if user in self.users_I_follow:
                if average_quality < self.acceptable_quality_threshold \
                        or average_difference > self.acceptable_opinion_threshold:
                    self.unfollow_user(user)
            ## Follow the user who meets the following requirements.
            else:
                if average_quality >= self.acceptable_quality_threshold \
                        and average_difference <= self.acceptable_opinion_threshold:
                    self.follow_user(user)

    ###
    # Task:
    #     Calculate and store the values of dependent variables.
    ###
    def calculate_dependent_variables(self):
        self.calculate_dependent_variables_for_data_source()
        self.calculate_dependent_variables_for_data_presentation()
        self.calculate_dependent_variables_for_reading_decision()

    ###
    # Task:
    #     Calculate and store the values of dependent variables for data source.
    #     This phase is about the original unsorted time line.
    #     It's result from both pre-selection and self-selection.
    ###
    def calculate_dependent_variables_for_data_source(self):
        timeline = self.original_data_source[self.time_step]
        if len(timeline) == 0:
            return
        self.calculate_proportion_answer_by_topic_data_source(timeline)
        self.calculate_proportion_answer_by_opinion_data_source(timeline)
        self.calculate_proportion_user_by_topic_data_source(timeline)
        self.calculate_proportion_user_by_opinion_data_source(timeline)

    ###
    # Task:
    #     Calculate the proportion of the answers for each topic in current time step.
    #     N: number of answers in the time line.
    #     Ni: number of answers whose questions are related to topic i in the time line.
    #     <key, value> = <topic i, Ni/N>
    # Parameters:
    #     timeline
    #         Type: List<Answer>
    #         Meaning: The original unsorted time line.
    ###
    def calculate_proportion_answer_by_topic_data_source(self, timeline):
        # <key, value> = <topic i, Ni/N>
        self.proportion_answer_by_topic_data_source[self.time_step] = dict()
        # <key, value> = <topic i, Ni>
        Ni_dict = dict()
        for answer in timeline:
            question = answer.get_question()
            related_topics = question.get_related_topics()
            for topic in related_topics:
                if topic not in Ni_dict.keys():
                    Ni_dict[topic] = 1
                else:
                    Ni_dict[topic] += 1
        N = len(timeline)
        for topic in Ni_dict:
            proportion = Ni_dict[topic] / N
            self.proportion_answer_by_topic_data_source[self.time_step][topic] = proportion


    ###
    # Task:
    #     Calculate the proportion of the answers for each opinion range in current time step.
    #     N: number of answers in the time line.
    #     diff_opinion: average opinion difference between the answer and current user. Ordinal variable, gap between
    #         each two values is 0.4.
    #     Nd: number of answers with the diff_opinion == d.
    #     <key, value> = <diff_opinion, Nd/N>
    # Parameters:
    #     timeline
    #         Type: List<Answer>
    #         Meaning: The original unsorted time line.
    ###
    def calculate_proportion_answer_by_opinion_data_source(self, timeline):
        # <key, value> = <diff_opinion, Nd/N>
        self.proportion_answer_by_opinion_data_source[self.time_step] = dict()
        # <key, value> = <diff_opinion, Nd>
        Nd_dict = dict()
        for answer in timeline:
            opinion_differences = []
            topic_opinions = answer.get_topic_opinion()
            for topic in topic_opinions:
                answer_opinion = topic_opinions[topic]
                user_opinion = self.topic_opinions[topic]
                difference = fabs(user_opinion - answer_opinion)
                opinion_differences.append(difference)
            average_difference = mean(opinion_differences)
            # Get the range index.
            for index in self.opinion_difference_range:
                if average_difference >= self.opinion_difference_range[index][0] \
                        and average_difference < self.opinion_difference_range[index][1]:
                    if index not in Nd_dict.keys():
                        Nd_dict[index] = 1
                    else:
                        Nd_dict[index] += 1
                    break
        N = len(timeline)
        for index in Nd_dict:
            proportion = Nd_dict[index] / N
            self.proportion_answer_by_opinion_data_source[self.time_step][index] = proportion

    ###
    # Task:
    #     Calculate the proportion of the users interested in each topic in current time step.
    #     N: number of occurrences of users whose answers appear in the time line.
    #     Ni: number of users whose answers' questions are related to topic i in the time line.
    #     <key, value> = <topic i, Ni/N>
    # Parameters:
    #     timeline
    #         Type: List<Answer>
    #         Meaning: The original unsorted time line.
    ###
    def calculate_proportion_user_by_topic_data_source(self, timeline):
        user_occurrence_list = []
        for answer in timeline:
            question = answer.get_question()
            user = question.get_publisher()
            user_occurrence_list.append(user)
        N = len(user_occurrence_list)
        # <key, value> = <topic i, Ni/N>
        self.proportion_user_by_topic_data_source[self.time_step] = dict()
        # <key, value> = <topic i, Ni>
        Ni_dict = dict()
        for user in user_occurrence_list:
            following_topics = user.get_following_topics()
            for topic in following_topics:
                if topic not in Ni_dict.keys():
                    Ni_dict[topic] = 1
                else:
                    Ni_dict[topic] += 1
        for topic in Ni_dict:
            proportion = Ni_dict[topic] / N
            self.proportion_user_by_topic_data_source[self.time_step][topic] = proportion

    ###
    # Task:
    #     Calculate the proportion of the users holding each opinion range in current time step.
    #     N: number of users whose answers appear in the time line.
    #     diff_opinion: average opinion difference between the user and current user. Ordinal variable, gap between each
    #         two values is 0.4.
    #     Nd: number of users with the diff_opinion == d.
    #     <key, value> = <diff_opinion, Nd/N>
    # Parameters:
    #     timeline
    #         Type: List<Answer>
    #         Meaning: The original unsorted time line.
    ###
    def calculate_proportion_user_by_opinion_data_source(self, timeline):
        user_occurrence_list = []
        for answer in timeline:
            question = answer.get_question()
            user = question.get_publisher()
            user_occurrence_list.append(user)
        N = len(user_occurrence_list)

        # <key, value> = <diff_opinion, Nd/N>
        self.proportion_user_by_opinion_data_source[self.time_step] = dict()
        # <key, value> = <diff_opinion, Nd>
        Nd_dict = dict()
        for user in user_occurrence_list:
            differences = []
            if user in self.user_topic_opinion_matrix.keys():
                opinion_matrix = self.user_topic_opinion_matrix[user]
                for topic in opinion_matrix:
                    self_opinion = self.topic_opinions[topic]
                    if topic in opinion_matrix.keys():
                        user_opinion = opinion_matrix[topic]
                        differences.append(fabs(self_opinion - user_opinion))
            else:
                for topic in self.topic_opinions:
                    differences.append(fabs(self.topic_opinions[topic]))
            if len(differences) == 0:
                average_difference = 0
            else:
                average_difference = mean(differences)
            for index in self.opinion_difference_range:
                if average_difference >= self.opinion_difference_range[index][0] \
                        and average_difference < self.opinion_difference_range[index][1]:
                    if index not in Nd_dict.keys():
                        Nd_dict[index] = 1
                    else:
                        Nd_dict[index] += 1
                    break
        for index in Nd_dict:
            proportion = Nd_dict[index] / N
            self.proportion_user_by_opinion_data_source[self.time_step][index] = proportion


    ###
    # Task:
    #     Calculate and store the values of dependent variables for data presentation.
    #     This phase is about the sorted time line.
    #     It's result from only pre-selection.
    ###
    def calculate_dependent_variables_for_data_presentation(self):
        timeline = self.sorted_time_line[self.time_step]
        if len(timeline) == 0:
            return
        self.calculate_average_ranking_position_answer_by_topic(timeline)
        self.calculate_average_ranking_position_answer_by_opinion(timeline)
        self.calculate_average_ranking_position_user_by_topic(timeline)
        self.calculate_average_ranking_position_user_by_opinion(timeline)

    ###
    # Task:
    #     Calculate the average ranking of the answers related to each topic.
    #     Ai: the answer in the time line whose question is related to topic i.
    #     Ra: ranking position of Ai.
    #     Ri: average(Ra) for topic i.
    #     <key, value> = <topic i, Ri>
    # Parameters:
    #     timeline
    #         Type: List<Answer>
    #         Meaning: The sorted time line.
    ###
    def calculate_average_ranking_position_answer_by_topic(self, timeline):
        # <key, value> = <time_step, <Topic, average_ranking>>
        self.average_ranking_position_answer_by_topic[self.time_step] = dict()
        # <key, value> = <Topic, List<Ra>>
        Ra_List_dict = dict()
        for position in range(len(timeline)):
            answer = timeline[position]
            question = answer.get_question()
            related_topics = question.get_related_topics()
            for topic in related_topics:
                if topic not in Ra_List_dict.keys():
                    Ra_List_dict[topic] = [position]
                else:
                    Ra_List_dict[topic].append(position)
        for topic in Ra_List_dict:
            average_position = mean(Ra_List_dict[topic])
            self.average_ranking_position_answer_by_topic[self.time_step][topic] = average_position

    ###
    # Task:
    #     Calculate average ranking position of the answers expressing different opinions.
    #     diff_opinion(a): average opinion difference between answer a and current user. Ordinal variable, gap between
    #         each two values is 0.4.
    #     Ra: ranking position of answer a.
    #     Rd: average(Ra) that satisfy diff_opinion(a) == d.
    #     <key, value> = <diff_opinion, Rd>
    # Parameters:
    #     timeline
    #         Type: List<Answer>
    #         Meaning: The sorted time line.
    ###
    def calculate_average_ranking_position_answer_by_opinion(self, timeline):
        # <key, value> = <time_step, <Integer(opinion_difference_index), average_ranking>>
        self.average_ranking_position_answer_by_opinion[self.time_step] = dict()
        # <key, value> = <Integer(opinion_difference_index), List<Ra>>
        Ra_List_dict = dict()
        for position in range(len(timeline)):
            answer = timeline[position]
            answer_opinions = answer.get_topic_opinion()
            answer_opinion_differences = []
            for topic in answer_opinions:
                self_opinion = self.topic_opinions[topic]
                answer_opinion = answer_opinions[topic]
                opinion_difference = fabs(self_opinion - answer_opinion)
                answer_opinion_differences.append(opinion_difference)
            average_difference = mean(answer_opinion_differences)
            for index in self.opinion_difference_range:
                if average_difference >= self.opinion_difference_range[index][0] \
                        and average_difference < self.opinion_difference_range[index][1]:
                    if index not in Ra_List_dict.keys():
                        Ra_List_dict[index] = [position]
                    else:
                        Ra_List_dict[index].append(position)
                    break
        for index in Ra_List_dict:
            average_ranking = mean(Ra_List_dict[index])
            self.average_ranking_position_answer_by_opinion[self.time_step][index] = average_ranking

    ###
    # Task:
    #     Calculate the average ranking position of answer providers focusing each topic.
    #     Ui: the users whose answers appear in the time line, and are interested in topic i.
    #     Ru: average ranking position of Ui's answers in the time line.
    #     Ri: average(Ru) for all topic i.
    #     <key, value> = <topic i, Ri>
    # Parameters:
    #     timeline
    #         Type: List<Answer>
    #         Meaning: The sorted time line.
    ###
    def calculate_average_ranking_position_user_by_topic(self, timeline):
        # <key, value> = <time_step, <Topic, average_ranking>>
        self.average_ranking_position_user_by_topic[self.time_step] = dict()
        # <key, value> = <Topic, List<ranking position of Ui's answer>>
        Ru_List_dict = dict()
        for position in range(len(timeline)):
            answer = timeline[position]
            user = answer.get_publisher()
            following_topics = user.get_following_topics()
            for topic in following_topics:
                if topic not in Ru_List_dict.keys():
                    Ru_List_dict[topic] = [position]
                else:
                    Ru_List_dict[topic].append(position)
        for topic in Ru_List_dict:
            average_ranking_position = mean(Ru_List_dict[topic])
            self.average_ranking_position_user_by_topic[self.time_step][topic] = average_ranking_position

    ###
    # Task:
    #     Calculate the average ranking position of answer providers holding different opinions.
    #     diff_opinion(i): average opinion difference between user i and current user. Ordinal variable, gap between
    #         each two values is 0.4.
    #     Ru: average ranking position of user i's answers in the time line.
    #     Rd: average(Ru) for all users who satisfy diff_opinion(i) == d.
    #     <key, value> = <diff_opinion, Rd>
    # Parameters:
    #     timeline
    #         Type: List<Answer>
    #         Meaning: The sorted time line.
    ###
    def calculate_average_ranking_position_user_by_opinion(self, timeline):
        # <key, value> = <time_step, <Integer(opinion_difference_index), average_ranking>>
        self.average_ranking_position_user_by_opinion[self.time_step] = dict()
        # <key, value> = <Integer(opinion_difference_index), List<Ranking position of user i's answers>>
        Ru_List_dict = dict()
        for position in range(len(timeline)):
            answer = timeline[position]
            user = answer.get_publisher()
            differences = []
            if user in self.user_topic_opinion_matrix.keys():
                opinion_matrix = self.user_topic_opinion_matrix[user]
                for topic in opinion_matrix:
                    self_opinion = self.topic_opinions[topic]
                    # if topic in user_opinion.keys():
                    user_opinion = opinion_matrix[topic]
                    differences.append(fabs(self_opinion - user_opinion))
            else:
                for topic in self.topic_opinions:
                    differences.append(fabs(self.topic_opinions[topic]))
            if len(differences) == 0:
                average_difference = 0
            else:
                average_difference = mean(differences)
            for index in self.opinion_difference_range:
                if average_difference >= self.opinion_difference_range[index][0] \
                        and average_difference < self.opinion_difference_range[index][1]:
                    if index not in Ru_List_dict.keys():
                        Ru_List_dict[index] = [position]
                    else:
                        Ru_List_dict[index].append(position)
                    break
        for index in Ru_List_dict:
            average_ranking_position = mean(Ru_List_dict[index])
            self.average_ranking_position_user_by_opinion[self.time_step][index] = average_ranking_position

    ###
    # Task:
    #     Calculate and store the values of dependent variables for reading decision.
    #     This phase is about the what answers this user read.
    #     It's result from only self-selection.
    ###
    def calculate_dependent_variables_for_reading_decision(self):
        if self.time_step not in self.answers_read.keys():
            return
        answers_read = self.answers_read[self.time_step]
        if len(answers_read) == 0:
            return
        self.calculate_proportion_answer_by_topic_read(answers_read)
        self.calculate_proportion_answer_by_opinion_read(answers_read)
        self.calculate_proportion_user_by_topic_read(answers_read)
        self.calculate_proportion_user_by_opinion_read(answers_read)

    ###
    # Task:
    #     Calculate the proportion of answers related to each topic in all the answers read by current user.
    #     Ni: number of answers read by current user whose questions are related to topic i.
    #     N: number of answers read by current user.
    #     <key, value> = <time_step, Ni/N>.
    # Parameters:
    #     answers_read
    #         Type: Set<Answer>
    #         Meaning: Answers read by this user in current time step.
    ###
    def calculate_proportion_answer_by_topic_read(self, answers_read):
        # <key, value> = <time_step, <Topic, proportion>>
        self.proportion_answer_by_topic_read[self.time_step] = dict()
        # <key, value> = <Topic, Ni>
        Ni_dict = dict()
        for answer in answers_read:
            question = answer.get_question()
            related_topics = question.get_related_topics()
            for topic in related_topics:
                if topic not in Ni_dict.keys():
                    Ni_dict[topic] = 1
                else:
                    Ni_dict[topic] += 1

        N = len(answers_read)
        for topic in Ni_dict:
            proportion = Ni_dict[topic] / N
            self.proportion_answer_by_topic_read[self.time_step][topic] = proportion

    ###
    # Task:
    #     Calculate the proportion of answers expressing specific opinion in all the answers read by current user.
    #     diff_opinion(a): average opinion difference between answer a and current user. Ordinal variable, gap between
    #         each two values is 0.4.
    #     Nd: number of answers read by current user that satisfy diff_opinion(a) = d.
    #     N: number of answers read by current user.
    #     <key, value> = <time_step, Nd/N>
    # Parameters:
    #     answers_read
    #         Type: Set<Answer>
    #         Meaning: Answers read by this user in current time step.
    ###
    def calculate_proportion_answer_by_opinion_read(self, answers_read):
        # <key, value> = <time_step, <Integer(opinion_difference_index), proportion>>
        self.proportion_answer_by_opinion_read[self.time_step] = dict()
        # <key, value> = <Integer(opinion_difference_index), Nd>
        Nd_dict = dict()
        for answer in answers_read:
            answer_opinions = answer.get_topic_opinion()
            opinion_differences = []
            for topic in answer_opinions:
                self_opinion = self.topic_opinions[topic]
                answer_opinion = answer_opinions[topic]
                difference = fabs(self_opinion - answer_opinion)
                opinion_differences.append(difference)
            average_difference = mean(opinion_differences)
            for index in self.opinion_difference_range:
                if average_difference >= self.opinion_difference_range[index][0] \
                        and average_difference < self.opinion_difference_range[index][1]:
                    if index not in Nd_dict.keys():
                        Nd_dict[index] = 1
                    else:
                        Nd_dict[index] += 1
                    break

        N = len(answers_read)
        for index in Nd_dict:
            proportion = Nd_dict[index] / N
            self.proportion_answer_by_opinion_read[self.time_step][index] = proportion

    ###
    # Task:
    #     Calculate the proportion of answer providers who are interested in each topic in all the answer providers.
    #     Ni: number of users who are interested in topic i, and their answers are read by current user.
    #     N: number of users whose answers are read by current user.
    #     <key, value> = <time_step, Ni/N>
    # Parameters:
    #     answers_read
    #         Type: Set<Answer>
    #         Meaning: Answers read by this user in current time step.
    ###
    def calculate_proportion_user_by_topic_read(self, answers_read):
        # <key, value> = <time_step, <Topic, proportion>>
        self.proportion_user_by_topic_read[self.time_step] = dict()
        # <key, value> = <Topic, Ni>
        Ni_dict = dict()
        answer_providers = set()
        for answer in answers_read:
            answer_providers.add(answer.get_publisher())
        N = len(answer_providers)

        for user in answer_providers:
            following_topics = user.get_following_topics()
            for topic in following_topics:
                if topic not in Ni_dict.keys():
                    Ni_dict[topic] = 1
                else:
                    Ni_dict[topic] += 1

        for topic in Ni_dict:
            proportion = Ni_dict[topic] / N
            self.proportion_user_by_topic_read[self.time_step][topic] = proportion

    ###
    # Task:
    #     Calculate the proportion of answer providers holding specific opinion in all the answer providers.
    #     diff_opinion(u): average opinion difference between user u and current user. Ordinal Variable, gap between
    #         each two values is 0.4.
    #     Nd: number of users whose answers are read by current user, and satisfy diff_opinion(u) == d.
    #     N: number of users whose answers are read by current user.
    #     <key, value> = <time_step, Nd/N>
    # Parameters:
    #     answers_read
    #         Type: Set<Answer>
    #         Meaning: Answers read by this user in current time step.
    ###
    def calculate_proportion_user_by_opinion_read(self, answers_read):
        # <key, value> = <time_step, <Integer(opinion_difference_index), proportion>>
        self.proportion_user_by_opinion_read[self.time_step] = dict()
        # <key, value> = <Integer(opinion_difference_index), Nd>
        Nd_dict = dict()
        answer_providers = set()
        for answer in answers_read:
            answer_providers.add(answer.get_publisher())
        N = len(answer_providers)

        for user in answer_providers:
            differences = []
            if user in self.user_topic_opinion_matrix.keys():
                opinion_matrix = self.user_topic_opinion_matrix[user]
                for topic in opinion_matrix:
                    self_opinion = self.topic_opinions[topic]
                    if topic in opinion_matrix.keys():
                        user_opinion = opinion_matrix[topic]
                        differences.append(fabs(self_opinion - user_opinion))
            else:
                for topic in self.topic_opinions:
                    differences.append(fabs(self.topic_opinions[topic]))
            if len(differences) == 0:
                average_difference = 0
            else:
                average_difference = mean(differences)
            for index in self.opinion_difference_range:
                if average_difference >= self.opinion_difference_range[index][0] \
                        and average_difference < self.opinion_difference_range[index][1]:
                    if index not in Nd_dict.keys():
                        Nd_dict[index] = 1
                    else:
                        Nd_dict[index] += 1
                    break

        for index in Nd_dict:
            proportion = Nd_dict[index] / N
            self.proportion_user_by_opinion_read[self.time_step][index] = proportion

    def report_dependent_variables(self):
        return (self.interested_topics,
                self.time_step_all_interested_topics_discovered,
                self.proportion_answer_by_topic_data_source,
                self.proportion_answer_by_opinion_data_source,
                self.proportion_user_by_topic_data_source,
                self.proportion_user_by_opinion_data_source,
                self.average_ranking_position_answer_by_topic,
                self.average_ranking_position_answer_by_opinion,
                self.average_ranking_position_user_by_topic,
                self.average_ranking_position_user_by_opinion,
                self.proportion_answer_by_topic_read,
                self.proportion_answer_by_opinion_read,
                self.proportion_user_by_topic_read,
                self.proportion_user_by_opinion_read)
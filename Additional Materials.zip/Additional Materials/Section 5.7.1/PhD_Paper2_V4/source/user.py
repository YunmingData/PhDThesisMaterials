# -*- coding: UTF-8 -*-
"""
Project: PhD_Paper2_V4
File: user.py
Author: 王晨龙 Chenlong Wang
Date & Time of Creation: 2022-06-16 19:59 
"""
import random
from scipy.stats import skewnorm
from source.post import Question, Answer
from source.utils import calculate_social_influence_ratio
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans


class User:
    def __init__(self, user_id: int, expertise: int, opinion: float,  agree_threshold: float,
                 disagree_threshold: float):
        """
        Constructor of User.

        :param int user_id: The unique identification of the user.
        :param int expertise: User's expertise in the topic.
        :param float opinion: User's opinion in the topic.
        :param float agree_threshold: The threshold of the opinion difference under which this user will agree with the
        opinion expressed in the answer she/he reads and have motivation to vote for the answer. It is also the
        threshold between assimilating and repulsing social influence.
        :param float disagree_threshold: The threshold of the opinion difference above which this user will disagree
        with the opinion expressed in the answer she/he reads and have motivation to vote against the answer.
        """
        # ========================================== Basic Attributes ================================================ #
        # The unique identification of the user.
        self.user_id = user_id
        # This user's expertise in the topic.
        self.expertise = expertise
        # User's opinion in the topic.
        self.opinion = opinion
        # The probability of posting an answer in each time step.
        self.answer_probability = 0.05
        # The threshold of the opinion difference under which this user will agree with the opinion expressed in the
        # answer she/he reads and have motivation to vote for the answer. It is also the threshold between assimilating
        # and repulsing social influence.
        self.agree_threshold = agree_threshold
        # The threshold of the opinion difference above which this user will disagree with the opinion expressed in the
        # answer she/he reads and have motivation to vote against the answer.
        self.disagree_threshold = disagree_threshold
        # ====================================== Reading, Writing, Voting ============================================ #
        # If the user has not answer specific question, this is the answer in user's mind but has not published.
        self.answer_in_mind = None
        # =========================================== Behaviour Record =============================================== #
        # <keu, value> = <time_step, set<Answer>>. The answers this user has read.
        self.answers_read = dict()
        # The answers this user has posted.
        self.answers_posted = set()
        # <keu, value> = <time_step, set<Answer>>. The answers this user has voted for.
        self.answers_voted_for = dict()
        # <keu, value> = <time_step, set<Answer>>. The answers this user has voted against.
        self.answers_voted_against = dict()

    def __repr__(self):
        return "User %d" % self.user_id

    def __str__(self):
        return "User %d" % self.user_id

    def __hash__(self):
        return hash(self.user_id)

    def publish_answer(self, question: Question, post_id: int, time_step: int, by_probability: bool, run_id: str):
        """
        Publish an answer to the question.

        :param Question question: The question to which the new answer is.
        :param int post_id: The post ID of the new answer.
        :param int time_step: Current time step.
        :param bool by_probability: Whether the publishing decision is made with a probability. If not, the user will
        always publish an answer.
        :param str run_id: The identification of this run.
        :return: The answer posted.
        :rtype: Answer
        """
        if by_probability and random.random() > self.answer_probability:
            return None
        answer = self.write_basic_answer(question, post_id, time_step)
        self.answers_posted.add(answer)
        question.answers.append(answer)
        print("[ %s | Time Step: %d ] User %d posted answer %d." % (run_id, time_step, self.user_id,
                                                                    answer.post_id))
        return answer

    def write_basic_answer(self, question: Question, post_id: int = -1, time_step: int = -1):
        """
        Write an answer, this is the first impression of this user to the given question's solution.

        :param Question question: The question to which the new answer is.
        :param int post_id: The post ID of the new answer.
        :param int time_step: Current time step.
        :return: The answer.
        :rtype: Answer
        """
        if self.expertise >= question.difficulty:
            value = 0
        else:
            scale = 0.05 * (question.difficulty - self.expertise)
            rvs_1 = skewnorm.rvs(a=self.opinion, loc=0, scale=scale, size=10000)
            value = random.choice(rvs_1)
            while value > 1 or value < -1:
                value = random.choice(rvs_1)
        answer = Answer(post_id=post_id,
                        publish_time=time_step,
                        publisher=self,
                        question=question,
                        value=value,
                        expression=random.randint(1, 9))
        return answer

    def reading_process(self, run_id: str, time_step: int, social_influence_type: str, time_line: list[Answer]):
        """
        Read and vote for the answers.

        :param str run_id: The identification of this run.
        :param int time_step: Current time step.
        :param str social_influence_type: What kind of social influence is working. None: no social influence;
        "bounded confidence": only assimilating influence; "hybrid": assimilating and repulsing influence.
        :param list[Answer] time_line: The list of answers for the user to read.
        """
        for answer in time_line:
            self.answer_in_mind = None
            self.read_answer(answer, time_step, social_influence_type)
            self.voting_decision(answer, time_step)
        # Screen output.
        if time_step in self.answers_read.keys():
            answer_read = "[ %s | Time Step: %d | User %d \t] Read: " % \
                          (run_id, time_step, self.user_id)
            for answer in self.answers_read[time_step]:
                answer_read += "%d, " % answer.post_id
            print(answer_read)
        if time_step in self.answers_voted_for.keys():
            answer_voted = "[ %s | Time Step: %d | User %d \t] Voted for: " % \
                           (run_id, time_step, self.user_id)
            for answer in self.answers_voted_for[time_step]:
                answer_voted += "%d, " % answer.post_id
            print(answer_voted)
        if time_step in self.answers_voted_against.keys():
            answer_voted_down = "[ %s | Time Step: %d | User %d \t] Voted against: " % \
                           (run_id, time_step, self.user_id)
            for answer in self.answers_voted_against[time_step]:
                answer_voted_down += "%d, " % answer.post_id
            print(answer_voted_down)

    def read_answer(self, answer: Answer, time_step: int, social_influence_type: str):
        """
        Read the answer, and be influenced by it.

        :param Answer answer: The answer to read.
        :param int time_step: Current time step.
        :param str social_influence_type: What kind of social influence is working. None: no social influence;
        "bounded confidence": only assimilating influence; "hybrid": assimilating and repulsing influence.
        """
        self.record_read_answer(answer, time_step)
        self.be_influenced_by_the_answer(answer, time_step, social_influence_type)

    def record_read_answer(self, answer: Answer, time_step: int):
        """
        Record the read behaviour in both this user and the answer.

        :param Answer answer: The answer being read.
        :param int time_step: Current time step.
        """
        if time_step not in self.answers_read.keys():
            self.answers_read[time_step] = set()
        self.answers_read[time_step].add(answer)
        if time_step not in answer.read_users.keys():
            answer.read_users[time_step] = set()
        answer.read_users[time_step].add(self)

    def be_influenced_by_the_answer(self, answer: Answer, time_step: int, social_influence_type: str):
        """
        User's opinion is influenced by the answer she/he reads.

        :param Answer answer: The answer this user reads.
        :param int time_step: Current time step.
        :param str social_influence_type: What kind of social influence is working. None: no social influence;
        "bounded confidence": only assimilating influence; "hybrid": assimilating and repulsing influence.
        """
        if social_influence_type is None:
            return
        has_answered, my_answer = self.has_answered(answer.question)
        if not has_answered:
            self.answer_in_mind = self.write_basic_answer(answer.question)
            my_answer = self.answer_in_mind

        # The weight of the social influence.
        self.opinion += self.calculate_social_influence(answer, my_answer, time_step, social_influence_type)

    def has_answered(self, question: Question):
        """
        If this user has answered the given question.

        :param Question question: The given question.
        :return: True/False, my answer/None.
        :rtype: tuple[bool, Answer]
        """
        for answer in self.answers_posted:
            if answer.question == question:
                return True, answer
        return False, None

    def calculate_social_influence(self, answer: Answer, my_answer: Answer, time_step: int, social_influence_type: str):
        """
        Calculate the social influence on user's opinion. The type of social influence depends on the social influence
        type and opinion difference. The weight of social influence depends on the up-vote numbers.

        :param Answer answer: The answer this user reads.
        :param Answer my_answer: The answer of this user or the answer in her/his mind.
        :param int time_step: Current time step.
        :param str social_influence_type: What kind of social influence is working. None: no social influence;
        "bounded confidence": only assimilating influence; "hybrid": assimilating and repulsing influence.
        :return: The weight of social influence. If it's assimilating, positive; otherwise negative.
        :rtype: float
        """
        # The ratio depends on the up-vote number of the answer.
        ratio = calculate_social_influence_ratio(answer, time_step)

        # The opinion difference between this user and the given answer.
        diff = answer.value - my_answer.value
        # Only assimilating social influence.
        if social_influence_type == "bounded confidence":
            weight = ratio * (self.agree_threshold - abs(diff))
            weight = weight if abs(diff) <= self.agree_threshold else 0
            return weight
        # Either assimilating or repulsing social influence.
        elif social_influence_type == "hybrid":
            # x: abs(diff), [0, 2]
            # y: weight of social influence.
            # Assume threshold: t = 0.5
            # So: y = -1 * (x - t) = t - x
            # When x < t, assimilating social influence, y > 0. With x smaller, social influence stronger.
            # When x > t, repulsing social influence, y < 0. With x bigger, social influence stronger.
            return ratio * (self.agree_threshold - abs(diff))

    def voting_decision(self, answer: Answer, time_step: int):
        """
        Make the decision of whether to vote for/against the answer.

        :param Answer answer: The answer to which the voting decision is made.
        :param int time_step: Current time step.
        """
        has_answered, my_answer = self.has_answered(answer.question)
        if not has_answered:
            # my_answer = self.write_basic_answer(answer.question)
            if self.answer_in_mind is None:
                my_answer = self.write_basic_answer(answer.question)
            else:
                my_answer = self.answer_in_mind

        # The opinion difference between this user and the given answer.
        diff = abs(my_answer.value - answer.value)
        if self.expertise >= answer.question.difficulty:
            if diff == 0:
                self.vote(answer, time_step, 1)
            elif diff > self.disagree_threshold:
                self.vote(answer, time_step, -1)
            else:
                self.vote(answer, time_step, 0)
        else:
            # The cognitive effort reduced by answer's expression. A line crossing (1, 0) and (9, 0.5)
            cognitive_fluency = 0.0625 * answer.expression - 0.0625
            if diff <= self.agree_threshold:
                self.vote(answer, time_step, 1)
            elif diff > self.disagree_threshold:
                # Because of fluency, there is a probability that this user will not vote against the answer with which
                # she/he disagree.
                if random.random() < cognitive_fluency:
                    self.vote(answer, time_step, 0)
                else:
                    self.vote(answer, time_step, -1)
            else:
                # Because of fluency, there is a probability that this user will vote for the answer with which she/he
                # neither agree or disagree.
                if random.random() < cognitive_fluency:
                    self.vote(answer, time_step, 1)
                else:
                    self.vote(answer, time_step, 0)

    def vote(self, answer: Answer, time_step: int, voting_status: int):
        """
        Record this user's voting behaviour to the given answer. Set the voting status to the given one.

        :param Answer answer: The given answer.
        :param int time_step: Current time step.
        :param int voting_status: For up-vote, 1; for down-vote, -1; for no vote, 0.
        """
        # Set the voting status as up-vote.
        if voting_status == 1:
            # Cancel all the down-votes in previous time steps.
            for previous_time in self.answers_voted_against:
                if answer in self.answers_voted_against[previous_time]:
                    self.answers_voted_against[previous_time].remove(answer)
            # Add record into the up-votes.
            if time_step not in self.answers_voted_for.keys():
                self.answers_voted_for[time_step] = set()
            self.answers_voted_for[time_step].add(answer)
            answer.record_vote(time_step, self, 1)
        # Set the voting status as down-vote.
        elif voting_status == -1:
            # Cancel all th up-votes in previous time steps.
            for previous_time in self.answers_voted_for:
                if answer in self.answers_voted_for[previous_time]:
                    self.answers_voted_for[previous_time].remove(answer)
            # Add record into the down-votes.
            if time_step not in self.answers_voted_against.keys():
                self.answers_voted_against[time_step] = set()
            self.answers_voted_against[time_step].add(answer)
            answer.record_vote(time_step, self, -1)
        # Set the voting status as no vote.
        elif voting_status == 0:
            # Check and cancel the previous up-votes.
            for previous_time in self.answers_voted_for:
                if answer in self.answers_voted_for[previous_time]:
                    self.answers_voted_for[previous_time].remove(answer)
            # Check and cancel the previous down-votes.
            for previous_time in self.answers_voted_against:
                if answer in self.answers_voted_against[previous_time]:
                    self.answers_voted_against[previous_time].remove(answer)
            answer.record_vote(time_step, self, 0)

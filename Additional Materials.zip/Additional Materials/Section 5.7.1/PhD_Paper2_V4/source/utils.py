# -*- coding: UTF-8 -*-
"""
Project: PhD_Paper2_V4
File: utils.py
Author: 王晨龙 Chenlong Wang
Date & Time of Creation: 2022-06-16 19:59 
"""
import random


def bubble_sort_answer(answer_list, sort_type: str):
    """
    Sort the answers under this question with bubble sort algorithm.
    Make them descending according to the sort type.

    :param list[Answer] answer_list: The list of answers needed to sort.
    :param str sort_type: "true": according to the qualities of answers;
    "show": according to the Wilson Confidence Intervals of answers;
    "time": according to the publish times ot answers;
    "vote": according to the up-vote numbers of answers.
    """
    for i in range(len(answer_list)):
        for j in range(0, len(answer_list)-i-1):
            if answer_list[j+1].should_be_placed_ahead(answer_list[j], sort_type):
                answer_list[j], answer_list[j + 1] = answer_list[j + 1], answer_list[j]


def merge_sort_answer(answer_list, sort_type: str):
    """
    Sort the answers under this question with merge sort algorithm.
    Make them descending according to the sort type.

    :param list[Answer] answer_list: The list of answers needs sorting.
    :param sort_type: "true": according to the qualities of answers;
    "show": according to the Wilson Confidence Intervals of answers;
    "time": according to the publish times ot answers;
    "vote": according to the up-vote numbers of answers.
    :return: The sorted answer list.
    :rtype: list[Answer]
    """
    if len(answer_list) <= 1:
        return answer_list
    mid = len(answer_list) // 2
    return merge(merge_sort_answer(answer_list[:mid], sort_type),
                 merge_sort_answer(answer_list[mid:], sort_type),
                 sort_type)


def merge(answer_list_1, answer_list_2, sort_type):
    """
    Merge the two parts and make sure the result is sorted.

    :param list[Answer] answer_list_1: The first part of answer list.
    :param list[Answer] answer_list_2: The second part of answer list.
    :param sort_type: "true": according to the qualities of answers;
    "show": according to the Wilson Confidence Intervals of answers;
    "time": according to the publish times ot answers;
    "vote": according to the up-vote numbers of answers.
    :return: The sorted answer list.
    :rtype: list[Answer]
    """
    result = []
    while answer_list_1 and answer_list_2:
        if answer_list_1[0].should_be_placed_ahead(answer_list_2[0], sort_type):
            result.append(answer_list_1.pop(0))
        else:
            result.append(answer_list_2.pop(0))
    if answer_list_1:
        result += answer_list_1
    if answer_list_2:
        result += answer_list_2
    return result


def calculate_social_influence_ratio(answer, time_step: int):
    """
    Calculate the change ratio in user's opinion if she/he is influenced. It will be used to multiple the opinion
    difference in the social influence calculation.

    :param Answer answer: The answer the user reads.
    :param int time_step: Current time step.
    :return: The change ratio.
    :rtype: float
    """
    answer.question.record_answer_ranks(time_step)
    answer_id_list = answer.question.get_up_vote_ranking()
    if len(answer_id_list) <= 5:
        w_ij = 0.4
    elif len(answer_id_list) <= 10:
        if answer.rank_by_up_vote[time_step] <= 5:
            w_ij = 0.6
        else:
            w_ij = 0.4
    elif len(answer_id_list) <= 15:
        if answer.rank_by_up_vote[time_step] <= 5:
            w_ij = 0.8
        elif answer.rank_by_up_vote[time_step] <= 10:
            w_ij = 0.6
        else:
            w_ij = 0.4
    else:
        if answer.rank_by_up_vote[time_step] <= 5:
            w_ij = 1
        elif answer.rank_by_up_vote[time_step] <= 10:
            w_ij = 0.8
        elif answer.rank_by_up_vote[time_step] <= 15:
            w_ij = 0.6
        else:
            w_ij = 0.4
    return w_ij


def choose_from_list_by_scale_free_principle(candidate_list, number_needed):
    """
    Choose several Users/Answers from the candidate list by scale free principle.

    :param list candidate_list: The list of Answers from which to choose.
    :param int number_needed: Number of Answers needed in the result.
    :return: The Chosen Answers.
    :rtype: list[Answer]
    """
    if number_needed <= 0:
        return []
    if number_needed >= len(candidate_list):
        return candidate_list

    result = []
    while len(result) < number_needed:
        cumulating_figure = []
        cumulative_percentage = []
        figure = 0
        for candidate in candidate_list:
            figure += candidate.calculate_wilson_score_interval()
            cumulating_figure.append(figure)
        # Happens when the candidates are Answers and no votes are given to them.
        if figure == 0:
            result.append(candidate_list[0])
            candidate_list.remove(candidate_list[0])
        else:
            for i in cumulating_figure:
                cumulative_percentage.append(i / figure)
            index = random.random()
            for i in range(len(cumulative_percentage)):
                if index < cumulative_percentage[i]:
                    result.append(candidate_list[i])
                    # Remove the chosen candidate from the candidate_list, and choose again.
                    # This is to accelerate code.
                    candidate_list.remove(candidate_list[i])
                    break
    return result

# -*- coding: UTF-8 -*-
"""
Project: PhD_Paper2_V4
File: post.py
Author: 王晨龙 Chenlong Wang
Date & Time of Creation: 2022-06-16 19:59 
"""
from source.utils import bubble_sort_answer, merge_sort_answer
from scipy.stats import spearmanr, kendalltau
from math import sqrt


class Post:
    def __init__(self, post_id: int, publish_time: int, publisher):
        """
        Constructor of the post. The post could be a question or an answer.

        :param int post_id: The unique identification number of this post.
        :param int publish_time: The time step in which this post is published.
        :param User publisher:  The user who created this post.
        """
        self.post_id = post_id
        self.publish_time = publish_time
        self.publisher = publisher

    def __repr__(self):
        return "Post %d" % self.post_id

    def __str__(self):
        return "Post %d" % self.post_id

    def __hash__(self):
        return hash(self.post_id)


class Question(Post):
    def __init__(self, post_id: int, publish_time: int, publisher, difficulty: int):
        """
        The constructor of the Question. It is a sub class of Post.

        :param int post_id: The unique identification number of this question.
        :param int publish_time: The time step in which this question is published.
        :param User publisher:  The user who created this question.
        :param int difficulty: How difficult this question is, which also means the expertise required to find the
        correct answer to this question. It is ranged in [1, 9], in which 9 is extreme difficult and 1 is extreme easy.
        """
        super().__init__(post_id, publish_time, publisher)
        # The difficulty of the question (i.e. the required expertise to solve this question).
        self.difficulty = difficulty
        # The answers under this question.
        self.answers = []

    def __repr__(self):
        return "Question %d" % self.post_id

    def __str__(self):
        return "Question %d" % self.post_id

    def record_answer_ranks(self, time_step):
        """
        Record the position of answers under this question in this time step.

        :param int time_step: The time step.
        """
        # The rank by up vote numbers.
        # bubble_sort_answer(self.answers, "vote")
        self.answers = merge_sort_answer(self.answers, "vote")
        rank_position = 1
        for answer in self.answers:
            answer.rank_by_up_vote[time_step] = rank_position
            rank_position += 1
        # The rank by Wilson Confidence Interval (i.e. the answers' showing positions).
        # bubble_sort_answer(self.answers, "show")
        self.answers = merge_sort_answer(self.answers, "show")
        rank_position = 1
        for answer in self.answers:
            answer.rank_by_wilson_confidence_interval[time_step] = rank_position
            rank_position += 1

    def get_up_vote_ranking(self):
        """
        Sort the answers under this question based on their up-vote numbers.

        :return:The sorted answers' IDs.
        :rtype: list[int]
        """
        # quick_sort_answer(self.answers, "vote")
        # bubble_sort_answer(self.answers, "vote")
        self.answers = merge_sort_answer(self.answers, "vote")
        result = []
        for answer in self.answers:
            result.append(answer.post_id)
        return result

    def get_community_ranking(self, by_vote: bool):
        """
        Sort the answers according to their vote-up numbers, and get the rankings of them.

        :param bool by_vote: Whether the community ranking is calculated by up vote number. If not, it will be
        calculated by Wilson Confidence Interval.
        :return: The sorted list of answer ids.
        :rtype: list[int]
        """
        answers_in_list = list(self.answers)
        if by_vote:
            # bubble_sort_answer(answers_in_list, "vote")
            answers_in_list = merge_sort_answer(answers_in_list, "vote")
        else:
            # bubble_sort_answer(answers_in_list, "show")
            answers_in_list = merge_sort_answer(answers_in_list, "show")

        result = []
        for answer in answers_in_list:
            result.append(answer.post_id)
        return result

    def get_rankings(self, by_vote: bool):
        """
        Calculate the two rankings and return them.

        :param bool by_vote: Whether the community ranking is calculated by up vote number. If not, it will be
        calculated by Wilson Confidence Interval.
        :return: The true ranking and community ranking of answers under this question.
        :rtype: tuple[list[int], list[int]]
        """
        community_ranking = self.get_community_ranking(by_vote)
        true_ranking = self.get_true_ranking()
        return true_ranking, community_ranking

    def get_true_ranking(self):
        """
        Sort the answers under this question according to the qualities.

        :return: The sorted list of answer ids.
        :rtype: list[int]
        """
        answers_in_list = list(self.answers)
        # bubble_sort_answer(answers_in_list, "true")
        answers_in_list = merge_sort_answer(answers_in_list, "true")

        result = []
        for answer in answers_in_list:
            result.append(answer.post_id)
        return result

    def ranking_correlation_coefficient(self, by_vote: bool):
        """
        Calculate the Spearman's ranking correlation coefficient and the Kendall tau correlation coefficient of the
        answers under this quetsion.

        :param bool by_vote: Whether the community ranking is calculated by up vote number. If not, it will be
        calculated by Wilson Confidence Interval.
        :return: Speaman's coefficient and corresponding p-value, Kendall tau coefficient and corresponding p-value.
        :rtype: tuple[tuple[float, float], tuple[float, float]]
        """
        true_ranking, community_ranking = self.get_rankings(by_vote)
        return spearmanr(true_ranking, community_ranking), kendalltau(true_ranking, community_ranking)

    def get_community_ranking_with_up_votes(self, by_vote):
        """
        Sort the answers according to their vote-up numbers, and get the rankings of them.
        Only include the answers with at least one up-vote.

        :param bool by_vote: Whether the community ranking is calculated by up vote number. If not, it will be
        calculated by Wilson Confidence Interval.
        :return: The sorted list of answer ids.
        :rtype: list[int]
        """
        answers_in_list = list(self.answers)
        if by_vote:
            # bubble_sort_answer(answers_in_list, "vote")
            answers_in_list = merge_sort_answer(answers_in_list, "vote")
        else:
            # bubble_sort_answer(answers_in_list, "show")
            answers_in_list = merge_sort_answer(answers_in_list, "show")

        result = []
        for answer in answers_in_list:
            if answer.get_up_vote_number() > 0:
                result.append(answer.post_id)
        return result

    def get_true_ranking_with_up_votes(self):
        """
        Sort the answers under this question according to the qualities.
        Only include the first few answers indicated by length_needed.

        :return: The sorted list of answer ids.
        :rtype: list[int]
        """
        answers_in_list = list(self.answers)
        # quick_sort_answer(answers_in_list, "true")
        # bubble_sort_answer(answers_in_list, "true")
        answers_in_list = merge_sort_answer(answers_in_list, "true")

        result = []
        for answer in answers_in_list:
            if answer.get_up_vote_number() > 0:
                result.append(answer.post_id)
        return result

    def get_rankings_with_up_votes(self, by_vote: bool):
        """
        Calculate the two rankings an return them.

        :param bool by_vote: Whether the community ranking is calculated by up vote number. If not, it will be
        calculated by Wilson Confidence Interval.
        :return: The true ranking and community ranking of answers with up votes under this question.
        :rtype: tuple[list[int], list[int]]
        """
        community_ranking = self.get_community_ranking_with_up_votes(by_vote)
        true_ranking = self.get_true_ranking_with_up_votes()
        return community_ranking, true_ranking

    def ranking_correlation_coefficient_answers_with_votes(self, by_vote: bool):
        """
        Calculate the Spearman's ranking correlation coefficient and the Kendall tau ranking correlation coefficient of
        the true ranking and the community ranking.

        :param bool by_vote: Whether the community ranking is calculated by up vote number. If not, it will be
        calculated by Wilson Confidence Interval.
        :return: Speaman's coefficient and corresponding p-value, Kendall tau coefficient and corresponding p-value.
        :rtype: tuple[tuple[float, float], tuple[float, float]]
        """
        true_ranking, community_ranking = self.get_rankings_with_up_votes(by_vote)
        return spearmanr(true_ranking, community_ranking), kendalltau(true_ranking, community_ranking)

    def get_top_10_percent_rankings(self, by_vote: bool):
        """
        Calculate the two rankings and return the top 10 answers' IDs for both lists.

        :param bool by_vote: Whether the community ranking is calculated by up vote number. If not, it will be
        calculated by Wilson Confidence Interval.
        :return: The top 10% true ranking answers and the top 10 community ranking answers unser this question.
        :rtype: tuple[list[int], list[int]]
        """
        true_ranking, community_ranking = self.get_rankings(by_vote)
        len_needed = round(len(true_ranking)/10)
        if len_needed > 0:
            true_ranking = true_ranking[:len_needed]
            community_ranking = community_ranking[:len_needed]
            return true_ranking, community_ranking
        else:
            return [], []

    def ranking_correlation_coefficient_top_10_percent(self, by_vote: bool):
        """
        Calculate the Spearman's ranking correlation coefficient and the Kendall tau ranking correlation coefficient of
        the top 10% answers under this question.
        Calculate the proportion of common answers in the top 10 answers in the true ranking list and the community
        ranking list.

        :param bool by_vote: Whether the community ranking is calculated by up vote number. If not, it will be
        calculated by Wilson Confidence Interval.
        :return: Speaman's coefficient and corresponding p-value, Kendall tau coefficient and corresponding p-value,
        proportion.
        :rtype: tuple[tuple[float, float], tuple[float, float], float]
        """
        true_ranking, community_ranking = self.get_top_10_percent_rankings(by_vote)
        if len(true_ranking) == 0 and len(community_ranking) == 0:
            proportion = 0
        else:
            true_ranking_set = set(true_ranking)
            community_ranking_set = set(community_ranking)
            proportion = len(true_ranking_set.intersection(community_ranking_set)) / len(true_ranking)
        return spearmanr(true_ranking, community_ranking), kendalltau(true_ranking, community_ranking), proportion

    def get_top_10_rankings(self, by_vote: bool):
        """
        Get top 10 highest voted answers, and calculate the true ranking of them.

        :param bool by_vote: Whether the community ranking is calculated by up vote number. If not, it will be
        calculated by Wilson Confidence Interval.
        :return: The top 10 community ranking answers and their true ranking.
        :rtype: tuple[list[int], list[int]]
        """
        community_ranking = self.get_community_ranking(by_vote)
        if len(community_ranking) <= 10:
            true_ranking = self.get_true_ranking()
            return true_ranking, community_ranking
        selected_community_ranking = community_ranking[:10]
        answers_in_list = []
        for answer in self.answers:
            for post_id in selected_community_ranking:
                if answer.post_id == post_id:
                    answers_in_list.append(answer)
                    break

        # bubble_sort_answer(answers_in_list, "true")
        answers_in_list = merge_sort_answer(answers_in_list, "true")
        selected_true_ranking = []
        for answer in answers_in_list:
            selected_true_ranking.append(answer.post_id)
        return selected_true_ranking, selected_community_ranking

    def ranking_correlation_coefficient_top_10(self, by_vote: bool):
        """
        Calculate the Spearman's ranking correlation coefficient and the Kendall tau ranking correlation coefficient of
        the top 10 highest voted answers' true ranking and community ranking.

        :param bool by_vote: Whether the community ranking is calculated by up vote number. If not, it will be
        calculated by Wilson Confidence Interval.
        :return: Speaman's coefficient and corresponding p-value, Kendall tau coefficient and corresponding p-value.
        :rtype: tuple[tuple[float, float], tuple[float, float]]
        """
        true_ranking, community_ranking = self.get_top_10_rankings(by_vote)
        return spearmanr(true_ranking, community_ranking), kendalltau(true_ranking, community_ranking)


class Answer(Post):
    def __init__(self, post_id: int, publish_time: int, publisher, question: Question, value: float, expression: int):
        """
        The constructor of the Answer. It is a sub class of Post.

        :param int post_id: The unique identification number of this answer.
        :param int publish_time: The time step in which this answer is published.
        :param User publisher:  The user who created this answer.
        :param Question question: To which question this answer is published.
        :param float value: The content of the answer, which represent the distance of the opinion expressed in this
        answer to the correct answer of the corresponding question.
        :param int expression: How good the opinion of this answer is expressed. This variable captures all the features
        not related to the correctness, but related to the expression of the value. It is range in [1, 9], where 9 is
        expressed excellently, while 1 is expressed very poorly.
        """
        super().__init__(post_id, publish_time, publisher)
        # The question to which this answer is.
        self.question = question
        # The content of the answer, which represent the distance of the opinion expressed in this answer to the correct
        # answer of the corresponding question.
        self.value = value
        # How good the opinion of this answer is expressed. This variable captures all the features not related to the
        # correctness, but related to the expression of the value. It is range in [1, 9], where 9 is expressed
        # excellently, while 1 is expressed very poorly.
        self.expression = expression
        # <key, value>: <time_step, Set<User>>.
        self.read_users = dict()
        # <key, value> = <time_step, set<User>>. In which time step, who has voted for this answer.
        self.up_votes = dict()
        # The number of total up-votes.
        self.up_vote_number = 0
        # The number of up-votes in recent 5 time steps.
        self.recent_up_vote_number = 0
        # <key, value> = <time_step, set<User>>. In which time step, who has voted against this answer.
        self.down_votes = dict()
        # The number of total down-votes.
        self.down_vote_number = 0
        # The number of down-votes in the recent 5 time steps.
        self.recent_down_vote_number = 0
        # The value for wilson score interval ranking.
        self.wilson_score_interval = 0
        # <key, value> = <time_step, rank by up vote number under the question>
        self.rank_by_up_vote = dict()
        # <key, value> = <time_step, rank by up Wilson Confidence Interval under the question>
        self.rank_by_wilson_confidence_interval = dict()

    def __repr__(self):
        return "Answer %d" % self.post_id

    def __str__(self):
        return "Answer %d" % self.post_id

    def should_be_placed_ahead(self, answer_b, standard: str):
        """
        Decide whether this answer should be placed in front of the other answer.

        :param Answer answer_b: The other answer.
        :param str standard: The standard of ranking.
        :return: If this answer should be placed ahead the other answer, return True; otherwise False.
        :rtype: bool
        """
        if standard == "true":
            # Value > Expression > Wilson Confidence Interval >  up-vote > time.
            if abs(self.value) < abs(answer_b.value):
                return True
            elif abs(self.value) == abs(answer_b.value):
                if self.expression > answer_b.expression:
                    return True
                elif self.expression == answer_b.expression:
                    if self.calculate_wilson_score_interval() > answer_b.calculate_wilson_score_interval():
                        return True
                    elif self.calculate_wilson_score_interval() == answer_b.calculate_wilson_score_interval():
                        if self.get_up_vote_number() > answer_b.get_up_vote_number():
                            return True
                        elif self.get_up_vote_number() == answer_b.get_up_vote_number():
                            if self.publish_time < answer_b.publish_time:
                                return True
            return False
        elif standard == "vote":
            # Up-vote > Wilson Confidence Interval > time.
            if self.get_up_vote_number() > answer_b.get_up_vote_number():
                return True
            elif self.get_up_vote_number() == answer_b.get_up_vote_number():
                if self.calculate_wilson_score_interval() > answer_b.calculate_wilson_score_interval():
                    return True
                elif self.calculate_wilson_score_interval() == answer_b.calculate_wilson_score_interval():
                    if self.publish_time < answer_b.publish_time:
                        return True
            return False
        elif standard == "show":
            # Wilson Confidence Interval > up-vote > time.
            if self.calculate_wilson_score_interval() > answer_b.calculate_wilson_score_interval():
                return True
            elif self.calculate_wilson_score_interval() == answer_b.calculate_wilson_score_interval():
                if self.get_up_vote_number() > answer_b.get_up_vote_number():
                    return True
                elif self.get_up_vote_number() == answer_b.get_up_vote_number():
                    if self.publish_time < answer_b.publish_time:
                        return True
            return False

    def calculate_wilson_score_interval(self):
        """
        Calculate lower bound of the wilson score interval for answer ranking.

        :return: The lower bound of the wilson score interval.
        :rtype: float
        """
        self.get_up_vote_number()
        self.get_down_vote_number()
        if self.up_vote_number + self.down_vote_number == 0:
            self.wilson_score_interval = 0
            return self.wilson_score_interval
        n = self.up_vote_number + self.down_vote_number
        z = 1.281551565545
        p = float(self.up_vote_number) / n

        left = p + 1/(2*n)*z*z
        right = z*sqrt(p*(1-p)/n + z*z/(4*n*n))
        under = 1 + 1/n*z*z
        self.wilson_score_interval = (left - right) / under

        return self.wilson_score_interval

    def get_up_vote_number(self):
        """Calculate how many users have voted for this post.

        :return: The number of up-voters.
        :rtype: int
        """
        self.up_vote_number = 0
        for time_step in self.up_votes:
            for voter in self.up_votes[time_step]:
                self.up_vote_number += 1
        return self.up_vote_number

    def get_down_vote_number(self):
        """Calculate how many users have voted against this post.

        :return: The number of down-voters.
        :rtype: int
        """
        self.down_vote_number = 0
        for time_step in self.down_votes:
            for voter in self.down_votes[time_step]:
                self.down_vote_number += 1
        return self.down_vote_number

    def record_vote(self, time_step: int, user, voting_status: int):
        """
        Record the vote status change by specific user in specific time step.

        :param int time_step: The time step this change is made.
        :param User user: The user who makes the change.
        :param int voting_status: The voting status. 1 is up-vote, -1 is down-vote, 0 is no vote.
        """
        if voting_status == 1:
            for previous_time in self.down_votes:
                if user in self.down_votes[previous_time]:
                    self.down_votes[previous_time].remove(user)
            if time_step not in self.up_votes.keys():
                self.up_votes[time_step] = set()
            self.up_votes[time_step].add(user)
        elif voting_status == -1:
            for previous_time in self.up_votes:
                if user in self.up_votes[previous_time]:
                    self.up_votes[previous_time].remove(user)
            if time_step not in self.down_votes.keys():
                self.down_votes[time_step] = set()
            self.down_votes[time_step].add(user)
        else:
            for previous_time in self.down_votes:
                if user in self.down_votes[previous_time]:
                    self.down_votes[previous_time].remove(user)
            for previous_time in self.up_votes:
                if user in self.up_votes[previous_time]:
                    self.up_votes[previous_time].remove(user)

    def read_time(self):
        """
        Count how many times this answer has been read.

        :return: Times that this answer has been read so far.
        :rtype: int
        """
        count = 0
        for time_step in self.read_users:
            count += len(self.read_users[time_step])
        return count

    def recent_read_time(self, current_time_step: int):
        """
        Count how many times this answer has been read in the recent 5 time steps.

        :param int current_time_step: Current time step.
        :return: Times that this answer has been read in recent 5 time steps.
        :rtype: int
        """
        count = 0
        for time_step in self.read_users:
            if time_step > (current_time_step - 5):
                count += len(self.read_users[time_step])
        return count

    def get_recent_up_vote_number(self, current_time_step: int):
        """Calculate how many users have voted for this post in the recent 5 time steps.

        :param int current_time_step: Current time step.
        :return: The number of up-voters.
        :rtype: int
        """
        self.recent_up_vote_number = 0
        for time_step in self.up_votes:
            if time_step > (current_time_step - 5):
                for voter in self.up_votes[time_step]:
                    self.recent_up_vote_number += 1
        return self.recent_up_vote_number

    def get_recent_down_vote_number(self, current_time_step: int):
        """Calculate how many users have voted against this post in the recent 5 time steps.

        :param int current_time_step: Current time step.
        :return: The number of down-voters.
        :rtype: int
        """
        self.recent_down_vote_number = 0
        for time_step in self.down_votes:
            if time_step > (current_time_step - 5):
                for voter in self.down_votes[time_step]:
                    self.recent_down_vote_number += 1
        return self.recent_down_vote_number

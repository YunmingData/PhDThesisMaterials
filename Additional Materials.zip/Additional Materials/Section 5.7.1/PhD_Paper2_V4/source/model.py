# -*- coding: UTF-8 -*-
"""
Project: PhD_Paper2_V4
File: model.py
Author: 王晨龙 Chenlong Wang
Date & Time of Creation: 2022-06-16 19:20 
"""
import random
import os
import numpy as np
import pandas as pd
from networkx import DiGraph
from networkx.algorithms.components import is_weakly_connected
from source.post import Question, Answer
from source.user import User
from source.utils import choose_from_list_by_scale_free_principle


class SimulationModel:
    def __init__(self, sub_model: str, repetition: int, interaction: str, difficulty: int, opinion_std: float,
                 opinion_bias: float = 0, social_influence: str = None, ability_limitation: bool = False,
                 network_structure: str = None, priority_user_biased: bool = False, priority_proportion: float = 0.5):
        """
        Constructor of the Agent-based simulation model.

        :param str sub_model: The name of the sub model.
        :param int repetition: This is which time of running the model.
        :param str interaction: The mechanism of the interaction among users. "Vote Once": like election, there is only
        one vote and no revision is allowed; "Vote Twice": revision is allowed, if there is ranking algorithm, it is the
         election mechanism in which the candidates are elected only if they reach a threshold;
         "Vote Twice Asynchronously": some users have priorities to vote before their peers, and revision will be done
         based on their voting; "Vote Sequentially": like online Q&A platforms, users read and vote when ever they want.
        :param int difficulty: The difficulty of questions asked.
        :param float opinion_std: The standard deviation of the opinion distribution. [0.1, 0.2, 0.3, 0.4, 0.5]
        :param float opinion_bias: The average bias of the users' opinions towards the correct opinion. If the model
        obeys DeGroot model's assumption, opinion bias = 0.
        :param str social_influence: What kind of social influence is working. None: no social influence;
        "bounded confidence": only assimilating influence; "hybrid": assimilating and repulsing influence.
        :param bool ability_limitation: Whether users have limited ability to read answers.
        :param str network_structure: The network structure of the users. None: there is no network; "random": random
        network; "scale-free": preferential attachment; "small-world": randomly reallocated edges.
        :param bool priority_user_biased: Whether the average bias of the opinions from the users who can answer prior
        to their peers is 0.
        :param float priority_proportion: The proportion of the users who can answer prior to their peers in the whole
        user crowd. [0, 1]
        """
        # ========================================= Sub Model Configuration ========================================== #
        # The name of this sub model.
        self.sub_model = sub_model
        # This is which time of running the model.
        self.repetition = repetition
        # Run ID is for output data.
        self.run_id = sub_model + "_%d" % repetition
        # The mechanism of the interaction among users. "Vote Once": like election, there is only one vote and no
        # revision is allowed; "Vote Twice": revision is allowed, if there is ranking algorithm, it is the election
        # mechanism in which the candidates are elected only if they reach a threshold; "Vote Twice Asynchronously":
        # some users have priorities to vote before their peers, and revision will be done based on their voting;
        # "Vote Sequentially": like online Q&A platforms, users read and vote when ever they want.
        self.interaction = interaction
        # The difficulty of questions asked in this model.
        self.difficulty = difficulty
        # The average bias of users' opinions towards the correct opinion. If the model obeys DeGroot model's
        # assumption, opinion bias = 0.
        self.opinion_bias = opinion_bias
        # The standard deviation of the user opinion distribution.
        self.opinion_std = opinion_std
        # What kind of social influence is working. None: no social influence; "bounded confidence": only assimilating
        # influence; "hybrid": assimilating and repulsing influence.
        self.social_influence = social_influence
        # Whether users have limited ability to read answers.
        self.ability_limitation = ability_limitation
        # The network structure of the users. None: there is no network; "random": random network; "scale-free":
        # preferential attachment; "small-world": randomly reallocated edges.
        self.network_structure = network_structure
        # Whether the average bias of the opinions from the users who can answer prior to their peers is 0.
        self.priority_user_biased = priority_user_biased
        # The proportion of the users who can answer prior to their peers in the whole user crowd.
        self.priority_user_proportion = priority_proportion
        # ================================================== Running ================================================= #
        # The question to which answers are posted.
        self.question = None
        # The user network.
        self.user_network = DiGraph()
        # Highest available post ID.
        self.p_id = 0
        # The list of answers.
        self.answers = []
        # How many time steps does this model need to run.
        self.total_run = 30
        # How many users are there in this model.
        self.total_user_number = 100
        # ================================================== Outputs ================================================= #
        self.output_path = os.getcwd() + os.sep + "output" + os.sep + sub_model
        if not os.path.exists(self.output_path):
            os.mkdir(self.output_path)

    def initialise(self):
        """
        Initialisation of the model. Create the question, users, and user network, in needed. Prepare for the output.
        """
        self.create_question()
        self.create_users()
        self.establish_user_network()
        self.create_output_records()

    def create_question(self):
        """
        Create the question, which is also the topic of the discussion.
        """
        self.question = Question(post_id=self.p_id,
                                 publish_time=0,
                                 publisher=None,
                                 difficulty=self.difficulty)
        self.p_id += 1

    def create_users(self):
        """
        Create the users, allocate their attributes.
        """
        for user_id in range(1, self.total_user_number+1):
            opinion = random.normalvariate(self.opinion_bias, self.opinion_std)
            expertise = round(random.normalvariate(5, 1.5))
            if expertise < 1 or expertise > 9:
                expertise = round(random.normalvariate(5, 1.5))

            agree_threshold = random.uniform(0, 2)
            disagree_threshold = random.uniform(agree_threshold, 2)

            user = User(user_id=user_id,
                        expertise=expertise,
                        opinion=opinion,
                        agree_threshold=agree_threshold,
                        disagree_threshold=disagree_threshold)
            self.user_network.add_node(user)

    def establish_user_network(self):
        """
        Create the network structure of the users. Only works when necessary.
        """
        if self.network_structure is None:
            return
        # For scale-free network, there are 3 + (n-3) = n edges, in which n is the number of nodes.
        # There are at most n_max = n*(n-1) / 2 edges.
        # To make the edge density equal for all kinds of networks, the density should be n / n_max = 2/(n-1).
        edge_density = 2 / (len(self.user_network.nodes) - 1)
        # Random network.
        if self.network_structure == "random":

            self.generate_random_network(edge_density)
        # Scale-free network, the edges are established with preferential attachment.
        elif self.network_structure == "scale-free":
            self.generate_scale_free_network()
        # Small-world network, the edges are reallocated randomly based on the random network.
        elif self.network_structure == "small-network":
            rewire_probability = 0.5
            self.generate_small_world_network(rewire_probability)

    def generate_random_network(self, edge_density: float):
        """
        Generate a random network among the given users with a given edge density.

        :param float edge_density: The density of edges.
        """
        user_list = list(self.user_network.nodes)
        max_edge_number = len(user_list) * (len(user_list) - 1) / 2
        edge_number = round(max_edge_number * edge_density)

        while self.user_network.size() < edge_number:
            (user_a, user_b) = random.sample(user_list, 2)
            if self.user_network.has_edge(user_a, user_b):
                continue
            self.user_network.add_edge(user_a, user_b)

    def generate_scale_free_network(self):
        """
        Generate a scale-free network among the given users. 3 randomly chosen users form a circle firstly, other users
        enter with preferential attachment rule.
        """
        # Choose 3 users, form a circle.
        original_user_list = random.sample(list(self.user_network.nodes), 3)
        self.user_network.add_edge(original_user_list[0], original_user_list[1])
        self.user_network.add_edge(original_user_list[1], original_user_list[2])
        self.user_network.add_edge(original_user_list[2], original_user_list[0])

        for user in self.user_network.nodes:
            if user in original_user_list:
                continue
            chosen_edge = random.choice(list(self.user_network.edges))
            user_being_followed = chosen_edge[1]
            self.user_network.add_edge(user, user_being_followed)

    def generate_small_world_network(self, rewire_probability: float):
        """
        Generate a ring network among the given users with a given edge density, then reallocate the edges with a given
        rewire probability.

        :param float rewire_probability: The probability of rewiring. ranged in (0, 1).
        """
        # Form a ring network.
        user_list = list(self.user_network.nodes)
        for i in range(len(user_list)-1):
            self.user_network.add_edge(user_list[i], user_list[i+1])
        self.user_network.add_edge(user_list[len(user_list)-1], user_list[0])

        # Randomly reallocate the edges.
        rewire_num = round(len(self.user_network.edges) * rewire_probability)
        awaiting_rewire_edges = random.sample(list(self.user_network.edges), rewire_num)
        for edge in awaiting_rewire_edges:
            source = edge[0]
            destiny = edge[1]
            # The new destiny should not be the source, the original destiny, and there should be no edge from the
            # source to the new destiny.
            while destiny == source or destiny == edge[1] or self.user_network.has_edge(source, destiny):
                destiny = random.choice(list(self.user_network.nodes))
            self.user_network.remove_edge(source, edge[1])
            self.user_network.add_edge(source, destiny)

    def create_output_records(self):
        """
        Create the output records.
        """
        # Sub Model.
        sub_model_dict = {
            "run_id": [self.run_id],
            "sub_model": [self.sub_model],
            "repetition": [self.repetition],
            "interaction": [self.interaction],
            "opinion_bias": [self.opinion_bias],
            "opinion_std": [self.opinion_std],
            "social_influence": [self.social_influence],
            "network_structure": [self.network_structure],
            "ability_limitation": [self.ability_limitation],
            "priority_user_biased": [self.priority_user_biased],
            "priority_user_proportion": [self.priority_user_proportion]
        }
        df = pd.DataFrame(sub_model_dict)
        df.to_csv(self.output_path + os.sep + "submodel_%s.csv" % self.run_id)

        # Questions.
        self.question_output = pd.DataFrame({
            "run_id": pd.Series(dtype=str),
            "q_id": pd.Series(dtype=int),
            "difficulty": pd.Series(dtype=int),
            "time_step": pd.Series(dtype=int),
            "num_answers": pd.Series(dtype=int)
        })
        self.question_output.loc[self.question_output.shape[0]] = [self.run_id, self.question.post_id,
                                                                       self.question.difficulty, 0, 0]
        # Answers.
        self.answer_output = pd.DataFrame({
            "run_id": pd.Series(dtype=str),
            "q_id": pd.Series(dtype=int),
            "a_id": pd.Series(dtype=int),
            "time_step": pd.Series(dtype=int),
            "publish_time": pd.Series(dtype=int),
            "value": pd.Series(dtype=float),
            "expression": pd.Series(dtype=int),
            "rank_up_vote": pd.Series(dtype=int),
            "rank_wilson_confidence_interval": pd.Series(dtype=int),
            "reads": pd.Series(dtype=int),
            "up_votes": pd.Series(dtype=int),
            "down_votes": pd.Series(dtype=int),
            "recent_reads": pd.Series(dtype=int),
            "recent_up_votes": pd.Series(dtype=int),
            "recent_down_votes": pd.Series(dtype=int),
            "users_around": pd.Series(dtype=int),
            "target": pd.Series(dtype=bool)
        })

        # Users.
        user_dict = {
            "run_id": pd.Series(dtype=str),
            "u_id": pd.Series(dtype=int),
            "time_step": pd.Series(dtype=int),
            "expertise": pd.Series(dtype=int),
            "opinion": pd.Series(dtype=float)
        }
        self.user_output = pd.DataFrame(user_dict)
        self.record_users(0)

        # Evaluations.
        self.evaluation_output = pd.DataFrame({
            "run_id": pd.Series(dtype=str),
            "q_id": pd.Series(dtype=int),
            "time_step": pd.Series(dtype=int),
            "spearman": pd.Series(dtype=float),
            "kendall_tau": pd.Series(dtype=float),
            "spearman_with_up_votes": pd.Series(dtype=float),
            "kendall_tau_with_up_votes": pd.Series(dtype=float),
            "spearman_top_10_percent": pd.Series(dtype=float),
            "kendall_tau_top_10_percent": pd.Series(dtype=float),
            "top_10_common_proportion": pd.Series(dtype=float),
            "spearman_top_10": pd.Series(dtype=float),
            "kendall_tau_top_10": pd.Series(dtype=float),
            "spearman_show": pd.Series(dtype=float),
            "kendall_tau_show": pd.Series(dtype=float),
            "spearman_with_up_votes_show": pd.Series(dtype=float),
            "kendall_tau_with_up_votes_show": pd.Series(dtype=float),
            "spearman_top_10_percent_show": pd.Series(dtype=float),
            "kendall_tau_top_10_percent_show": pd.Series(dtype=float),
            "top_10_common_proportion_show": pd.Series(dtype=float),
            "spearman_top_10_show": pd.Series(dtype=float),
            "kendall_tau_top_10_show": pd.Series(dtype=float)
        })
        print("# [Initialisation] Created output records.")

    def run(self):
        """
        Run the simulation model, and record the outputs.
        """
        print("""#=========================================================================#
# Sub Model: %s
# Repetition: %d
#=========================================================================#
""" % (self.sub_model, self.repetition))
        if self.interaction == "Vote Once":
            # Each user publishes an answer.
            user: User
            for user in self.user_network.nodes:
                new_answer = user.publish_answer(self.question, self.p_id, 1, False, self.run_id)
                self.answers.append(new_answer)
                self.p_id += 1

            # Each user vote for the answers independently.
            for user in self.user_network.nodes:
                user.reading_process(self.run_id, 2, None, self.answers)

            # Record output variables.
            self.record_dependent_variables(2)
            self.output_realtime_records()
        elif self.interaction == "Vote Twice":
            # Each user publishes an answer.
            user: User
            for user in self.user_network.nodes:
                new_answer = user.publish_answer(self.question, self.p_id, 1, False, self.run_id)
                self.answers.append(new_answer)
                self.p_id += 1

            # Each user vote for the answers. Run two times.
            for time_step in [2, 3]:
                for user in self.user_network.nodes:
                    if self.ability_limitation:
                        time_line = self.prepare_timeline(user, time_step)
                    else:
                        time_line = self.answers
                    if time_step == 2:
                        user.reading_process(self.run_id, time_step, None, time_line)
                    else:
                        user.reading_process(self.run_id, time_step, self.social_influence, time_line)

                # Record output variables.
                self.record_dependent_variables(time_step)
                self.output_realtime_records()
        elif self.interaction == "Vote Twice Asynchronously":
            # Make these users answer firstly.
            for user in self.user_network.nodes:
                new_answer = user.publish_answer(self.question, self.p_id, 1, False, self.run_id)
                self.answers.append(new_answer)
                self.p_id += 1
            self.record_dependent_variables(1)
            self.output_realtime_records()

            # Select some users to publish answers firstly.
            first_round_users = self.select_users_with_priorities()
            # Let these users vote for the first time.
            for user in first_round_users:
                if self.ability_limitation:
                    time_line = self.prepare_timeline(user, 2)
                else:
                    time_line = self.answers
                user.reading_process(self.run_id, 2, None, time_line)
            self.record_dependent_variables(2)
            self.output_realtime_records()

            # Let all users to vote based on the result given by the first round users.
            for user in self.user_network.nodes:
                user.reading_process(self.run_id, 3, self.social_influence, self.answers)
                self.record_dependent_variables(3)
                self.output_realtime_records()
        elif self.interaction == "Vote Sequentially":
            for time_step in range(1, self.total_run+1):
                # Shuffle users.
                user_list = list(self.user_network.nodes)
                random.shuffle(user_list)
                for user in user_list:
                    # Answer question.
                    answered, user_answer = user.has_answered(self.question)
                    if not answered:
                        new_answer = user.publish_answer(self.question, self.p_id, time_step, True, self.run_id)
                        if new_answer is not None:
                            self.answers.append(new_answer)
                            self.p_id += 1

                    # Read and vote.
                    time_line = self.prepare_timeline(user, time_step)
                    user.reading_process(self.run_id, time_step, self.social_influence, time_line)

                    # Record outputs.
                    self.record_dependent_variables(time_step)
                    self.output_realtime_records()

    def prepare_timeline(self, user: User, time_step: int):
        """
        Randomly chose one question to read its answers. The more up-votes an answer has, the more likely it will be
        read.

        :param User user: For whom the timeline is prepared.
        :param int time_step: Current time step.
        :return: The sorted answers under a question.
        :rtype: list[Answer]
        """
        if self.interaction == "Vote Sequentially":
            # The answers the users this user follows voted-for in the recent 2 time steps.
            users_followed = set()
            for edge in self.user_network.edges:
                if edge[0] == user:
                    users_followed.add(edge[1])

            answers_voted_by_friends = set()
            for user in users_followed:
                if time_step in user.answers_voted_for.keys():
                    for answerA in user.answers_voted_for[time_step]:
                        answers_voted_by_friends.add(answerA)
                if (time_step - 1) in user.answers_voted_for.keys():
                    for answerA in user.answers_voted_for[time_step - 1]:
                        answers_voted_by_friends.add(answerA)
            other_answers = set()
            for answerB in self.question.answers:
                if answerB not in answers_voted_by_friends:
                    other_answers.add(answerB)
            result = []
            if len(answers_voted_by_friends) >= 5:
                result.extend(random.sample(list(answers_voted_by_friends), 5))
                result.extend(choose_from_list_by_scale_free_principle(list(other_answers), 5))
            elif 1 <= len(answers_voted_by_friends) <= 4:
                result.extend(random.sample(list(answers_voted_by_friends), len(answers_voted_by_friends)))
                result.extend(choose_from_list_by_scale_free_principle(list(other_answers),
                                                                       10 - len(answers_voted_by_friends)))
            else:
                result = choose_from_list_by_scale_free_principle(list(other_answers), 10)
            return result
        else:
            all_answers = []
            for answer in self.question.answers:
                all_answers.append(answer)
            return choose_from_list_by_scale_free_principle(all_answers, 10)

    def select_users_with_priorities(self):
        """
        Select some users who can answer the question prior to their peers.

        :return: The selected users.
        :rtype: set[User]
        """
        first_round_users = set()
        if self.priority_user_biased:
            user_list = list(self.user_network.nodes)
            random.shuffle(user_list)
            target_num = round(self.priority_user_proportion * len(user_list))
            # Preferentially choose the users with a positive opinion.
            for user in user_list:
                if user.opinion > 0 and len(first_round_users) < target_num:
                    first_round_users.add(user)
            # Compensate with users with negative opinions.
            while len(first_round_users) < target_num:
                for user in user_list:
                    if user.opinion <= 0:
                        first_round_users.add(user)
        else:
            target_num = round(self.priority_user_proportion * len(list(self.user_network.nodes)))
            first_round_users = random.sample(list(self.user_network.nodes), target_num)
        return first_round_users

    def record_dependent_variables(self, time_step):
        """
        Record the values of dependent variables in each time step.

        :param int time_step: Current time step.
        """
        self.record_question(time_step)
        self.record_answers(time_step)
        self.record_users(time_step)
        self.record_evaluation_quality(time_step)

    def record_question(self, time_step):
        """
        Record the new questions in the question output.

        :param int time_step: Current time step.
        """
        self.question.record_answer_ranks(time_step)
        self.question_output.loc[self.question_output.shape[0]] = [self.run_id, self.question.post_id,
                                                                   self.question.difficulty, time_step,
                                                                   len(self.question.answers)]

    def record_answers(self, time_step):
        """
        Record the answers in this time step.

        :param int time_step: Current time step.
        :return:
        """
        answer: Answer
        for answer in self.answers:
            read_time = answer.read_time()
            up_vote = answer.get_up_vote_number()
            down_vote = answer.get_down_vote_number()
            recent_read_time = answer.recent_read_time(time_step)
            recent_up_vote = answer.get_recent_up_vote_number(time_step)
            recent_down_vote = answer.get_recent_down_vote_number(time_step)
            users_around = 0
            if answer.post_id > 10000:
                target = True
            else:
                target = False
            user: User
            for user in self.user_network.nodes:
                # if abs(answer.value - user.opinion) < 0.5:
                #     users_around += 1
                has_answered, users_answer = user.has_answered(self.question)
                if has_answered and abs(answer.value - users_answer.value) < 0.5:
                    users_around += 1
            self.answer_output.loc[self.answer_output.shape[0]] = [self.run_id,
                                                                   answer.question.post_id,
                                                                   answer.post_id,
                                                                   time_step,
                                                                   answer.publish_time,
                                                                   answer.value,
                                                                   answer.expression,
                                                                   answer.rank_by_up_vote[time_step],
                                                                   answer.rank_by_wilson_confidence_interval[time_step],
                                                                   read_time, up_vote, down_vote,
                                                                   recent_read_time, recent_up_vote, recent_down_vote,
                                                                   users_around, target]

    def record_users(self, time_step):
        """
        Record users' opinions and expertises in this time step.

        :param int time_step: Current time step.
        """
        for user in self.user_network.nodes:
            self.user_output = pd.concat([self.user_output, pd.DataFrame([[np.NAN] * self.user_output.shape[1]],
                                                                         columns=self.user_output.columns)],
                                         ignore_index=True)
            self.user_output.loc[self.user_output.shape[0] - 1, "run_id"] = self.run_id
            self.user_output.loc[self.user_output.shape[0] - 1, "u_id"] = user.user_id
            self.user_output.loc[self.user_output.shape[0] - 1, "time_step"] = time_step
            self.user_output.loc[self.user_output.shape[0] - 1, "expertise"] = user.expertise
            self.user_output.loc[self.user_output.shape[0] - 1, "opinion"] = user.opinion

    def record_evaluation_quality(self, time_step):
        """
        Record the collective-evaluation_quality of this time step.

        :param int time_step: Current time step.
        """
        # The comparison if community evaluation is calculated with up-vote numbers.
        coefficients_v = self.question.ranking_correlation_coefficient(True)
        spearman = coefficients_v[0][0]
        kendall_tau = coefficients_v[1][0]
        coefficients_v_with_votes = self.question.ranking_correlation_coefficient_answers_with_votes(True)
        spearman_with_votes = coefficients_v_with_votes[0][0]
        kendall_tau_with_votes = coefficients_v_with_votes[1][0]
        coefficients_v_top_10_percent = self.question.ranking_correlation_coefficient_top_10_percent(True)
        spearman_top_10_percent = coefficients_v_top_10_percent[0][0]
        kendall_tau_top_10_percent = coefficients_v_top_10_percent[1][0]
        common_proportion = coefficients_v_top_10_percent[2]
        coefficients_v_top_10 = self.question.ranking_correlation_coefficient_top_10(True)
        spearman_top_10 = coefficients_v_top_10[0][0]
        kendall_tau_top_10 = coefficients_v_top_10[1][0]
        # The comparison if community evaluation is calculated with Wilson Confidence Intervals.
        coefficients_w = self.question.ranking_correlation_coefficient(False)
        spearman_show = coefficients_w[0][0]
        kendall_tau_show = coefficients_w[1][0]
        coefficients_w_with_votes = self.question.ranking_correlation_coefficient_answers_with_votes(False)
        spearman_with_votes_show = coefficients_w_with_votes[0][0]
        kendall_tau_with_votes_show = coefficients_w_with_votes[1][0]
        coefficients_w_top_10_percent = self.question.ranking_correlation_coefficient_top_10_percent(False)
        spearman_top_10_percent_show = coefficients_w_top_10_percent[0][0]
        kendall_tau_top_10_percent_show = coefficients_w_top_10_percent[1][0]
        common_proportion_show = coefficients_w_top_10_percent[2]
        coefficients_w_top_10 = self.question.ranking_correlation_coefficient_top_10(False)
        spearman_top_10_show = coefficients_w_top_10[0][0]
        kendall_tau_top_10_show = coefficients_w_top_10[1][0]
        self.evaluation_output.loc[self.evaluation_output.shape[0]] = [self.run_id, self.question.post_id,
                                                                       time_step, spearman, kendall_tau,
                                                                       spearman_with_votes,
                                                                       kendall_tau_with_votes,
                                                                       spearman_top_10_percent,
                                                                       kendall_tau_top_10_percent,
                                                                       common_proportion,
                                                                       spearman_top_10, kendall_tau_top_10,
                                                                       spearman_show, kendall_tau_show,
                                                                       spearman_with_votes_show,
                                                                       kendall_tau_with_votes_show,
                                                                       spearman_top_10_percent_show,
                                                                       kendall_tau_top_10_percent_show,
                                                                       common_proportion_show,
                                                                       spearman_top_10_show,
                                                                       kendall_tau_top_10_show]

    def output_realtime_records(self):
        """
        Write the realtime records into output files.
        """
        self.question_output.to_csv(self.output_path + os.sep + "question_%s.csv" % self.run_id)
        self.answer_output.to_csv(self.output_path + os.sep + "answer_%s.csv" % self.run_id)
        self.user_output.to_csv(self.output_path + os.sep + "user_%s.csv" % self.run_id)
        self.evaluation_output.to_csv(self.output_path + os.sep + "evaluation_%s.csv" % self.run_id)

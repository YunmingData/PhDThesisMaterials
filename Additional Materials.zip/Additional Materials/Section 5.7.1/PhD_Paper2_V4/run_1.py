# -*- coding: UTF-8 -*-
"""
Project: PhD_Paper2_V4
File: run_1.py
Author: 王晨龙 Chenlong Wang
Date & Time of Creation: 2022-06-16 19:20 
"""
from source.model import SimulationModel

j = 1
rep_time = 50
# Benchmark.
for i in range(j, j+rep_time):
    model = SimulationModel(sub_model="Model 1",
                            repetition=i,
                            interaction="Vote Once",
                            difficulty=8,
                            opinion_std=0.3,
                            opinion_bias=0,
                            social_influence=None,
                            ability_limitation=False,
                            network_structure=None,
                            priority_user_biased=False,
                            priority_proportion=0.5)
    model.initialise()
    model.run()
j += rep_time

# Sensitivity analysis: difficulty.
for difficulty in [5, 6, 7, 8, 9]:
    for i in range(j, j+rep_time):
        model = SimulationModel(sub_model="Model 1-Sensitivity Analysis-difficulty",
                                repetition=i,
                                interaction="Vote Once",
                                difficulty=difficulty,
                                opinion_std=0.3,
                                opinion_bias=0,
                                social_influence=None,
                                ability_limitation=False,
                                network_structure=None,
                                priority_user_biased=False,
                                priority_proportion=0.5)
        model.initialise()
        model.run()
    j += rep_time

# Sensitivity analysis: opinion_std.
for std in [0.1, 0.2, 0.3, 0.4, 0.5]:
    for i in range(j, j+rep_time):
        model = SimulationModel(sub_model="Model 1-Sensitivity analysis-opinion_std",
                                repetition=i,
                                interaction="Vote Once",
                                difficulty=5,
                                opinion_std=std,
                                opinion_bias=0,
                                social_influence=None,
                                ability_limitation=False,
                                network_structure=None,
                                priority_user_biased=False,
                                priority_proportion=0.5)
        model.initialise()
        model.run()
    j += rep_time

# Sensitivity analysis: opinion_bias.
for bias in [0.1, 0.2, 0.3, 0.4, 0.5]:
    for i in range(j, j+rep_time):
        model = SimulationModel(sub_model="Model 1-Sensitivity analysis-opinion_bias",
                                repetition=i,
                                interaction="Vote Once",
                                difficulty=5,
                                opinion_std=0.3,
                                opinion_bias=bias,
                                social_influence=None,
                                ability_limitation=False,
                                network_structure=None,
                                priority_user_biased=False,
                                priority_proportion=0.5)
        model.initialise()
        model.run()
    j += rep_time

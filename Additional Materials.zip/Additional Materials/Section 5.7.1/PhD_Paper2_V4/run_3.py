# -*- coding: UTF-8 -*-
"""
Project: PhD_Paper2_V4
File: run_3.py
Author: 王晨龙 Chenlong Wang
Date & Time of Creation: 2022-06-17 17:45 
"""
from source.model import SimulationModel

j = 1
rep_time = 50

# Benchmark.
for biased in [False, True]:
    for proportion in [0.1, 0.3, 0.5, 0.7, 0.9]:
        for i in range(j, j + rep_time):
            model = SimulationModel(sub_model="Model 3",
                                    repetition=i,
                                    interaction="Vote Twice Asynchronously",
                                    difficulty=8,
                                    opinion_std=0.3,
                                    opinion_bias=0,
                                    social_influence="hybrid",
                                    ability_limitation=True,
                                    network_structure="scale-free",
                                    priority_user_biased=biased,
                                    priority_proportion=proportion)
            model.initialise()
            model.run()
        j += rep_time

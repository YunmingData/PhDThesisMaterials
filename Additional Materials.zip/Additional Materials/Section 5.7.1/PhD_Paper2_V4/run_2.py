# -*- coding: UTF-8 -*-
"""
Project: PhD_Paper2_V4
File: run_2.py
Author: 王晨龙 Chenlong Wang
Date & Time of Creation: 2022-06-17 17:39 
"""
from source.model import SimulationModel

j = 1
rep_time = 50
# Benchmark.
for i in range(j, j + rep_time):
    model = SimulationModel(sub_model="Model 2",
                            repetition=i,
                            interaction="Vote Twice",
                            difficulty=8,
                            opinion_std=0.3,
                            opinion_bias=0,
                            social_influence="hybrid",
                            ability_limitation=True,
                            network_structure="scale-free",
                            priority_user_biased=False,
                            priority_proportion=0.5)
    model.initialise()
    model.run()
j += rep_time

# Sensitivity Analysis: social_influence.
for social_influence in ["bounded confidence", "hybrid"]:
    for i in range(j, j + rep_time):
        model = SimulationModel(sub_model="Model 2-Sensitivity Analysis-social_influence",
                                repetition=i,
                                interaction="Vote Twice",
                                difficulty=8,
                                opinion_std=0.3,
                                opinion_bias=0,
                                social_influence=social_influence,
                                ability_limitation=True,
                                network_structure="scale-free",
                                priority_user_biased=False,
                                priority_proportion=0.5)
        model.initialise()
        model.run()
    j += rep_time

# Sensitivity Analysis: network_structure.
for network_structure in ["random", "scale-free", "small-world"]:
    for i in range(j, j + rep_time):
        model = SimulationModel(sub_model="Model 2-Sensitivity Analysis-network_structure",
                                repetition=i,
                                interaction="Vote Twice",
                                difficulty=8,
                                opinion_std=0.3,
                                opinion_bias=0,
                                social_influence="hybrid",
                                ability_limitation=True,
                                network_structure=network_structure,
                                priority_user_biased=False,
                                priority_proportion=0.5)
        model.initialise()
        model.run()
    j += rep_time

# Sensitivity Analysis: ability_limitation.
for ability_limitation in [False, True]:
    for i in range(j, j + rep_time):
        model = SimulationModel(sub_model="Model 2-Sensitivity Analysis-ability_limitation",
                                repetition=i,
                                interaction="Vote Twice",
                                difficulty=8,
                                opinion_std=0.3,
                                opinion_bias=0,
                                social_influence="hybrid",
                                ability_limitation=ability_limitation,
                                network_structure="scale-free",
                                priority_user_biased=False,
                                priority_proportion=0.5)
        model.initialise()
        model.run()
    j += rep_time

# -*- coding: UTF-8 -*-
"""
Project: PhD_Paper2_V4
File: run_4_2.py
Author: 王晨龙 Chenlong Wang
Date & Time of Creation: 2022-06-20 09:35 
"""
from source.model import SimulationModel

j = 11
rep_time = 10

for i in range(j, j+rep_time):
    model = SimulationModel(sub_model="Model 4",
                            repetition=i,
                            interaction="Vote Sequentially",
                            difficulty=8,
                            opinion_std=0.3,
                            opinion_bias=0,
                            social_influence="hybrid",
                            ability_limitation=True,
                            network_structure="scale-free",
                            priority_user_biased=False,
                            priority_proportion=0.5)
    model.initialise()
    model.run()
